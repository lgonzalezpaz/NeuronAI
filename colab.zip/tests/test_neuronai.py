"""Unit and property tests for NeuronAI v2 (run with `pytest -q`)."""
import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pytest

from neuronai.model import (simulate, theta_dict, apply_controls, CONTROLS, FIT_PARAMS, FIT_BOUNDS,
                            params_from_unit, params_to_unit, connectivity_matrices, _psp_discretisation)
from neuronai.features import extract_features, feature_matrix, phase_sync, spectral_features, psd, FEATURE_NAMES
from neuronai.stats import icc_2_1, fdr_bh, hedges_g
from neuronai.intervention import NormativeReference, all_supports
from neuronai.data import read_gdf, preprocess, _norm_name


def short_sim(seed=0, **kw):
    return simulate(theta_dict(**kw), duration=6.0, transient=1.0, seed=seed)


# ---------------------------------------------------------------- model
def test_simulation_shape_and_finite():
    r = short_sim()
    assert r.eeg.shape == (1, 17, 1500)
    assert np.isfinite(r.eeg).all()
    assert r.eeg.std() > 0


def test_bitwise_reproducibility():
    a, b = short_sim(seed=3).eeg, short_sim(seed=3).eeg
    assert np.array_equal(a, b)
    assert not np.array_equal(a, short_sim(seed=4).eeg)


def test_batch_equals_single():
    th = theta_dict()
    single = simulate(th, duration=4.0, transient=1.0, seed=1).eeg[0]
    batch = simulate({k: np.full(1, v) for k, v in th.items()}, duration=4.0, transient=1.0, seed=1).eeg[0]
    assert np.allclose(single, batch)


def test_common_average_reference():
    r = short_sim()
    assert np.allclose(r.eeg.mean(axis=1), 0, atol=1e-4)


def test_psp_discretisation_exact_steady_state():
    # step response of the unit-gain kernel converges to 1/k
    P, G = _psp_discretisation(100.0, 1e-3)
    y = np.zeros(2)
    for _ in range(2000):
        y = P @ y + G * 1.0
    assert abs(y[0] - 1 / 100.0) < 1e-9


def test_controls_zero_is_identity():
    th = {k: np.array([v]) for k, v in theta_dict().items()}
    out = apply_controls(th, np.zeros((1, len(CONTROLS))))
    for k in th:
        assert np.allclose(out[k], th[k])


@pytest.mark.parametrize('knob,param,sign', [('GABA_A', 'G', 1), ('GABA_slow', 'B', 1), ('AMPA', 'A', 1),
                                             ('Drive', 'p', 1), ('NE', 'rscale', 1), ('5HT', 'dv0', -1)])
def test_controls_direction(knob, param, sign):
    th = {k: np.array([v]) for k, v in theta_dict().items()}
    u = np.zeros((1, len(CONTROLS))); u[0, CONTROLS.index(knob)] = 1.0
    base = apply_controls(th, None)[param]
    mod = apply_controls(th, u)[param]
    assert np.sign(mod - base)[0] == sign


def test_controls_clipped():
    th = {k: np.array([v]) for k, v in theta_dict().items()}
    u = np.full((1, len(CONTROLS)), 5.0)
    assert np.allclose(apply_controls(th, u)['A'], apply_controls(th, np.ones((1, len(CONTROLS))))['A'])


def test_unit_roundtrip():
    z = np.random.default_rng(0).random((20, len(FIT_PARAMS)))
    assert np.allclose(params_to_unit(params_from_unit(z)), z)


def test_matrices_row_normalised():
    W, M = connectivity_matrices()
    assert np.allclose(W.sum(1), 1) and np.allclose(M.sum(1), 1)
    assert np.allclose(np.diag(W), 0)


# ---------------------------------------------------------------- features
def test_features_scale_invariant():
    x = short_sim().eeg[0]
    f1 = feature_matrix(extract_features(x, 250.0))
    f2 = feature_matrix(extract_features(x * 1e-6, 250.0))
    assert np.allclose(f1, f2, rtol=1e-4, atol=1e-6)


def test_sync_bounds_and_extremes():
    fs, t = 250.0, np.arange(0, 20, 1 / 250.0)
    rng = np.random.default_rng(0)
    same = np.tile(np.sin(2 * np.pi * 10 * t), (5, 1)) + 1e-3 * rng.standard_normal((5, len(t)))
    noise = rng.standard_normal((5, len(t)))
    s1, s0 = phase_sync(same, fs), phase_sync(noise, fs)
    assert s1['plv_alpha'] > 0.99 and s1['kuramoto_alpha'] > 0.99
    assert s0['plv_alpha'] < 0.2
    for s in (s0, s1):
        for k in ('plv_alpha', 'kuramoto_alpha'):
            assert 0 <= float(s[k]) <= 1


def test_wpli_zero_lag_insensitive():
    # zero-lag (volume-conduction-like) coupling must give wPLI ~ 0 while PLV ~ 1
    fs, t = 250.0, np.arange(0, 20, 1 / 250.0)
    rng = np.random.default_rng(1)
    src = np.sin(2 * np.pi * 10 * t + 0.3 * np.cumsum(rng.standard_normal(len(t))) / np.sqrt(250))
    x = np.stack([src + 0.05 * rng.standard_normal(len(t)) for _ in range(4)])
    s = phase_sync(x, fs)
    assert s['plv_alpha'] > 0.9 and abs(s['wpli_alpha']) < 0.2


def test_iaf_recovers_alpha_peak():
    fs, t = 250.0, np.arange(0, 20, 1 / 250.0)
    rng = np.random.default_rng(2)
    x = np.stack([np.sin(2 * np.pi * 10 * t + rng.random() * 6) + 0.3 * rng.standard_normal(len(t)) for _ in range(3)])
    f, P = psd(x, fs)
    assert abs(spectral_features(f, P)['iaf'] - 10.0) < 0.6


def test_exponent_of_pink_noise():
    rng = np.random.default_rng(3)
    n = 250 * 60
    spec = np.fft.rfft(rng.standard_normal((3, n)))
    fr = np.fft.rfftfreq(n, 1 / 250.0); fr[0] = 1
    x = np.fft.irfft(spec / fr ** 1.0, n)           # 1/f^2 power -> exponent 2
    f, P = psd(x, 250.0)
    assert abs(spectral_features(f, P)['exponent'] - 2.0) < 0.25


# ---------------------------------------------------------------- statistics & search
def test_icc_perfect_and_noise():
    x = np.random.default_rng(0).standard_normal(50)
    assert icc_2_1(x, x) > 0.999
    assert icc_2_1(x, np.random.default_rng(1).standard_normal(50)) < 0.4


def test_fdr_monotone():
    q = fdr_bh(np.array([0.001, 0.01, 0.03, 0.5]))
    assert np.all(np.diff(q) >= 0) and q[-1] <= 1


def test_hedges_sign():
    assert hedges_g(np.ones(10) + np.arange(10) * .1, np.arange(10) * .1) > 0


def test_supports_count():
    assert len(all_supports(3)) == 9 + 36 + 84 == 129


def test_mahalanobis_zero_at_mean():
    X = np.random.default_rng(0).standard_normal((40, len(FEATURE_NAMES)))
    ref = NormativeReference(X)
    assert ref.distance(X.mean(0)[None])[0] < 1e-8
    assert np.all(ref.distance(X) >= 0)


# ---------------------------------------------------------------- data
def test_channel_aliases():
    assert _norm_name('EEG T3-REF') == 'T7' and _norm_name('FP1') == 'Fp1'


def test_gdf_roundtrip_and_preprocess():
    import struct
    fs, n, ns = 256, 256 * 70, 17
    labels = ['FP1', 'FP2', 'F7', 'F3', 'Fz', 'F4', 'F8', 'T7', 'C3', 'Cz', 'C4', 'T8', 'P7', 'P3', 'Pz', 'P4', 'P8']
    rng = np.random.default_rng(0)
    data = rng.standard_normal((ns, n)) * 10 + 5 * np.sin(2 * np.pi * 10 * np.arange(n) / fs)
    hdr = bytearray(256 * (ns + 1))
    hdr[:8] = b'GDF 1.25'
    hdr[184:192] = struct.pack('<q', len(hdr)); hdr[236:244] = struct.pack('<q', n)
    hdr[244:252] = struct.pack('<II', 1, fs); hdr[252:254] = struct.pack('<H', ns)
    o = 256
    def put(vals, w, fmt=None):
        nonlocal o
        for v in vals:
            hdr[o:o + w] = struct.pack(fmt, v) if fmt else v.encode().ljust(w); o += w
    put(labels, 16); put([''] * ns, 80); put(['uV'] * ns, 8)
    put([-1e4] * ns, 8, '<d'); put([1e4] * ns, 8, '<d'); put([-10000] * ns, 8, '<q'); put([10000] * ns, 8, '<q')
    put([''] * ns, 80); put([1] * ns, 4, '<i'); put([17] * ns, 4, '<I')
    with tempfile.TemporaryDirectory() as d:
        p = os.path.join(d, 't.gdf')
        with open(p, 'wb') as f:
            f.write(bytes(hdr)); f.write(data.T.astype('<f8').tobytes())
        x, fs2, names = read_gdf(p)
        assert fs2 == fs and np.allclose(x, data) and names[0] == 'FP1'
        pp = preprocess(x, fs2, names)
        assert pp['fs'] == 250.0 and len(pp['windows']) >= 3 and not pp['excluded']


# ---------------------------------------------------------------- additions (v2.0 search & refinement)
def test_common_random_numbers():
    th = {k: np.full(4, v) for k, v in theta_dict().items()}
    r = simulate(th, duration=2.0, transient=0.5, seed=1, crn_index=np.array([0, 1, 0, 1]))
    assert np.allclose(r.eeg[0], r.eeg[2]) and not np.allclose(r.eeg[0], r.eeg[1])


def test_gaba_decay_kinetics_vectorised():
    from neuronai.model import _psp_discretisation, _psp_discretisation_vec
    P, G = _psp_discretisation(500.0, 1e-3)
    Pv, Gv = _psp_discretisation_vec(np.array([[500.0]]), 1e-3)
    assert np.allclose(P.ravel(), [x.item() for x in Pv]) and np.allclose(G, [x.item() for x in Gv])


def test_random_like_matches_support_and_norm():
    from neuronai.intervention import random_like
    U = np.zeros((5, len(CONTROLS))); U[0, [0, 3]] = [0.5, -0.4]; U[1, 2] = 0.9; U[2, [1, 4, 8]] = [0.2, 0.3, -0.1]
    U[3, 5] = -1.0; U[4, [6, 7]] = [0.7, 0.7]
    R_ = random_like(U, seed=0)
    assert np.all((np.abs(R_) > 1e-12).sum(1) == (np.abs(U) > 1e-12).sum(1))
    assert np.allclose(np.linalg.norm(R_, axis=1), np.linalg.norm(U, axis=1), atol=1e-9)
    assert np.all(np.abs(R_) <= 1)


def test_mlp_gradient_matches_finite_difference():
    from sklearn.neural_network import MLPRegressor
    from neuronai.inference import ForwardEmulator, emulator_value_grad
    rng = np.random.default_rng(0)
    Xtr = rng.random((300, 11)); Ytr = np.c_[np.sin(3 * Xtr[:, 0]), Xtr[:, 1] ** 2, Xtr[:, 2] * Xtr[:, 3]]
    emu = ForwardEmulator(n_members=2, hidden=(16, 16), max_iter=200).fit(Xtr, Ytr)
    u = rng.random(11)
    P, J = emulator_value_grad(emu, u)
    assert np.allclose(P, emu.predict(u[None])[0])
    eps = 1e-6
    for k in range(3):
        e = np.zeros(11); e[k] = eps
        num = (emu.predict((u + e)[None])[0] - emu.predict((u - e)[None])[0]) / (2 * eps)
        assert np.allclose(num, J[:, k], atol=1e-5)


def test_narrowband_line_detected_but_not_alpha():
    from neuronai.data import detect_narrowband
    fs, n = 250.0, 250 * 80
    rng = np.random.default_rng(5)
    t = np.arange(n) / fs
    spec = np.fft.rfft(rng.standard_normal((6, n)))
    fr = np.fft.rfftfreq(n, 1 / fs); fr[0] = 1
    x = np.fft.irfft(spec / fr ** 0.8, n)
    alpha = np.sum([np.sin(2 * np.pi * f * t + rng.random() * 6) for f in np.linspace(9, 11, 15)], 0) * 0.02
    line = 0.3 * np.sin(2 * np.pi * 16.0 * t)
    peaks = detect_narrowband(x + alpha + line[None] * rng.random((6, 1)), fs)
    assert any(abs(p - 16.0) < 0.2 for p in peaks)
    assert not any(8 < p < 12 for p in peaks)


def test_discriminant_identification_separable_and_null():
    from neuronai.stats import identify_discriminant
    rng = np.random.default_rng(0)
    centres = rng.normal(0, 3, (4, 5))
    lab = np.repeat(np.arange(4), 10)
    M = centres[lab] + rng.normal(0, 0.5, (40, 5))
    assert identify_discriminant(M, lab) > 0.95
    noise = rng.normal(0, 1, (40, 5))
    assert identify_discriminant(noise, lab) < 0.5


def test_child_permutation_exact_and_monte_carlo_agree():
    from neuronai.stats import child_permutation_test
    rng = np.random.default_rng(1)
    children = np.repeat(np.arange(12), 5); groups = np.where(children < 6, 'A', 'B')
    v = rng.normal(0, 1, 60) + (groups == 'A') * 1.5 + np.repeat(rng.normal(0, 0.3, 12), 5)
    _, p_exact, n_exact = child_permutation_test(v, groups, children)
    _, p_mc, n_mc = child_permutation_test(v, groups, children, max_exact=10, n_perm=5000)
    assert n_exact == 924 and n_mc == 5000
    assert abs(p_exact - p_mc) < 0.02


def test_sign_flip_test_detects_shift_and_null():
    from neuronai.stats import sign_flip_test
    rng = np.random.default_rng(0)
    assert sign_flip_test(rng.normal(1.0, 1, 30))[1] < 0.01
    assert sign_flip_test(rng.normal(0.0, 1, 30))[1] > 0.05
