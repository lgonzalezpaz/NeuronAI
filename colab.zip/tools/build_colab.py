"""Generate the Google Colab single-cell script and notebook from the repository sources.

Every source file is embedded as plain, readable text (no encoding of any kind), written to
/content/NeuronAI at run time, and executed with the same scripts used for the article."""
import json, os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCES = ['scripts/00_prepare_data.py', 'scripts/02c_assign_participants.py', 'scripts/fig6_clinical_load.py',
           'neuronai/__init__.py', 'neuronai/model.py', 'neuronai/features.py', 'neuronai/data.py',
           'neuronai/bank.py', 'neuronai/inference.py', 'neuronai/intervention.py', 'neuronai/stats.py',
           'scripts/fig_style.py', 'scripts/01_generate_banks.py', 'scripts/02_preprocess_features.py',
           'scripts/03_train_models.py', 'scripts/03b_noise_ceiling.py', 'scripts/03c_benchmark_inference.py', 'scripts/04_fit_subjects.py',
           'scripts/05_pharmaco_validity.py', 'scripts/05b_control_fingerprints.py', 'scripts/06_intervention.py',
           'scripts/07_validation_stats.py', 'scripts/08_single_case.py', 'scripts/fig1_schematic.py',
           'scripts/09_figures.py', 'scripts/fig_graphical_abstract.py', 'tests/__init__.py', 'tests/test_neuronai.py']

HEADER = '''# =============================================================================
# NeuronAI v2.0 - Google Colab version (complete pipeline)
# Biophysical EEG digital twins with simulation-based inference for
# personalised in silico neuropharmacology.
#
# HOW TO USE
#   1. Open https://colab.research.google.com and create a new notebook.
#   2. Get the two "Download All" links of the Duville et al. datasets:
#      open https://data.mendeley.com/datasets/7zf99hxxc9/1 (ASD), click "Download All",
#      open your browser's downloads page (Chrome: chrome://downloads), right-click the file,
#      "Copy link address", paste it in DIRECT_URLS["ASD"] below (you can cancel the local download);
#      repeat with https://data.mendeley.com/datasets/spwnt8t25y/1 (TD).
#      Alternative: put both zip files in Google Drive and use MANUAL_ZIPS.
#   3. Paste this whole file into ONE code cell and press Run (Ctrl+Enter). Keep the tab open.
#   4. At the end, the results and figures are downloaded as NeuronAI_results.zip.
#
# MODE = "quick": 2,048 simulations per bank (checks the pipeline; results are less precise).
# MODE = "paper": 8,192 simulations per bank (reproduces the article; about 8-10 h on 2 CPUs).
# =============================================================================
MODE = "quick"            # "quick", "paper" or "test"
DIRECT_URLS = {"ASD": "", "TD": ""}
MANUAL_ZIPS = {}          # e.g. {"ASD": "/content/drive/MyDrive/ASD.zip", "TD": "/content/drive/MyDrive/TD.zip"}
RUN_TESTS = True          # run the unit tests first
'''

RUNNER = '''
# ----------------------------------------------------------------------------- setup
import os, sys, subprocess, zipfile, glob, shutil, time
REPO = os.environ.get("NEURONAI_HOME", "/content/NeuronAI")
os.makedirs(REPO, exist_ok=True)
for rel, src in SOURCE_FILES.items():
    path = os.path.join(REPO, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(src)
os.makedirs(os.path.join(REPO, "results"), exist_ok=True)
os.makedirs(os.path.join(REPO, "figures"), exist_ok=True)
print("NeuronAI v2.0 source written to", REPO)


def run(cmd):
    print("\\n$ " + cmd, flush=True)
    t0 = time.time()
    p = subprocess.Popen(cmd, shell=True, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in p.stdout:
        print(line, end="", flush=True)
    if p.wait() != 0:
        raise RuntimeError("Step failed: " + cmd)
    print(f"   ({(time.time() - t0) / 60:.1f} min)", flush=True)


# ----------------------------------------------------------------------------- data
import requests


def fetch(url, dest):
    with requests.get(url, stream=True, timeout=300) as r:
        r.raise_for_status()
        with open(dest, "wb") as fh:
            for chunk in r.iter_content(1 << 20):
                fh.write(chunk)


RAW = {}
if any(v.startswith("/content/drive") for v in MANUAL_ZIPS.values()):
    from google.colab import drive
    drive.mount("/content/drive")
for grp in ["ASD", "TD"]:
    if MANUAL_ZIPS.get(grp):
        RAW[grp] = MANUAL_ZIPS[grp]
    elif DIRECT_URLS.get(grp, "").strip():
        RAW[grp] = f"/content/{grp}_all.zip"
        if not os.path.exists(RAW[grp]):
            print("downloading", grp, "...", flush=True)
            fetch(DIRECT_URLS[grp].strip(), RAW[grp])
    else:
        raise RuntimeError(f"Provide DIRECT_URLS['{grp}'] or MANUAL_ZIPS['{grp}'] (see the instructions at the top).")

# ----------------------------------------------------------------------------- pipeline
N_BANK = {"quick": 2048, "paper": 8192, "test": 256}[MODE]
os.environ["OMP_NUM_THREADS"] = "1"
if RUN_TESTS:
    run("pip -q install pytest && python -m pytest -q tests")
run(f'python scripts/00_prepare_data.py --asd "{RAW["ASD"]}" --td "{RAW["TD"]}"')
run(f"python scripts/01_generate_banks.py --kind I --n {N_BANK} & python scripts/01_generate_banks.py --kind E --n {N_BANK}; wait")
run("python scripts/02_preprocess_features.py --asd data/ASD --td data/TD")
run("python scripts/02c_assign_participants.py --meta data_meta")
run("python scripts/03_train_models.py")
run("python scripts/03b_noise_ceiling.py")
run("python scripts/03c_benchmark_inference.py")
run("python scripts/04_fit_subjects.py --shard 0 --nshards 2 & python scripts/04_fit_subjects.py --shard 1 --nshards 2; wait")
run("python scripts/05_pharmaco_validity.py & python scripts/05b_control_fingerprints.py; wait")
run("python scripts/06_intervention.py --shard 0 --nshards 2 & python scripts/06_intervention.py --shard 1 --nshards 2; wait")
run("python scripts/08_single_case.py")
run("python scripts/07_validation_stats.py")
run("python scripts/fig1_schematic.py")
run("python scripts/09_figures.py")
run("python scripts/fig6_clinical_load.py")
run("python scripts/fig_graphical_abstract.py")

# ----------------------------------------------------------------------------- show & download
try:
    from IPython.display import Image, display
    for f in sorted(glob.glob(os.path.join(REPO, "figures", "*.png"))):
        print(os.path.basename(f)); display(Image(filename=f, width=900))
except ImportError:
    print("Figures written to", os.path.join(REPO, "figures"))
print()
print("Key results:")
print(open(os.path.join(REPO, "results", "validation_summary.json")).read()[:3000])
shutil.make_archive(REPO + "_results", "zip", REPO, ".")
try:
    from google.colab import files
    files.download(REPO + "_results.zip")
except Exception as exc:
    print("Results archive:", REPO + "_results.zip")
'''


def read(rel):
    s = open(os.path.join(ROOT, rel), encoding='utf-8').read()
    assert "'''" not in s, rel
    if not s.endswith('\n'):
        s += '\n'
    return s


def single_cell():
    parts = [HEADER, '\n# ----------------------------------------------------------------------------- source code (plain text)\n',
             'SOURCE_FILES = {}\n']
    for rel in SOURCES:
        parts.append(f"SOURCE_FILES[{rel!r}] = r'''" + read(rel) + "'''\n\n")
    parts.append(RUNNER)
    return ''.join(parts)


def notebook():
    def md(t): return {'cell_type': 'markdown', 'metadata': {}, 'source': t.splitlines(True)}
    def code(t): return {'cell_type': 'code', 'metadata': {}, 'execution_count': None, 'outputs': [], 'source': t.splitlines(True)}
    cells = [md('# NeuronAI v2.0 in Google Colab\n\nBiophysical EEG digital twins with simulation-based inference for '
                'personalised in silico neuropharmacology.\n\n1. Edit and run the **options** cell (paste the two Mendeley download links).\n'
                '2. Run the **source** cell (writes the code to `/content/NeuronAI`).\n'
                '3. Run the **pipeline** cell.\n'),
             code(HEADER)]
    src = 'SOURCE_FILES = {}\n' + ''.join(f"SOURCE_FILES[{rel!r}] = r'''" + read(rel) + "'''\n\n" for rel in SOURCES)
    cells.append(md('## Source code (plain text; identical to the GitHub repository)'))
    cells.append(code(src))
    cells.append(md('## Pipeline'))
    cells.append(code(RUNNER))
    return {'cells': cells, 'metadata': {'colab': {'provenance': []}, 'kernelspec': {'display_name': 'Python 3', 'name': 'python3'},
                                         'language_info': {'name': 'python'}}, 'nbformat': 4, 'nbformat_minor': 0}


if __name__ == '__main__':
    os.makedirs(os.path.join(ROOT, 'colab'), exist_ok=True)
    os.makedirs(os.path.join(ROOT, 'notebooks'), exist_ok=True)
    open(os.path.join(ROOT, 'colab', 'NeuronAI_v2_Colab_single_cell.py'), 'w', encoding='utf-8').write(single_cell())
    json.dump(notebook(), open(os.path.join(ROOT, 'notebooks', 'NeuronAI_v2_Colab.ipynb'), 'w', encoding='utf-8'), indent=1)
    print('Colab files written')
