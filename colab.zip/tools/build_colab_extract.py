"""Generate a single-cell Google Colab script that downloads the complete Duville et al. EEG datasets
directly from Mendeley Data, runs the NeuronAI preprocessing step (scripts/02) on every recording and
returns a small archive (descriptors, spectra, QC, manifest, metadata) that can be analysed anywhere.

All source code is embedded as plain, readable text."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SOURCES = ['neuronai/__init__.py', 'neuronai/model.py', 'neuronai/features.py', 'neuronai/data.py',
           'neuronai/bank.py', 'neuronai/inference.py', 'neuronai/intervention.py', 'neuronai/stats.py',
           'scripts/02_preprocess_features.py']

HEADER = '''# =============================================================================
# NeuronAI v2.0 - process the COMPLETE Duville et al. datasets in Google Colab
# (the EEG files never pass through your computer).
#
# Mendeley Data protects its pages with a browser check, so the download link
# must be obtained once in your own browser:
#   1. Open https://data.mendeley.com/datasets/7zf99hxxc9/1 (ASD) and click "Download All".
#   2. As soon as the download starts, open the downloads page of your browser
#      (Chrome: chrome://downloads ; Edge: edge://downloads ; Firefox: Ctrl+Shift+Y),
#      right-click the file -> "Copy link address" and paste it below in DIRECT_URLS["ASD"].
#      You can then cancel the download on your computer.
#   3. Repeat with https://data.mendeley.com/datasets/spwnt8t25y/1 (TD) -> DIRECT_URLS["TD"].
#   4. Paste this whole file into ONE Colab cell and press Run. Keep the tab open
#      (about 30-60 min). At the end "NeuronAI_full_cohort_features.zip" (a few MB)
#      is downloaded: that small file is all that is needed for the rest of the analysis.
# The links expire after a while; if the download fails with 403/expired, copy fresh links.
# Alternative: put the two zip files in Google Drive and use MANUAL_ZIPS instead.
# =============================================================================
DIRECT_URLS = {
    "ASD": "",                   # paste the ASD "Download All" link here (between the quotes)
    "TD":  "",                   # paste the TD "Download All" link here
}
MANUAL_ZIPS = {}                 # alternative, e.g. {"ASD": "/content/drive/MyDrive/ASD.zip", "TD": "/content/drive/MyDrive/TD.zip"}
DATASETS = {"ASD": ("7zf99hxxc9", 1), "TD": ("spwnt8t25y", 1)}   # Mendeley identifiers (for the record)
BLOCK = 19                       # recordings per child in sequential numbering (1 rest + 18 task)
SAVE_TO_DRIVE = False            # True: also copy the result zip to Google Drive (MyDrive/NeuronAI)
'''

RUNNER = r'''
# ----------------------------------------------------------------------------- setup
import os, sys, re, json, glob, time, shutil, zipfile, subprocess
import requests
REPO = "/content/NeuronAI"
for rel, src in SOURCE_FILES.items():
    path = os.path.join(REPO, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(src)
OUT = "/content/neuronai_full_cohort"
DATA = "/content/data"
os.makedirs(OUT, exist_ok=True)
EEG_EXT = (".gdf", ".edf", ".bdf", ".set", ".fdt", ".mat")
ARCHIVE_EXT = (".zip",)
API = "https://data.mendeley.com/public-api/datasets"
HEAD = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*"}


def as_list(obj):
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for k in ("results", "files", "items", "data", "folders"):
            if isinstance(obj.get(k), list):
                return obj[k]
    return []


def file_entry(it, folder=""):
    if not isinstance(it, dict):
        return None
    cd = it.get("content_details") or {}
    url = cd.get("download_url") or it.get("download_url")
    if not url:
        return None
    size = int(cd.get("size", 0) or it.get("size", 0) or 0)
    return (folder, it.get("filename") or it.get("name") or "file", size, url)


def list_dataset(ds, ver):
    """Return [(folder_path, filename, size, url)] using the public Mendeley Data API."""
    # 1) dataset record: https://data.mendeley.com/public-api/datasets/<id>  (works without a token)
    for params in ({"version": ver}, {}):
        try:
            r = requests.get(f"{API}/{ds}", params=params, headers=HEAD, timeout=60)
            print(f"  GET {r.url} -> {r.status_code}")
            if r.ok:
                rec = r.json()
                items = [e for e in (file_entry(it) for it in as_list(rec.get("files", rec))) if e]
                if items:
                    return items
                print("  record keys:", list(rec)[:20] if isinstance(rec, dict) else type(rec))
            else:
                print("  ", r.text[:200].replace("\n", " "))
        except Exception as exc:
            print("  dataset record failed:", exc)
    # 2) folder-by-folder listing
    folders = []
    try:
        r = requests.get(f"{API}/{ds}/folders/{ver}", headers=HEAD, timeout=60)
        if r.ok:
            folders = [f for f in as_list(r.json()) if isinstance(f, dict) and "id" in f]
    except Exception as exc:
        print("  folder listing failed:", exc)
    by_id = {f["id"]: f for f in folders}

    def path_of(fid):
        parts = []
        while fid in by_id:
            parts.append(by_id[fid].get("name", ""))
            fid = by_id[fid].get("parent_id")
        return "/".join(reversed(parts))

    out = []
    for fid in ["root"] + list(by_id):
        try:
            r = requests.get(f"{API}/{ds}/files", params={"folder_id": fid, "version": ver}, headers=HEAD, timeout=60)
            print(f"  GET {r.url} -> {r.status_code}")
        except Exception as exc:
            print("  file listing failed:", exc); continue
        if not r.ok:
            continue
        for it in as_list(r.json()):
            url = (it.get("content_details") or {}).get("download_url") or it.get("download_url")
            if url:
                out.append(("" if fid == "root" else path_of(fid), it.get("filename", "file"), int(it.get("size", 0) or 0), url))
    return out


def download(url, dest):
    tmp = dest + ".part"
    for attempt in range(4):
        try:
            with requests.get(url, stream=True, timeout=300, allow_redirects=True, headers={"User-Agent": HEAD["User-Agent"]}) as r:
                r.raise_for_status()
                with open(tmp, "wb") as fh:
                    for chunk in r.iter_content(1 << 20):
                        fh.write(chunk)
            os.replace(tmp, dest)
            return True
        except Exception as exc:
            print(f"    attempt {attempt + 1}: {exc}")
            code = getattr(getattr(exc, "response", None), "status_code", None)
            if code in (401, 403, 404):
                break
            time.sleep(5 * (attempt + 1))
    if os.path.exists(tmp):
        os.remove(tmp)
    return False


def extract_archives(folder):
    for zp in glob.glob(os.path.join(folder, "**", "*.zip"), recursive=True):
        try:
            with zipfile.ZipFile(zp) as zf:
                zf.extractall(os.path.splitext(zp)[0])
            os.remove(zp)
        except Exception as exc:
            print("  could not extract", zp, exc)


def short_name(rel, maxlen=100):
    """Short, unique file name for a relative path (keeps the extension and the last folder)."""
    import hashlib
    parts = rel.replace("\\", "/").split("/")
    base = "__".join(parts[-2:]) if len(parts) > 1 else parts[0]
    stem, ext = os.path.splitext(base)
    h = hashlib.md5(rel.encode()).hexdigest()[:6]
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", stem)[: maxlen - len(ext) - 8]
    return f"{stem}_{h}{ext}"


def prefix_names(folder, grp):
    """Make recording ids unique across groups and folders (EEGLAB .set/.fdt pairs are left untouched)."""
    eeg = [f for f in glob.glob(os.path.join(folder, "**", "*"), recursive=True)
           if f.lower().endswith((".gdf", ".edf", ".bdf", ".mat"))]
    counts = {}
    for f in eeg:
        counts[os.path.basename(f).lower()] = counts.get(os.path.basename(f).lower(), 0) + 1
    renamed = []
    for f in eeg:
        b = os.path.basename(f)
        new = b
        if counts[b.lower()] > 1:                     # same name in several folders: add a folder tag
            tag = re.sub(r"[^A-Za-z0-9]+", "", os.path.basename(os.path.dirname(f)))[:20] or "x"
            new = f"{tag}_{new}"
        if not new.upper().startswith(grp):
            new = f"{grp}_{new}"
        if new != b:
            os.rename(f, os.path.join(os.path.dirname(f), new))
        renamed.append({"group": grp, "original_path": os.path.relpath(f, folder), "recording_id": os.path.splitext(new)[0]})
    return renamed


manifest = []
for grp, (ds, ver) in DATASETS.items():
    dest = os.path.join(DATA, grp)
    os.makedirs(dest, exist_ok=True)
    print(f"\n=== {grp}: Mendeley dataset {ds} v{ver}")
    have = [f for f in glob.glob(os.path.join(dest, "**", "*"), recursive=True) if f.lower().endswith(EEG_EXT[:4])]
    if have:
        print(f"  {len(have)} EEG files already in this Colab session; download skipped")
        continue
    if DIRECT_URLS.get(grp, "").strip():
        zp = os.path.join(DATA, f"{grp}_all.zip")
        print("  downloading the archive from the link provided ...", flush=True)
        t0 = time.time()
        if not download(DIRECT_URLS[grp].strip(), zp):
            raise RuntimeError(f"The {grp} link did not work (it may have expired). Copy a fresh link (see the "
                               "instructions at the top) and run the cell again.")
        print(f"  {os.path.getsize(zp) / 1e9:.2f} GB in {(time.time() - t0) / 60:.1f} min; extracting ...", flush=True)
        with zipfile.ZipFile(zp) as zf:
            zf.extractall(dest)
        os.remove(zp)
        extract_archives(dest)
        manifest.append({"group": grp, "folder": "", "original_name": "Download All archive", "local_name": "",
                         "size": 0})
        continue
    if grp in MANUAL_ZIPS:
        with zipfile.ZipFile(MANUAL_ZIPS[grp]) as zf:
            zf.extractall(dest)
        extract_archives(dest)
        continue
    items = list_dataset(ds, ver)
    if not items:
        raise RuntimeError(f"Mendeley blocked the automatic download of {grp} (browser check). Follow the "
                           "instructions at the top of the cell: copy the 'Download All' link from your browser "
                           "into DIRECT_URLS and run the cell again.")
    total = sum(s for *_, s, _ in items)
    print(f"  {len(items)} files, {total / 1e9:.2f} GB")
    t0 = time.time()
    for k, (fpath, name, size, url) in enumerate(items, 1):
        ext = os.path.splitext(name)[1].lower()
        small_meta = ext not in EEG_EXT + ARCHIVE_EXT and size < 50e6
        if ext not in EEG_EXT + ARCHIVE_EXT and not small_meta:
            continue
        local = name if name.upper().startswith(grp) else f"{grp}_{name}"
        sub = os.path.join(dest, fpath) if ext in ARCHIVE_EXT else (dest if ext in EEG_EXT else os.path.join(OUT, "metadata", grp))
        os.makedirs(sub, exist_ok=True)
        target = os.path.join(sub, local if ext in EEG_EXT else name)
        if not (os.path.exists(target) and (size == 0 or os.path.getsize(target) == size)):
            download(url, target)
        manifest.append({"group": grp, "folder": fpath, "original_name": name, "local_name": os.path.basename(target),
                         "size": size})
        if k % 25 == 0:
            print(f"  {k}/{len(items)} files  ({(time.time() - t0) / 60:.1f} min)", flush=True)
    extract_archives(dest)

import pandas as pd
inventory, id_map = [], []
for grp in DATASETS:
    root = os.path.join(DATA, grp)
    for f in sorted(glob.glob(os.path.join(root, "**", "*"), recursive=True)):
        if not os.path.isfile(f):
            continue
        ext = os.path.splitext(f)[1].lower()
        inventory.append({"group": grp, "original_path": os.path.relpath(f, root), "size": os.path.getsize(f)})
        if ext in (".xlsx", ".xls", ".csv", ".tsv", ".txt", ".json", ".docx", ".pdf", ".md") and os.path.getsize(f) < 50e6:
            mdir = os.path.join(OUT, "metadata", grp)
            os.makedirs(mdir, exist_ok=True)
            shutil.copy(f, os.path.join(mdir, short_name(os.path.relpath(f, root))))
    id_map.extend(prefix_names(root, grp))
pd.DataFrame(id_map).to_csv(os.path.join(OUT, "recording_id_map.csv"), index=False)
pd.DataFrame(inventory).to_csv(os.path.join(OUT, "file_inventory.csv"), index=False)
pd.DataFrame(manifest).to_csv(os.path.join(OUT, "manifest.csv"), index=False)
for grp in DATASETS:
    n = len([p for p in glob.glob(os.path.join(DATA, grp, "**", "*"), recursive=True) if p.lower().endswith(EEG_EXT[:4])])
    print(grp, "EEG files available:", n)
    if n == 0:
        raise RuntimeError(f"No EEG files found for {grp}; see the messages above.")

# ----------------------------------------------------------------------------- preprocessing (scripts/02)
cmd = (f"python scripts/02_preprocess_features.py --asd {DATA}/ASD --td {DATA}/TD --out {OUT} --block {BLOCK}")
print("\n$", cmd, flush=True)
p = subprocess.Popen(cmd, shell=True, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
log = []
for line in p.stdout:
    log.append(line)
    print(line, end="", flush=True)
p.wait()
open(os.path.join(OUT, "preprocess_log.txt"), "w").write("".join(log))
if p.returncode != 0:
    raise RuntimeError("Preprocessing failed; see the log above.")

# ----------------------------------------------------------------------------- package & download
zip_path = shutil.make_archive("/content/NeuronAI_full_cohort_features", "zip", OUT)
print("\nResult:", zip_path, f"({os.path.getsize(zip_path) / 1e6:.1f} MB)")
if SAVE_TO_DRIVE:
    from google.colab import drive
    drive.mount("/content/drive")
    os.makedirs("/content/drive/MyDrive/NeuronAI", exist_ok=True)
    shutil.copy(zip_path, "/content/drive/MyDrive/NeuronAI/")
    print("Copied to MyDrive/NeuronAI/")
try:
    from google.colab import files
    files.download(zip_path)
except Exception:
    pass
'''


def read(rel):
    s = open(os.path.join(ROOT, rel), encoding='utf-8').read()
    assert "'''" not in s, rel
    return s if s.endswith('\n') else s + '\n'


if __name__ == '__main__':
    parts = [HEADER, '\n# ----------------------------------------------------------------------------- source code (plain text)\n',
             'SOURCE_FILES = {}\n']
    for rel in SOURCES:
        parts.append(f"SOURCE_FILES[{rel!r}] = r'''" + read(rel) + "'''\n\n")
    parts.append(RUNNER)
    os.makedirs(os.path.join(ROOT, 'colab'), exist_ok=True)
    out = os.path.join(ROOT, 'colab', 'NeuronAI_download_full_cohort_Colab.py')
    open(out, 'w', encoding='utf-8').write(''.join(parts))
    print('written', out)
