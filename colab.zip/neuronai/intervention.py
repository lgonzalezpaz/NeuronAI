"""
neuronai.intervention
=====================

In silico pharmacological search.

For a subject with observed descriptors x_s and fitted digital twin theta_s,
the post-intervention descriptors under control vector u are predicted with a
residual-preserving (delta) estimator:

    x_hat(u) = x_s + [F(theta_s (+) u) - F(theta_s)]

where F is the forward emulator (search stage) or the full stochastic simulator
averaged over seeds (verification stage). Distance to the normative reference
is the Mahalanobis distance to the typically-developing (TD) feature
distribution (Ledoit-Wolf shrinkage covariance). The search evaluates all
sparse supports of size 1-3 (9 + 36 + 84 = 129 combinations), first on a dense
grid and then by bounded quasi-Newton refinement of the best supports.
"""
from __future__ import annotations

from itertools import combinations
from typing import Dict, List, Optional

import numpy as np
from scipy.optimize import minimize
from sklearn.covariance import LedoitWolf

from .model import CONTROLS, apply_controls, FIT_PARAMS
from .inference import emu_matrix

LAMBDA_L2 = 0.05


class NormativeReference:
    def __init__(self, X_ref: np.ndarray, feature_idx: Optional[List[int]] = None):
        self.idx = feature_idx if feature_idx is not None else list(range(X_ref.shape[1]))
        Xr = X_ref[:, self.idx]
        self.mu = Xr.mean(0)
        self.sd = Xr.std(0, ddof=1)
        lw = LedoitWolf().fit((Xr - self.mu) / self.sd)
        try:
            self.P = np.linalg.inv(lw.covariance_)
        except np.linalg.LinAlgError:                  # degenerate reference (very few recordings)
            self.P = np.linalg.pinv(lw.covariance_)

    def distance(self, X: np.ndarray) -> np.ndarray:
        Z = (np.atleast_2d(X)[:, self.idx] - self.mu) / self.sd
        return np.sqrt(np.einsum('ni,ij,nj->n', Z, self.P, Z))


def all_supports(max_k: int = 3):
    sup = []
    for k in range(1, max_k + 1):
        sup.extend(combinations(range(len(CONTROLS)), k))
    return sup


def _theta_rows(theta_s: Dict[str, float], U: np.ndarray) -> np.ndarray:
    n = U.shape[0]
    th = {k: np.full(n, float(theta_s[k])) for k in FIT_PARAMS}
    return emu_matrix(apply_controls(th, U))


def emulated_post(x_s, theta_s, U, emulator, base_pred=None):
    U = np.atleast_2d(U)
    if base_pred is None:
        base_pred = emulator.predict(_theta_rows(theta_s, np.zeros((1, len(CONTROLS)))))[0]
    return x_s[None, :] + emulator.predict(_theta_rows(theta_s, U)) - base_pred[None, :]


def search(x_s: np.ndarray, theta_s: Dict[str, float], emulator, ref: NormativeReference,
           lam: float = LAMBDA_L2, max_k: int = 3, n_refine: int = 12,
           grid_pts=(41, 21, 9), precomputed=None) -> Dict:
    """Exhaustive sparse search; returns ranked results for all 129 supports.

    precomputed: optional (supports, U_all, owners, delta_grid) to reuse emulator predictions."""
    base_pred = emulator.predict(_theta_rows(theta_s, np.zeros((1, len(CONTROLS)))))[0]
    d0 = float(ref.distance(x_s[None, :])[0])
    if precomputed is None:
        supports, U_all, own = grid_controls(max_k, grid_pts)
        D = ref.distance(emulated_post(x_s, theta_s, U_all, emulator, base_pred))
    else:
        supports, U_all, own, delta_grid = precomputed
        D = ref.distance(x_s[None, :] + delta_grid)
    J = D + lam * (U_all ** 2).sum(1)
    results = []
    for si, sup in enumerate(supports):
        m = own == si
        j = np.argmin(J[m])
        results.append({'support': sup, 'u': U_all[m][j].copy(), 'J': float(J[m][j]), 'D': float(D[m][j])})
    order = np.argsort([r['J'] for r in results])
    for oi in order[:n_refine]:
        r = results[oi]
        sup = list(r['support'])

        def obj(v):
            U = np.zeros((1, len(CONTROLS))); U[0, sup] = v
            d = ref.distance(emulated_post(x_s, theta_s, U, emulator, base_pred))[0]
            return d + lam * float((v ** 2).sum())
        opt = minimize(obj, r['u'][sup], method='L-BFGS-B', bounds=[(-1, 1)] * len(sup),
                       options={'maxiter': 60})
        if opt.fun < r['J']:
            U = np.zeros(len(CONTROLS)); U[sup] = opt.x
            r['u'], r['J'] = U, float(opt.fun)
            r['D'] = float(ref.distance(emulated_post(x_s, theta_s, U[None], emulator, base_pred))[0])
    for r in results:
        r['improvement'] = 100.0 * (d0 - r['D']) / d0
        r['name'] = '+'.join(CONTROLS[i] for i in r['support'])
    results.sort(key=lambda r: r['J'])
    return {'d0': d0, 'results': results, 'base_pred': base_pred}


def grid_controls(max_k: int = 3, grid_pts=(41, 21, 9)):
    supports = all_supports(max_k)
    rows, owners = [], []
    for si, sup in enumerate(supports):
        g = np.linspace(-1, 1, grid_pts[len(sup) - 1])
        mesh = np.stack(np.meshgrid(*([g] * len(sup)), indexing='ij'), -1).reshape(-1, len(sup))
        U = np.zeros((len(mesh), len(CONTROLS)))
        U[:, list(sup)] = mesh
        rows.append(U); owners.append(np.full(len(mesh), si))
    return supports, np.concatenate(rows), np.concatenate(owners)


def grid_rank(x_s, delta_grid, U_all, own, supports, ref, lam=LAMBDA_L2):
    """Rank supports from precomputed emulator changes on the grid (no refinement)."""
    d0 = float(ref.distance(x_s[None])[0])
    D = ref.distance(x_s[None] + delta_grid)
    J = D + lam * (U_all ** 2).sum(1)
    best = []
    for si, sup in enumerate(supports):
        m = own == si
        j = np.argmin(J[m])
        best.append((float(J[m][j]), si, float(D[m][j])))
    best.sort()
    J0, si, D0 = best[0]
    return {'name': '+'.join(CONTROLS[i] for i in supports[si]), 'support': supports[si],
            'improvement': 100 * (d0 - D0) / d0}


def member_deltas(theta_s, emulator, U_all):
    """Per-member emulator changes F_m(theta (+) u) - F_m(theta) on the control grid."""
    X = emulator.xs.transform(_theta_rows(theta_s, U_all))
    X0 = emulator.xs.transform(_theta_rows(theta_s, np.zeros((1, len(CONTROLS)))))
    out = []
    for m in emulator.members:
        out.append(emulator.ys.inverse_transform(m.predict(X)) - emulator.ys.inverse_transform(m.predict(X0)))
    return np.stack(out)   # (members, grid, features)


def random_null(x_s, theta_s, u_star, emulator, ref, n: int = 500, seed: int = 0):
    """Improvements of random control vectors with the same support size and L2 norm as u_star."""
    rng = np.random.default_rng(seed)
    k = int((np.abs(u_star) > 1e-9).sum())
    norm = np.linalg.norm(u_star)
    U = np.zeros((n, len(CONTROLS)))
    for i in range(n):
        sup = rng.choice(len(CONTROLS), size=max(k, 1), replace=False)
        v = rng.standard_normal(len(sup))
        v = v / np.linalg.norm(v) * norm
        U[i, sup] = np.clip(v, -1, 1)
    d0 = ref.distance(x_s[None])[0]
    D = ref.distance(emulated_post(x_s, theta_s, U, emulator))
    return 100.0 * (d0 - D) / d0


# ---------------------------------------------------------------------------
# Simulator-in-the-loop verification (guards against surrogate exploitation)
# ---------------------------------------------------------------------------
def random_like(U_ref: np.ndarray, seed: int = 0) -> np.ndarray:
    """Random control vectors matched one-to-one to U_ref in support size and Euclidean norm."""
    rng = np.random.default_rng(seed)
    out = np.zeros_like(U_ref)
    for i, u in enumerate(U_ref):
        k = max(int((np.abs(u) > 1e-9).sum()), 1)
        norm = np.linalg.norm(u)
        for _ in range(100):
            sup = rng.choice(len(CONTROLS), size=k, replace=False)
            v = rng.standard_normal(k)
            v = v / np.linalg.norm(v) * norm
            if np.all(np.abs(v) <= 1):
                break
        out[i, sup] = np.clip(v, -1, 1)
    return out


def simulate_candidates(theta_s: Dict[str, float], U: np.ndarray, n_streams: int, seed: int,
                        max_rows: int = 200):
    """Simulate the twin under each control vector (rows of U) with n_streams paired noise streams.

    Returns descriptors of shape (n_candidates, n_streams, n_features); stream s receives identical
    noise for every candidate (common random numbers), so differences isolate the intervention."""
    from .model import simulate
    from .features import extract_features, feature_matrix
    n_c = len(U)
    cand = np.repeat(np.arange(n_c), n_streams)
    stream = np.tile(np.arange(n_streams), n_c)
    F = np.empty((len(cand), 9))
    per = max(n_streams, (max_rows // n_streams) * n_streams)
    for s in range(0, len(cand), per):
        sl = slice(s, s + per)
        th = {k: np.full(len(cand[sl]), float(theta_s[k])) for k in FIT_PARAMS}
        r = simulate(th, u=U[cand[sl]], duration=20.0, seed=seed, crn_index=stream[sl])
        F[sl] = feature_matrix(extract_features(r.eeg, r.fs))
    return F.reshape(n_c, n_streams, -1)


def verified_improvement(x_s, F_cand, F_base, ref: NormativeReference):
    """Per-stream and mean improvement (%) of each candidate using residual-preserving deltas."""
    d0 = float(ref.distance(x_s[None])[0])
    delta = F_cand - F_base[None]                       # (cand, streams, feat)
    per = 100 * (d0 - ref.distance((x_s[None, None] + delta).reshape(-1, len(x_s))).reshape(delta.shape[:2])) / d0
    mean = 100 * (d0 - ref.distance(x_s[None] + delta.mean(1))) / d0
    return per, mean, delta
