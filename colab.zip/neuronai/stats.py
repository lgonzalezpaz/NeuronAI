"""neuronai.stats - statistics used throughout the analyses."""
from __future__ import annotations

import numpy as np
from scipy import stats


def bootstrap_ci(x, func=np.mean, n_boot: int = 10000, ci: float = 0.95, seed: int = 0):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(x), (n_boot, len(x)))
    bs = np.array([func(x[i]) for i in idx])
    lo, hi = np.percentile(bs, [100 * (1 - ci) / 2, 100 * (1 + ci) / 2])
    return float(func(x)), float(lo), float(hi)


def hedges_g(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    sp = np.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
    d = (a.mean() - b.mean()) / sp
    return d * (1 - 3 / (4 * (na + nb) - 9))


def hedges_g_ci(a, b, n_boot=5000, seed=0):
    rng = np.random.default_rng(seed)
    a, b = np.asarray(a, float), np.asarray(b, float)
    bs = [hedges_g(rng.choice(a, len(a)), rng.choice(b, len(b))) for _ in range(n_boot)]
    return hedges_g(a, b), *np.percentile(bs, [2.5, 97.5])


def fdr_bh(p):
    p = np.asarray(p, float)
    n = len(p)
    order = np.argsort(p)
    q = np.empty(n)
    prev = 1.0
    for rank, i in enumerate(order[::-1]):
        k = n - rank
        prev = min(prev, p[i] * n / k)
        q[i] = prev
    return q


def icc_2_1(x1, x2):
    """ICC(2,1): two-way random effects, absolute agreement, single measurement."""
    Y = np.column_stack([x1, x2]).astype(float)
    n, k = Y.shape
    gm = Y.mean()
    msr = k * ((Y.mean(1) - gm) ** 2).sum() / (n - 1)
    msc = n * ((Y.mean(0) - gm) ** 2).sum() / (k - 1)
    sse = ((Y - Y.mean(1, keepdims=True) - Y.mean(0, keepdims=True) + gm) ** 2).sum()
    mse = sse / ((n - 1) * (k - 1))
    return (msr - mse) / (msr + (k - 1) * mse + k * (msc - mse) / n)


def icc_ci(x1, x2, n_boot=2000, seed=0):
    rng = np.random.default_rng(seed)
    n = len(x1)
    vals = []
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        vals.append(icc_2_1(np.asarray(x1)[i], np.asarray(x2)[i]))
    return icc_2_1(x1, x2), *np.nanpercentile(vals, [2.5, 97.5])


def spearman(x, y):
    m = np.isfinite(x) & np.isfinite(y)
    r, p = stats.spearmanr(np.asarray(x)[m], np.asarray(y)[m])
    return float(r), float(p), int(m.sum())


def mannwhitney(a, b):
    return stats.mannwhitneyu(a, b, alternative='two-sided')


def cluster_bootstrap_ci(x, clusters, func=np.mean, n_boot: int = 5000, ci: float = 0.95, seed: int = 0):
    """Two-stage (cluster, then within-cluster) bootstrap for nested data
    (recordings nested within children)."""
    x = np.asarray(x, float); clusters = np.asarray(clusters)
    labs = np.unique(clusters)
    groups = [x[clusters == c] for c in labs]
    rng = np.random.default_rng(seed)
    bs = []
    for _ in range(n_boot):
        pick = rng.integers(0, len(groups), len(groups))
        sample = np.concatenate([rng.choice(groups[k], len(groups[k])) for k in pick])
        bs.append(func(sample))
    lo, hi = np.percentile(bs, [100 * (1 - ci) / 2, 100 * (1 + ci) / 2])
    return float(func(x)), float(lo), float(hi)


def child_permutation_test(values, groups, clusters, n_perm: int = 20000, seed: int = 0, max_exact: int = 20000):
    """Permutation test of a group difference at the child (cluster) level.
    Statistic: difference of child-mean averages. All relabellings of children are enumerated when there
    are at most `max_exact` of them (exact test); otherwise `n_perm` random relabellings are used
    (Monte Carlo, p = (1 + #extreme) / (1 + n_perm)). Returns (diff, p_two_sided, n_permutations)."""
    from itertools import combinations
    from math import comb
    v = np.asarray(values, float); g = np.asarray(groups); c = np.asarray(clusters)
    labs = np.unique(c)
    means = np.array([v[c == l].mean() for l in labs])
    lab_group = np.array([g[c == l][0] for l in labs])
    G = np.unique(lab_group)
    in_a = lab_group == G[0]
    obs = means[in_a].mean() - means[~in_a].mean()
    k = int(in_a.sum())
    if comb(len(labs), k) <= max_exact:
        stats_ = []
        for cmb in combinations(range(len(labs)), k):
            m = np.zeros(len(labs), bool); m[list(cmb)] = True
            stats_.append(means[m].mean() - means[~m].mean())
        stats_ = np.array(stats_)
        return float(obs), float((np.abs(stats_) >= abs(obs) - 1e-12).mean()), len(stats_)
    rng = np.random.default_rng(seed)
    ext = 0
    for _ in range(n_perm):
        m = np.zeros(len(labs), bool); m[rng.choice(len(labs), k, replace=False)] = True
        ext += abs(means[m].mean() - means[~m].mean()) >= abs(obs) - 1e-12
    return float(obs), float((1 + ext) / (1 + n_perm)), int(n_perm)


def sign_flip_test(x, n_perm: int = 20000, seed: int = 0, stat=np.mean):
    """One-sample (paired) sign-flip permutation test of H0: distribution symmetric about 0.
    `x` holds one value per independent unit (e.g. per child). Returns (statistic, p_two_sided)."""
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    obs = stat(x)
    rng = np.random.default_rng(seed)
    flips = rng.choice([-1.0, 1.0], size=(n_perm, len(x)))
    null = np.array([stat(f * x) for f in flips])
    return float(obs), float((1 + (np.abs(null) >= abs(obs) - 1e-12).sum()) / (1 + n_perm))


def icc_1(values, clusters):
    """ICC(1) from one-way random-effects ANOVA (unbalanced): share of variance between clusters."""
    v = np.asarray(values, float); c = np.asarray(clusters)
    labs = np.unique(c)
    k_i = np.array([(c == l).sum() for l in labs]); N = len(v); a = len(labs)
    gm = v.mean()
    msb = sum(k * (v[c == l].mean() - gm) ** 2 for k, l in zip(k_i, labs)) / (a - 1)
    msw = sum(((v[c == l] - v[c == l].mean()) ** 2).sum() for l in labs) / (N - a)
    k0 = (N - (k_i ** 2).sum() / N) / (a - 1)
    return float((msb - msw) / (msb + (k0 - 1) * msw))


def _ledoit_wolf_cov(X):
    """Ledoit-Wolf shrunk covariance computed on standardised data and rescaled
    (the procedure of scikit-learn's discriminant_analysis._cov(X, shrinkage='auto'))."""
    sc = X.std(0)
    sc[sc == 0] = 1.0
    Z = (X - X.mean(0)) / sc
    n, p = Z.shape
    S = Z.T @ Z / n
    mu = np.trace(S) / p
    d2 = ((S - mu * np.eye(p)) ** 2).sum()
    Z2 = Z ** 2
    b2 = ((Z2.T @ Z2) / n - S ** 2).sum() / n
    shrink = 0.0 if d2 == 0 else min(b2, d2) / d2
    C = (1 - shrink) * S + shrink * mu * np.eye(p)
    return sc[:, None] * C * sc[None, :]


def _lda_fit_predict(X, y, x_new):
    """Shrinkage linear discriminant, equivalent to scikit-learn's
    LinearDiscriminantAnalysis(solver='lsqr', shrinkage='auto') with empirical priors, implemented
    directly in NumPy (about 50 times faster, which makes leave-one-out permutation tests feasible).
    Returns the predicted label of every row of x_new."""
    labs, inv = np.unique(y, return_inverse=True)
    pri = np.bincount(inv) / len(y)
    means = np.stack([X[inv == k].mean(0) for k in range(len(labs))])
    cov = sum(pri[k] * _ledoit_wolf_cov(X[inv == k]) for k in range(len(labs)))
    coef = np.linalg.lstsq(cov, means.T, rcond=None)[0].T
    icpt = -0.5 * np.einsum('ij,ij->i', means, coef) + np.log(pri)
    return labs[np.argmax(np.atleast_2d(x_new) @ coef.T + icpt, axis=1)]


def identify_discriminant(M, labels, halves=()):
    """Leave-one-recording-out identification of the person behind each recording with a
    shrinkage linear discriminant (Ledoit-Wolf), fitted only on the training recordings of each fold.

    M       (n, p) features of the full recordings (e.g. twin parameters)
    labels  (n,) person labels
    halves  optional sequence of (n, p) arrays with the same features estimated on independent
            halves of each recording; they are added to the training set of each fold only, so
            that the within-person covariance also reflects estimation noise.
    Returns the proportion of correctly identified recordings."""
    import warnings
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    M = np.asarray(M, float); labels = np.asarray(labels)
    n, hits = len(M), 0
    for k in range(n):
        tr = np.arange(n) != k
        X = np.vstack([M[tr]] + [np.asarray(h, float)[tr] for h in halves])
        y = np.concatenate([labels[tr]] * (1 + len(halves)))
        mu, sd = X.mean(0), X.std(0) + 1e-12
        hits += _lda_fit_predict((X - mu) / sd, y, ((M[k] - mu) / sd)[None])[0] == labels[k]
    return hits / n
