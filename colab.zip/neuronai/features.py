"""
neuronai.features
=================

Unit-invariant EEG descriptors shared by simulated and empirical data.

Every feature is invariant to a global rescaling of the signal (microvolts,
volts, or model millivolts give identical values), which removes the
unit-mismatch problem of NeuronAI v1.0.

Features (FEATURE_NAMES):
  rel_delta, rel_theta, rel_alpha, rel_beta              log10 relative power (1-30 Hz)
  iaf                                                    individual alpha frequency (Hz)
  exponent                                               aperiodic 1/f exponent
  plv_alpha, wpli_alpha, kuramoto_alpha                  alpha-band phase synchrony
"""
from __future__ import annotations

from typing import Dict, Tuple

import numpy as np
from scipy.signal import welch, butter, sosfiltfilt, hilbert

BANDS = {'delta': (1.0, 4.0), 'theta': (4.0, 8.0), 'alpha': (8.0, 13.0),
         'beta': (13.0, 30.0)}
FMIN, FMAX = 1.0, 30.0   # fitting range; scalp gamma is dominated by EMG/device noise
FEATURE_NAMES = ['rel_delta', 'rel_theta', 'rel_alpha', 'rel_beta',
                 'iaf', 'exponent', 'plv_alpha', 'wpli_alpha', 'kuramoto_alpha']
FEATURE_LABELS = {
    'rel_delta': r'$\delta$ rel. power', 'rel_theta': r'$\theta$ rel. power',
    'rel_alpha': r'$\alpha$ rel. power', 'rel_beta': r'$\beta$ rel. power',
    'iaf': 'IAF (Hz)',
    'exponent': '1/f exponent', 'plv_alpha': r'PLV$_\alpha$',
    'wpli_alpha': r'wPLI$_\alpha$', 'kuramoto_alpha': r'Kuramoto $r_\alpha$'}


def psd(x: np.ndarray, fs: float, win_sec: float = 2.0) -> Tuple[np.ndarray, np.ndarray]:
    """Welch PSD along the last axis (Hann, 2-s windows, 50 % overlap)."""
    nper = int(round(win_sec * fs))
    f, P = welch(x, fs=fs, nperseg=nper, noverlap=nper // 2, axis=-1, detrend='constant')
    return f, P


def normalised_log_psd(f: np.ndarray, P: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Channel-averaged relative PSD (sums to 1 in 1-45 Hz), log10. Shape (..., n_freq)."""
    sel = (f >= FMIN) & (f <= FMAX)
    Pm = P[..., sel].mean(axis=-2) if P.ndim >= 2 else P[sel]
    Pm = Pm / Pm.sum(axis=-1, keepdims=True)
    return f[sel], np.log10(Pm + 1e-20)


def spectral_features(f: np.ndarray, P: np.ndarray) -> Dict[str, np.ndarray]:
    """P: (..., channels, freqs). Returns dict of arrays with shape (...)."""
    sel = (f >= FMIN) & (f <= FMAX)
    Pm = P.mean(axis=-2)  # average over channels
    tot = Pm[..., sel].sum(axis=-1)
    out = {}
    for name, (lo, hi) in BANDS.items():
        idx = (f >= lo) & (f < hi) if name != 'beta' else (f >= lo) & (f <= hi)
        out['rel_' + name] = np.log10(Pm[..., idx].sum(axis=-1) / tot + 1e-20)
    # individual alpha frequency: centre of gravity in 7-14 Hz
    ia = (f >= 7.0) & (f <= 14.0)
    w = Pm[..., ia]
    out['iaf'] = (w * f[ia]).sum(axis=-1) / w.sum(axis=-1)
    # aperiodic exponent: log-log least-squares fit on 2-6 and 15-30 Hz (excludes the alpha peak)
    fa = ((f >= 2.0) & (f <= 6.0)) | ((f >= 15.0) & (f <= 30.0))
    lx = np.log10(f[fa])
    ly = np.log10(Pm[..., fa] + 1e-30)
    lxm = lx - lx.mean()
    slope = ((ly - ly.mean(axis=-1, keepdims=True)) * lxm).sum(axis=-1) / (lxm ** 2).sum()
    out['exponent'] = -slope
    return out


def phase_sync(x: np.ndarray, fs: float, band=(8.0, 13.0), trim_sec: float = 0.5) -> Dict[str, np.ndarray]:
    """Alpha-band PLV, debiased wPLI and Kuramoto order parameter.

    x : (..., channels, samples).  Returns arrays of shape (...).
    PLV and wPLI are averaged over all channel pairs; the Kuramoto order
    parameter r(t) = |mean_k exp(i phi_k(t))| is averaged over time.
    """
    sos = butter(4, band, btype='band', fs=fs, output='sos')
    xf = sosfiltfilt(sos, x, axis=-1)
    trim = int(trim_sec * fs)
    z = hilbert(xf, axis=-1)[..., trim:-trim]
    ph = np.exp(1j * np.angle(z))
    n_ch = x.shape[-2]
    iu = np.triu_indices(n_ch, 1)
    # PLV via phase-normalised cross products
    T = ph.shape[-1]
    cross = np.einsum('...it,...jt->...ij', ph, ph.conj()) / T
    plv = np.abs(cross)[..., iu[0], iu[1]].mean(axis=-1)
    # debiased weighted phase-lag index (Vinck et al., 2011) on analytic cross-spectra
    zi = z[..., :, None, :]
    zj = z[..., None, :, :]
    # memory-light computation pair by pair
    wpli_vals = []
    for i, j in zip(*iu):
        im = np.imag(z[..., i, :] * np.conj(z[..., j, :]))
        s = im.sum(axis=-1)
        sa = np.abs(im).sum(axis=-1)
        s2 = (im ** 2).sum(axis=-1)
        num = s ** 2 - s2
        den = sa ** 2 - s2
        wpli_vals.append(np.where(den > 0, num / np.maximum(den, 1e-30), 0.0))
    del zi, zj
    wpli = np.mean(np.stack(wpli_vals, axis=-1), axis=-1)
    r = np.abs(ph.mean(axis=-2)).mean(axis=-1)
    return {'plv_alpha': plv, 'wpli_alpha': wpli, 'kuramoto_alpha': r}


def extract_features(x: np.ndarray, fs: float) -> Dict[str, np.ndarray]:
    """Full feature dictionary for x of shape (..., channels, samples)."""
    f, P = psd(x, fs)
    feats = spectral_features(f, P)
    feats.update(phase_sync(x, fs))
    return feats


def feature_matrix(feats: Dict[str, np.ndarray]) -> np.ndarray:
    return np.stack([np.atleast_1d(feats[k]) for k in FEATURE_NAMES], axis=-1)
