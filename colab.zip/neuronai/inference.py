"""
neuronai.inference
==================

NeuronAI learning components (scikit-learn only, CPU, bit-wise reproducible):

* ``InverseEnsemble`` - amortised simulation-based inference. A deep ensemble of
  multilayer perceptrons maps the 10 EEG descriptors to the 8 subject-level
  physiological parameters (unit-cube scale). Split-conformal calibration on a
  held-out set of simulations yields distribution-free prediction intervals
  with guaranteed marginal coverage (Vovk et al., 2005; Angelopoulos & Bates, 2023).

* ``ForwardEmulator`` - a deep-ensemble surrogate of the simulator that maps the
  physiological parameters (+ neuromodulatory nuisance parameters) to the
  expected EEG descriptors; used for fast intervention search, after which
  every candidate is re-verified with the full stochastic simulator.
"""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score

from .model import FIT_PARAMS, FIT_BOUNDS
from .bank import EMU_EXTRA


class InverseEnsemble:
    def __init__(self, n_members: int = 5, hidden=(256, 128, 64), alpha: float = 1e-4,
                 seed: int = 2026, max_iter: int = 600):
        self.n_members, self.hidden, self.alpha = n_members, hidden, alpha
        self.seed, self.max_iter = seed, max_iter
        self.members = []
        self.scaler = StandardScaler()
        self.q = None

    def fit(self, X: np.ndarray, Z: np.ndarray, X_cal: Optional[np.ndarray] = None,
            Z_cal: Optional[np.ndarray] = None, coverage: float = 0.90):
        Xs = self.scaler.fit_transform(X)
        self.members = []
        for m in range(self.n_members):
            net = MLPRegressor(hidden_layer_sizes=self.hidden, activation='relu', alpha=self.alpha,
                               learning_rate_init=1e-3, batch_size=128, max_iter=self.max_iter,
                               early_stopping=True, validation_fraction=0.1, n_iter_no_change=25,
                               random_state=self.seed + m)
            net.fit(Xs, Z)
            self.members.append(net)
        if X_cal is not None:
            self.calibrate(X_cal, Z_cal, coverage)
        return self

    def predict(self, X: np.ndarray, return_members: bool = False):
        Xs = self.scaler.transform(np.atleast_2d(X))
        P = np.stack([np.clip(m.predict(Xs), 0, 1) for m in self.members])
        return (P.mean(0), P) if return_members else P.mean(0)

    def calibrate(self, X_cal, Z_cal, coverage=0.90):
        """Split-conformal absolute-residual quantiles per parameter."""
        pred = self.predict(X_cal)
        res = np.abs(pred - Z_cal)
        n = len(res)
        level = min(1.0, np.ceil((n + 1) * coverage) / n)
        self.q = np.quantile(res, level, axis=0, method='higher')
        self.coverage = coverage
        return self.q

    def interval(self, X):
        mu = self.predict(X)
        return np.clip(mu - self.q, 0, 1), np.clip(mu + self.q, 0, 1)

    def score(self, X, Z) -> Dict[str, float]:
        pred = self.predict(X)
        return {n: r2_score(Z[:, i], pred[:, i]) for i, n in enumerate(FIT_PARAMS)}


EMU_INPUTS = list(FIT_PARAMS) + list(EMU_EXTRA.keys())


def emu_matrix(theta: Dict[str, np.ndarray]) -> np.ndarray:
    th = {k: np.atleast_1d(np.asarray(v, float)) for k, v in theta.items()}
    n = max(len(v) for v in th.values())
    th.setdefault('dv0', np.zeros(n))
    th.setdefault('rscale', np.ones(n))
    cols = []
    for k in EMU_INPUTS:
        lo, hi = FIT_BOUNDS.get(k, EMU_EXTRA.get(k))
        # allow controlled extrapolation beyond the prior box (e.g. +30 % gains)
        cols.append((np.broadcast_to(th[k], (n,)) - lo) / (hi - lo))
    return np.stack(cols, axis=1)


class ForwardEmulator:
    def __init__(self, n_members: int = 5, hidden=(256, 256, 128), alpha: float = 1e-4,
                 seed: int = 7, max_iter: int = 800):
        self.n_members, self.hidden, self.alpha = n_members, hidden, alpha
        self.seed, self.max_iter = seed, max_iter
        self.members, self.xs, self.ys = [], StandardScaler(), StandardScaler()

    def fit(self, Theta_unit: np.ndarray, Y: np.ndarray):
        Xs = self.xs.fit_transform(Theta_unit)
        Ys = self.ys.fit_transform(Y)
        self.members = []
        for m in range(self.n_members):
            net = MLPRegressor(hidden_layer_sizes=self.hidden, activation='relu', alpha=self.alpha,
                               learning_rate_init=1e-3, batch_size=128, max_iter=self.max_iter,
                               early_stopping=True, validation_fraction=0.1, n_iter_no_change=25,
                               random_state=self.seed + m)
            net.fit(Xs, Ys)
            self.members.append(net)
        return self

    def predict(self, Theta_unit: np.ndarray, return_std: bool = False):
        Xs = self.xs.transform(np.atleast_2d(Theta_unit))
        P = np.stack([self.ys.inverse_transform(m.predict(Xs)) for m in self.members])
        return (P.mean(0), P.std(0)) if return_std else P.mean(0)

    def score(self, Theta_unit, Y, names: Sequence[str]) -> Dict[str, float]:
        P = self.predict(Theta_unit)
        return {n: r2_score(Y[:, i], P[:, i]) for i, n in enumerate(names)}


class SpectralEmulator(ForwardEmulator):
    """Emulator of the full 1-30 Hz relative log-spectrum (59 bins) through a PCA bottleneck."""

    def __init__(self, n_components: int = 12, **kw):
        super().__init__(**kw)
        self.n_components = n_components

    def fit(self, Theta_unit, LP):
        from sklearn.decomposition import PCA
        self.pca = PCA(self.n_components, random_state=0).fit(LP)
        super().fit(Theta_unit, self.pca.transform(LP))
        return self

    def predict(self, Theta_unit, return_std=False):
        P = super().predict(Theta_unit)
        return self.pca.inverse_transform(P)


def _mlp_forward_grad(net, x):
    """Forward pass of a fitted scikit-learn ReLU MLPRegressor with the Jacobian w.r.t. its input."""
    a = x
    J = np.eye(len(x))
    for li, (W, b) in enumerate(zip(net.coefs_, net.intercepts_)):
        h = a @ W + b
        J = J @ W
        if li < len(net.coefs_) - 1:
            mask = (h > 0).astype(float)
            a = h * mask
            J = J * mask[None, :]
        else:
            a = h
    return a, J


def emulator_value_grad(emulator, u_in):
    """Ensemble-mean emulator prediction and Jacobian (n_features x n_inputs) in original units."""
    xs, ys = emulator.xs, emulator.ys
    x = (u_in - xs.mean_) / xs.scale_
    preds, jacs = [], []
    for m in emulator.members:
        a, J = _mlp_forward_grad(m, x)
        preds.append(a); jacs.append(J)
    P = np.mean(preds, 0) * ys.scale_ + ys.mean_
    Jm = (np.mean(jacs, 0) / xs.scale_[:, None]) * ys.scale_[None, :]   # d pred / d u_in  (inputs x outputs)
    if hasattr(emulator, 'pca'):
        P = P @ emulator.pca.components_ + emulator.pca.mean_
        Jm = Jm @ emulator.pca.components_
    return P, Jm.T


def refine_twin(x: np.ndarray, emulator: 'ForwardEmulator', z_starts: np.ndarray, scale: np.ndarray,
                lo: Optional[np.ndarray] = None, hi: Optional[np.ndarray] = None,
                spectrum: Optional[np.ndarray] = None, spec_emulator: Optional['SpectralEmulator'] = None,
                spec_scale: Optional[np.ndarray] = None):
    """Posterior-mode refinement of a digital twin.

    Minimises the standardised discrepancy between emulated and observed data,
        L(z) = sum_j ((F_j(z) - x_j) / s_j)^2  +  (9 / n_f) * sum_f ((S_f(z) - y_f) / t_f)^2,
    i.e. the nine descriptors plus (optionally) the full relative log-spectrum y, the spectral block
    being weighted as much as the descriptor block. z is restricted to [lo, hi] (the split-conformal
    interval of the amortised estimate); L-BFGS-B with exact emulator gradients and several starts.
    Neuromodulatory nuisance inputs are held at baseline (unit-scale value 0.5)."""
    from scipy.optimize import minimize
    P = len(FIT_PARAMS)
    lo = np.zeros(P) if lo is None else np.asarray(lo)
    hi = np.ones(P) if hi is None else np.asarray(hi)
    extra = np.array([0.5, 0.5])
    use_spec = spectrum is not None and spec_emulator is not None
    w_spec = 9.0 / len(spectrum) if use_spec else 0.0

    def f(z):
        u = np.concatenate([z, extra])
        pred, J = emulator_value_grad(emulator, u)
        r = (pred - x) / scale
        val = float((r ** 2).sum())
        g = (2 * (r / scale) @ J)[:P]
        if use_spec:
            sp, Js = emulator_value_grad(spec_emulator, u)
            rs = (sp - spectrum) / spec_scale
            val += w_spec * float((rs ** 2).sum())
            g = g + w_spec * (2 * (rs / spec_scale) @ Js)[:P]
        return val, g
    best = None
    for z0 in np.atleast_2d(z_starts):
        z0 = np.clip(z0, lo, hi)
        res = minimize(f, z0, jac=True, method='L-BFGS-B', bounds=list(zip(lo, hi)), options={'maxiter': 300})
        if best is None or res.fun < best.fun:
            best = res
    return best.x, float(best.fun)
