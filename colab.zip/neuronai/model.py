"""
neuronai.model
==============

Multi-column extension of the Wendling et al. (2002) neural mass model with

* differentiated glutamatergic transmission (AMPA, NMDA-GluN2A, NMDA-GluN2B),
  including a voltage-dependent Mg2+ block (Jahr & Stevens, 1990);
* NMDA drive onto fast (somatic-targeting, PV-like) interneurons;
* neuromodulatory gain control (dopamine, serotonin, noradrenaline) implemented
  as explicit, bounded transformations of the physiological parameters;
* a network of N cortical columns placed under the EEG electrodes, coupled
  through distance-dependent long-range excitatory connections, and observed
  through a fixed volume-conduction (spatial mixing) operator.

All post-synaptic potential (PSP) kernels are second-order linear filters
h(t) = H k t exp(-k t).  They are integrated with the *exact* discretisation of
the linear part under a zero-order hold on the input (exponential integrator),
which is unconditionally stable for the fast GABA_A kernel (g = 500 s^-1).

The simulator is vectorised over a batch of parameter sets, so thousands of
simulations can be generated efficiently with NumPy only (Colab-compatible).
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, Optional, Sequence

import numpy as np
from scipy.linalg import expm
from scipy.signal import decimate

# --------------------------------------------------------------------------
# Montage: the 17 electrodes shared by the two acquisition systems
# --------------------------------------------------------------------------
EEG_CHANNELS = ['Fp1', 'Fp2', 'F7', 'F3', 'Fz', 'F4', 'F8', 'T7', 'C3', 'Cz',
                'C4', 'T8', 'P7', 'P3', 'Pz', 'P4', 'P8']

_RAW_POS = {
    'Fp1': (-0.309, 0.951, 0.0), 'Fp2': (0.309, 0.951, 0.0),
    'F7': (-0.809, 0.588, 0.0), 'F3': (-0.50, 0.67, 0.55),
    'Fz': (0.0, 0.719, 0.695), 'F4': (0.50, 0.67, 0.55),
    'F8': (0.809, 0.588, 0.0), 'T7': (-1.0, 0.0, 0.0),
    'C3': (-0.719, 0.0, 0.695), 'Cz': (0.0, 0.0, 1.0),
    'C4': (0.719, 0.0, 0.695), 'T8': (1.0, 0.0, 0.0),
    'P7': (-0.809, -0.588, 0.0), 'P3': (-0.50, -0.67, 0.55),
    'Pz': (0.0, -0.719, 0.695), 'P4': (0.50, -0.67, 0.55),
    'P8': (0.809, -0.588, 0.0)}


def electrode_positions(channels: Sequence[str] = EEG_CHANNELS) -> np.ndarray:
    """Approximate unit-sphere coordinates of 10-20 electrodes."""
    pos = np.array([_RAW_POS[c] for c in channels], dtype=float)
    return pos / np.linalg.norm(pos, axis=1, keepdims=True)


def connectivity_matrices(channels: Sequence[str] = EEG_CHANNELS,
                          coupling_length: float = 0.5,
                          mixing_width: float = 0.30):
    """Return (W, M): row-normalised long-range coupling and volume-conduction mixing."""
    pos = electrode_positions(channels)
    d = np.linalg.norm(pos[:, None, :] - pos[None, :, :], axis=-1)
    W = np.exp(-d / coupling_length)
    np.fill_diagonal(W, 0.0)
    W /= W.sum(axis=1, keepdims=True)
    M = np.exp(-d ** 2 / (2.0 * mixing_width ** 2))
    M /= M.sum(axis=1, keepdims=True)
    return W, M


# --------------------------------------------------------------------------
# Parameters
# --------------------------------------------------------------------------
# Subject-level (fitted) physiological parameters and their prior bounds.
FIT_PARAMS = ['A', 'B', 'G', 'N', 'f2B', 'p', 'K', 'sigma', 'rho']
FIT_BOUNDS = {
    'A': (2.6, 4.6),      # mV, AMPA (fast excitatory) PSP gain
    'B': (10.0, 50.0),    # mV, slow dendritic inhibitory PSP gain
    'G': (5.0, 40.0),     # mV, fast somatic (GABA_A) inhibitory PSP gain
    'N': (0.0, 3.0),      # mV, total NMDA PSP gain on pyramidal cells
    'f2B': (0.0, 1.0),    # fraction of NMDA current carried by GluN2B
    'p': (60.0, 260.0),   # s^-1, mean extrinsic (thalamo-cortical) drive
    'K': (0.0, 1.5),      # long-range glutamatergic coupling strength
    'sigma': (10.0, 60.0),  # s^-1, s.d. of the stochastic drive
    'rho': (0.0, 0.95),   # fraction of drive variance carried by slow (OU, tau = 0.5 s) fluctuations
}
FIT_LABELS = {
    'A': 'AMPA gain $A$', 'B': 'Slow inhibition $B$', 'G': 'Fast GABA$_A$ $G$',
    'N': 'NMDA gain $N$', 'f2B': 'GluN2B fraction $f_{2B}$',
    'p': 'Tonic drive $\\bar p$', 'K': 'Coupling $K$', 'sigma': 'Noise $\\sigma$',
    'rho': 'Slow-input fraction $\\rho$'}


@dataclass
class ModelConstants:
    """Fixed constants (Jansen & Rit, 1995; Wendling et al., 2002)."""
    a: float = 100.0      # s^-1, AMPA rate
    b: float = 50.0       # s^-1, slow inhibitory rate
    g: float = 500.0      # s^-1, fast inhibitory rate
    a2A: float = 1.0 / 0.050   # s^-1, GluN2A (tau ~ 50 ms)
    a2B: float = 1.0 / 0.250   # s^-1, GluN2B (tau ~ 250 ms)
    C: float = 135.0
    e0: float = 2.5
    v0: float = 6.0
    r: float = 0.56
    mg: float = 1.0       # mM extracellular Mg2+
    v_rest: float = -65.0  # mV
    NI_ratio: float = 0.5  # NMDA gain on fast interneurons relative to N
    coupling_scale: float = 50.0
    tau_slow: float = 0.5   # s, correlation time of the slow input component
    mixing_width: float = 0.50
    fs_sim: float = 1000.0
    fs_out: float = 250.0


# Pharmacological control knobs (u in [-1, 1]; +1 = maximal agonism/potentiation)
CONTROLS = ['GABA_A', 'GABA_slow', 'AMPA', 'NMDA_2A', 'NMDA_2B',
            'Drive', 'DA', '5HT', 'NE']
CONTROL_LABELS = {
    'GABA_A': 'GABA$_A$ (fast)', 'GABA_slow': 'Slow/dendritic GABA',
    'AMPA': 'AMPA', 'NMDA_2A': 'NMDA-GluN2A', 'NMDA_2B': 'NMDA-GluN2B',
    'Drive': 'Tonic drive', 'DA': 'Dopamine (D1)', '5HT': 'Serotonin (5-HT$_{2A}$)',
    'NE': 'Noradrenaline'}
MAX_REL_CHANGE = 0.30   # +/-30 % maximal change of a receptor gain


def apply_controls(theta: Dict[str, np.ndarray], u: Optional[np.ndarray]) -> Dict[str, np.ndarray]:
    """Map pharmacological controls u (..., 9) onto physiological parameters.

    Receptor-level knobs scale the corresponding gain by (1 + 0.3 u).
    Neuromodulators act through documented gain-control mechanisms:

    * DA (D1-like): potentiates NMDA currents in pyramidal cells (+20 %) and
      increases fast-spiking interneuron excitability (+10 % G)
      (Seamans & Yang, 2004; Gorelova et al., 2002).
    * 5-HT (5-HT2A): depolarises pyramidal neurons, i.e. lowers the firing
      threshold v0 by up to 1 mV, and recruits fast interneurons (+5 % G)
      (Aghajanian & Marek, 1997; Puig & Gulledge, 2011).
    * NE: increases the slope (gain) of the firing-rate function by up to 15 %
      and reduces the stochastic drive by up to 20 % (signal-to-noise
      enhancement; Servan-Schreiber et al., 1990; Aston-Jones & Cohen, 2005).
    """
    out = {k: np.asarray(v, dtype=float).copy() for k, v in theta.items()}
    out.setdefault('dv0', np.zeros_like(out['A']))
    out.setdefault('rscale', np.ones_like(out['A']))
    if u is None:
        return out
    u = np.atleast_2d(np.asarray(u, dtype=float))
    u = np.clip(u, -1.0, 1.0)
    shp = out['A'].shape
    col = lambda i: u[:, i].reshape(shp) if u.shape[0] == np.prod(shp) else u[0, i] * np.ones(shp)
    m = MAX_REL_CHANGE
    out['G'] = out['G'] * (1 + m * col(0)) * (1 + 0.10 * col(6)) * (1 + 0.05 * col(7))
    out['B'] = out['B'] * (1 + m * col(1))
    out['A'] = out['A'] * (1 + m * col(2))
    n2a = out['N'] * (1 - out['f2B']) * (1 + m * col(3))
    n2b = out['N'] * out['f2B'] * (1 + m * col(4))
    n2a = n2a * (1 + 0.20 * col(6))
    n2b = n2b * (1 + 0.20 * col(6))
    out['N'] = n2a + n2b
    out['f2B'] = np.where(out['N'] > 0, n2b / np.maximum(out['N'], 1e-12), out['f2B'])
    out['p'] = out['p'] * (1 + m * col(5))
    out['dv0'] = out['dv0'] - 1.0 * col(7)
    out['rscale'] = out['rscale'] * (1 + 0.15 * col(8))
    out['sigma'] = out['sigma'] * (1 - 0.20 * col(8))
    return out


def _psp_discretisation(k: float, dt: float):
    """Exact ZOH discretisation of y'' = k*x - 2k y' - k^2 y (unit gain)."""
    Am = np.array([[0.0, 1.0], [-k * k, -2.0 * k]])
    Bm = np.array([[0.0], [k]])
    Mx = np.zeros((3, 3))
    Mx[:2, :2] = Am
    Mx[:2, 2:] = Bm
    E = expm(Mx * dt)
    return E[:2, :2], E[:2, 2]


def _psp_discretisation_vec(k: np.ndarray, dt: float):
    """Closed-form exact ZOH discretisation for an array of rate constants k (B,1)."""
    e = np.exp(-k * dt)
    P = ((1 + k * dt) * e, dt * e, -k * k * dt * e, (1 - k * dt) * e)
    Gv = ((1 - e * (1 + k * dt)) / k, k * dt * e)
    return P, Gv


def params_from_unit(z: np.ndarray, names: Sequence[str] = FIT_PARAMS) -> Dict[str, np.ndarray]:
    """Convert unit-cube coordinates (..., P) into a parameter dictionary."""
    z = np.atleast_2d(z)
    return {n: FIT_BOUNDS[n][0] + z[:, i] * (FIT_BOUNDS[n][1] - FIT_BOUNDS[n][0])
            for i, n in enumerate(names)}


def params_to_unit(theta: Dict[str, np.ndarray], names: Sequence[str] = FIT_PARAMS) -> np.ndarray:
    cols = [(np.asarray(theta[n], float) - FIT_BOUNDS[n][0]) /
            (FIT_BOUNDS[n][1] - FIT_BOUNDS[n][0]) for n in names]
    return np.stack(cols, axis=-1)


DEFAULT_THETA = {'A': 3.5, 'B': 30.0, 'G': 20.0, 'N': 1.0, 'f2B': 0.4,
                 'p': 140.0, 'K': 0.3, 'sigma': 30.0, 'rho': 0.5}


@dataclass
class SimulationResult:
    eeg: np.ndarray            # (batch, channels, samples) sensor-level, common-average referenced
    fs: float
    channels: list = field(default_factory=lambda: list(EEG_CHANNELS))


def simulate(theta: Dict[str, np.ndarray], u: Optional[np.ndarray] = None,
             duration: float = 20.0, transient: float = 2.0, seed: int = 0,
             const: ModelConstants = ModelConstants(),
             channels: Sequence[str] = EEG_CHANNELS,
             return_sources: bool = False, crn_index: Optional[np.ndarray] = None) -> SimulationResult:
    """Simulate a batch of networks of extended Wendling columns.

    Parameters
    ----------
    theta : dict of arrays of shape (batch,) (scalars are broadcast).
    u : optional (batch, 9) array of pharmacological controls in [-1, 1].
    duration : seconds of retained signal; transient : discarded warm-up.
    seed : seed of the dedicated NumPy Generator (bit-wise reproducible).
    crn_index : optional integer array (batch,) assigning each row to a noise stream; rows that
        share an index receive identical noise (common random numbers for paired comparisons).
    """
    th = {k: np.atleast_1d(np.asarray(v, dtype=float)) for k, v in theta.items()}
    bsz = max(v.shape[0] for v in th.values())
    th = {k: np.broadcast_to(v, (bsz,)).copy() for k, v in th.items()}
    th = apply_controls(th, u)
    rng = np.random.default_rng(seed)
    c = const
    dt = 1.0 / c.fs_sim
    n_ch = len(channels)
    W, Mmix = connectivity_matrices(channels, mixing_width=c.mixing_width)

    col = lambda x: x[:, None]  # (B,) -> (B,1) broadcast over columns
    A, B, G = col(th['A']), col(th['B']), col(th['G'])
    N2A = col(th['N'] * (1.0 - th['f2B']))
    N2B = col(th['N'] * th['f2B'])
    NI = col(th['N'] * c.NI_ratio * th.get('NI_scale', np.ones(bsz)))   # NMDA on fast interneurons
    pbar, sig, K = col(th['p']), col(th['sigma']), col(th['K'])
    rho = col(th.get('rho', np.full(bsz, DEFAULT_THETA['rho'])))
    sw, ss = sig * np.sqrt(1.0 - rho), sig * np.sqrt(rho)   # white / slow s.d.
    phi = np.exp(-dt / c.tau_slow)
    sq = np.sqrt(1.0 - phi ** 2)
    v0p = c.v0 + col(th['dv0'])
    rr = c.r * col(th['rscale'])
    C1, C2, C3, C4 = c.C, 0.8 * c.C, 0.25 * c.C, 0.25 * c.C
    C5, C6, C7 = 0.3 * c.C, 0.1 * c.C, 0.8 * c.C
    two_e0 = 2.0 * c.e0

    def S(v, v0=c.v0):
        return two_e0 / (1.0 + np.exp(rr * (v0 - v)))

    Pa, Ga_ = _psp_discretisation(c.a, dt)
    Pb, Gb_ = _psp_discretisation(c.b, dt)
    g_tau = col(th['g_tau']) if 'g_tau' in th else np.ones((bsz, 1))
    Pg_v, Gg_v = _psp_discretisation_vec(c.g / g_tau, dt)   # GABA_A decay prolongation (g_tau > 1)
    P2a, G2a_ = _psp_discretisation(c.a2A, dt)
    P2b, G2b_ = _psp_discretisation(c.a2B, dt)

    shape = (bsz, n_ch)
    # state: (value, derivative) for each PSP
    y0 = np.zeros(shape); z0 = np.zeros(shape)   # pyramidal -> interneurons (AMPA)
    y1 = np.zeros(shape); z1 = np.zeros(shape)   # excitatory input to pyramidal (AMPA)
    y2 = np.zeros(shape); z2 = np.zeros(shape)   # slow dendritic inhibition
    y3 = np.zeros(shape); z3 = np.zeros(shape)   # fast somatic inhibition
    y4 = np.zeros(shape); z4 = np.zeros(shape)   # slow -> fast inhibition
    na = np.zeros(shape); za = np.zeros(shape)   # NMDA GluN2A on pyramidal
    nb = np.zeros(shape); zb = np.zeros(shape)   # NMDA GluN2B on pyramidal
    ni = np.zeros(shape); zi = np.zeros(shape)   # NMDA on fast interneurons
    if crn_index is not None:
        crn_index = np.asarray(crn_index, int)
        n_streams = int(crn_index.max()) + 1
        draw = lambda: rng.standard_normal((n_streams, n_ch))[crn_index]
    else:
        draw = lambda: rng.standard_normal(shape)
    eta = draw()                                  # slow OU input (unit variance)

    n_tr = int(round(transient * c.fs_sim))
    n_keep = int(round(duration * c.fs_sim))
    out = np.empty((bsz, n_ch, n_keep), dtype=np.float32)
    mg_k = c.mg / 3.57

    def step(y, z, P, Gv, inp):
        return P[0, 0] * y + P[0, 1] * z + Gv[0] * inp, P[1, 0] * y + P[1, 1] * z + Gv[1] * inp

    for it in range(n_tr + n_keep):
        vp = y1 + na + nb - y2 - y3
        Sp = S(vp, v0p)
        Se = S(C1 * y0)
        Ss = S(C3 * y0)
        Sf = S(C5 * y0 - C6 * y4 + C5 * ni)
        mgb = 1.0 / (1.0 + mg_k * np.exp(-0.062 * (c.v_rest + vp)))
        eta = phi * eta + sq * draw()
        drive = pbar + sw * draw() + ss * eta + K * c.coupling_scale * (Sp @ W.T)
        exc = C2 * Se
        y0, z0 = step(y0, z0, Pa, Ga_, A * Sp)
        y1, z1 = step(y1, z1, Pa, Ga_, A * (drive + exc))
        y2, z2 = step(y2, z2, Pb, Gb_, B * C4 * Ss)
        inp3 = G * C7 * Sf
        y3, z3 = (Pg_v[0] * y3 + Pg_v[1] * z3 + Gg_v[0] * inp3, Pg_v[2] * y3 + Pg_v[3] * z3 + Gg_v[1] * inp3)
        y4, z4 = step(y4, z4, Pb, Gb_, B * Ss)
        na, za = step(na, za, P2a, G2a_, N2A * mgb * exc * 0.1)
        nb, zb = step(nb, zb, P2b, G2b_, N2B * mgb * exc * 0.1)
        ni, zi = step(ni, zi, P2a, G2a_, NI * Sp)
        if it >= n_tr:
            out[:, :, it - n_tr] = vp
    if return_sources:
        src = out.copy()
    # volume conduction + common average reference
    sens = np.einsum('ij,bjt->bit', Mmix, out)
    sens -= sens.mean(axis=1, keepdims=True)
    sens -= sens.mean(axis=2, keepdims=True)
    q = int(round(c.fs_sim / c.fs_out))
    sens = decimate(sens, q, ftype='fir', axis=-1, zero_phase=True).astype(np.float32)
    res = SimulationResult(eeg=sens, fs=c.fs_out, channels=list(channels))
    if return_sources:
        res.sources = src
    return res


def theta_dict(**kw) -> Dict[str, float]:
    d = dict(DEFAULT_THETA)
    d.update(kw)
    return d
