"""
neuronai.data
=============

Dependency-light loaders and a fully specified preprocessing pipeline for
scalp EEG (EEGLAB .set/.fdt, EDF/BDF, MATLAB .mat, CSV/TXT).  MNE is used when
available (e.g. on Google Colab) but is not required.

Pipeline (identical for every recording, unit-invariant):
 1. channel selection (17 electrodes common to both montages; legacy names
    T3/T4/T5/T6 mapped to T7/T8/P7/P8);
 2. polyphase resampling to 250 Hz;
 3. zero-phase 1-45 Hz band-pass (4th-order Butterworth, second-order sections),
    60 Hz notch (Mexican mains frequency) and automatic notching of narrowband
    instrumental lines (>= 8 dB above the local spectrum, <= 0.5 Hz wide);
 4. bad-channel detection (robust z of log-variance > 4, or flat) and
    distance-weighted spatial interpolation;
 5. common average reference;
 6. 2-s epoching and rejection of epochs whose log-variance or peak-to-peak
    amplitude is a robust outlier (> median + 3.5 MAD);
 7. concatenation of the clean epochs into 20-s analysis windows.
"""
from __future__ import annotations

import os
import re
import struct
from math import gcd
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.io import loadmat
from scipy.signal import resample_poly, butter, sosfiltfilt, iirnotch, filtfilt

from .model import EEG_CHANNELS, electrode_positions

FS_TARGET = 250.0
MAX_BAD = 4            # maximum number of interpolated channels (of 17)
MAX_MEDCORR = 0.95     # reference-failure threshold
MIN_CLEAN_SEC = 60.0   # minimum clean data retained
ALIASES = {'T3': 'T7', 'T4': 'T8', 'T5': 'P7', 'T6': 'P8'}


def _norm_name(ch: str) -> str:
    c = re.sub(r'^(EEG[\s_-]*)', '', str(ch).strip(), flags=re.I)
    c = re.sub(r'[-_](REF|LE|A1|A2|M1|M2|AVG|CZ)$', '', c, flags=re.I)
    c = c.strip()
    for std in EEG_CHANNELS + list(ALIASES.keys()):
        if c.lower() == std.lower():
            return ALIASES.get(std, std)
    return c


# ----------------------------------------------------------------------------
# Readers
# ----------------------------------------------------------------------------
def read_edf(path: str) -> Tuple[np.ndarray, float, List[str]]:
    """Minimal EDF/EDF+ reader (16-bit). Returns data (ch, samples) in physical units."""
    with open(path, 'rb') as f:
        hdr = f.read(256)
        n_rec = int(hdr[236:244].decode().strip())
        dur = float(hdr[244:252].decode().strip())
        ns = int(hdr[252:256].decode().strip())
        def field(width):
            raw = f.read(width * ns).decode('latin-1')
            return [raw[i * width:(i + 1) * width].strip() for i in range(ns)]
        labels = field(16); field(80); field(8)
        pmin = np.array(field(8), float); pmax = np.array(field(8), float)
        dmin = np.array(field(8), float); dmax = np.array(field(8), float)
        field(80); nsamp = np.array(field(8), int); field(32)
        raw = np.frombuffer(f.read(), dtype='<i2')
    rec_len = nsamp.sum()
    n_rec = min(n_rec if n_rec > 0 else len(raw) // rec_len, len(raw) // rec_len)
    raw = raw[:n_rec * rec_len].reshape(n_rec, rec_len)
    gain = (pmax - pmin) / (dmax - dmin)
    offs = pmin - gain * dmin
    keep = [i for i, l in enumerate(labels) if 'annotation' not in l.lower()]
    fs_all = nsamp / dur
    fs = float(np.median(fs_all[keep]))
    data, names = [], []
    start = np.concatenate([[0], np.cumsum(nsamp)])
    for i in keep:
        if abs(fs_all[i] - fs) > 1e-6:
            continue
        sig = raw[:, start[i]:start[i + 1]].reshape(-1).astype(float)
        data.append(sig * gain[i] + offs[i]); names.append(labels[i])
    return np.array(data), fs, names


_GDF_DTYPES = {1: '<i1', 2: '<u1', 3: '<i2', 4: '<u2', 5: '<i4', 6: '<u4', 7: '<i8', 8: '<u8',
               16: '<f4', 17: '<f8'}


def read_gdf(path: str) -> Tuple[np.ndarray, float, List[str]]:
    """Reader for GDF 1.x files (as exported by g.tec g.USBamp / Smarting recorders).

    Returns data (channels, samples) in physical units, sampling rate and labels.
    """
    with open(path, 'rb') as f:
        buf = f.read()
    ver = buf[:8].decode('latin-1')
    if not ver.startswith('GDF 1'):
        raise ValueError(f'Only GDF 1.x is supported by the built-in reader ({ver}); install MNE.')
    hlen = struct.unpack('<q', buf[184:192])[0]
    nrec = struct.unpack('<q', buf[236:244])[0]
    dn, dd = struct.unpack('<II', buf[244:252])
    ns = struct.unpack('<H', buf[252:254])[0]
    o = 256

    def fld(w):
        nonlocal o
        r = [buf[o + i * w:o + (i + 1) * w] for i in range(ns)]
        o += w * ns
        return r
    labels = [x.decode('latin-1').strip('\x00 ') for x in fld(16)]
    fld(80); fld(8)
    pmin = np.array([struct.unpack('<d', x)[0] for x in fld(8)])
    pmax = np.array([struct.unpack('<d', x)[0] for x in fld(8)])
    dmin = np.array([struct.unpack('<q', x)[0] for x in fld(8)], float)
    dmax = np.array([struct.unpack('<q', x)[0] for x in fld(8)], float)
    fld(80)
    spr = np.array([struct.unpack('<i', x)[0] for x in fld(4)])
    typ = np.array([struct.unpack('<I', x)[0] for x in fld(4)])
    if len(set(spr)) != 1 or len(set(typ)) != 1:
        raise ValueError('Mixed sampling rates / data types are not supported by the built-in reader.')
    dt = np.dtype(_GDF_DTYPES[int(typ[0])])
    rec_bytes = int(spr[0]) * ns * dt.itemsize
    avail = (len(buf) - hlen) // rec_bytes
    nrec = avail if nrec < 0 else min(nrec, avail)
    raw = np.frombuffer(buf, dtype=dt, count=nrec * spr[0] * ns, offset=hlen)
    raw = raw.reshape(nrec, ns, spr[0]).transpose(1, 0, 2).reshape(ns, -1).astype(float)
    gain = np.where(dmax > dmin, (pmax - pmin) / np.where(dmax > dmin, dmax - dmin, 1), 1.0)
    data = (raw - dmin[:, None]) * gain[:, None] + pmin[:, None]
    fs = spr[0] / (dn / dd)
    return data, float(fs), labels


def read_set(path: str) -> Tuple[np.ndarray, float, List[str]]:
    """EEGLAB .set reader (data embedded or in a companion .fdt file)."""
    try:
        m = loadmat(path, squeeze_me=True, struct_as_record=False)
        EEG = m['EEG'] if 'EEG' in m else m
        get = (lambda k: getattr(EEG, k)) if not isinstance(EEG, dict) else (lambda k: EEG[k])
        fs = float(get('srate')); nbchan = int(get('nbchan')); pnts = int(get('pnts'))
        trials = int(get('trials')) if np.size(get('trials')) else 1
        chanlocs = get('chanlocs')
        names = [str(c.labels) for c in np.atleast_1d(chanlocs)]
        dat = get('data')
    except NotImplementedError:  # MATLAB v7.3 (HDF5)
        import h5py
        with h5py.File(path, 'r') as h:
            g = h['EEG'] if 'EEG' in h else h
            fs = float(np.array(g['srate']).squeeze()); nbchan = int(np.array(g['nbchan']).squeeze())
            pnts = int(np.array(g['pnts']).squeeze()); trials = int(np.array(g['trials']).squeeze())
            refs = g['chanlocs']['labels']
            names = [''.join(chr(c) for c in np.array(h[r[0]]).squeeze()) for r in refs]
            dat = g['data']
            dat = np.array(dat) if not isinstance(dat, (str, bytes)) and dat.dtype != 'uint16' else \
                ''.join(chr(c) for c in np.array(dat).squeeze())
    if isinstance(dat, str):
        fdt = os.path.join(os.path.dirname(path), os.path.basename(dat))
        if not os.path.exists(fdt):
            fdt = os.path.splitext(path)[0] + '.fdt'
        x = np.fromfile(fdt, dtype='<f4').reshape((nbchan, pnts * trials), order='F')
    else:
        x = np.asarray(dat, float).reshape(nbchan, -1, order='F') if np.ndim(dat) == 3 else np.asarray(dat, float)
        if x.shape[0] != nbchan:
            x = x.T
    return x.astype(float), fs, names


def read_any(path: str, fs_hint: Optional[float] = None) -> Tuple[np.ndarray, float, List[str]]:
    ext = os.path.splitext(path)[1].lower()
    try:
        import mne  # noqa: F401  (Colab path)
        mne.set_log_level('ERROR')
        if ext in ('.set', '.edf', '.bdf', '.gdf', '.vhdr', '.fif', '.cnt'):
            raw = mne.io.read_raw(path, preload=True, verbose=False)
            return raw.get_data(), float(raw.info['sfreq']), list(raw.ch_names)
    except Exception:
        pass
    if ext == '.edf':
        return read_edf(path)
    if ext == '.gdf':
        return read_gdf(path)
    if ext == '.set':
        return read_set(path)
    if ext == '.mat':
        m = loadmat(path, squeeze_me=True)
        arrs = {k: v for k, v in m.items() if isinstance(v, np.ndarray) and v.ndim == 2 and min(v.shape) >= 8}
        if not arrs:
            raise ValueError(f'No 2-D EEG array found in {path}')
        k = max(arrs, key=lambda k: arrs[k].size)
        x = arrs[k]
        x = x if x.shape[0] < x.shape[1] else x.T
        fs = fs_hint or float(next((np.squeeze(v) for kk, v in m.items() if kk.lower() in ('fs', 'srate', 'sfreq')), 0) or 0)
        names = list(EEG_CHANNELS[:x.shape[0]])
        return x.astype(float), fs, names
    if ext in ('.csv', '.txt', '.tsv'):
        import pandas as pd
        df = pd.read_csv(path, sep=None, engine='python')
        names = [str(c) for c in df.columns]
        return df.values.T.astype(float), fs_hint, names
    raise ValueError(f'Unsupported format: {path}')


# ----------------------------------------------------------------------------
# Preprocessing
# ----------------------------------------------------------------------------
def select_channels(x, names):
    nm = [_norm_name(n) for n in names]
    idx, missing = [], []
    for ch in EEG_CHANNELS:
        if ch in nm:
            idx.append(nm.index(ch))
        else:
            missing.append(ch)
    if missing:
        raise ValueError(f'Missing channels: {missing}; available: {names}')
    return x[idx]


def _interp_matrix(bad: np.ndarray) -> np.ndarray:
    pos = electrode_positions()
    d = np.linalg.norm(pos[:, None] - pos[None], axis=-1)
    Wt = np.where(bad[None, :], 0.0, 1.0 / (d + 1e-6) ** 2)
    np.fill_diagonal(Wt, 0.0)
    Wt /= Wt.sum(1, keepdims=True)
    T = np.eye(len(bad))
    T[bad] = Wt[bad]
    return T


def detect_narrowband(x: np.ndarray, fs: float, thr: float = 0.8, max_width: float = 0.5,
                      fmin: float = 2.0, fmax: float = 45.0) -> List[float]:
    """Centre frequencies of narrowband (non-physiological) spectral lines in the channel-averaged PSD."""
    from scipy.signal import welch, medfilt
    xc = x - x.mean(axis=0, keepdims=True)
    f, P = welch(xc, fs=fs, nperseg=int(8 * fs), axis=-1)
    L = np.log10(P.mean(0) + 1e-30)
    df_ = f[1] - f[0]
    base = medfilt(L, int(4.0 / df_) | 1)
    ex = (L - base) > thr
    ex &= (f >= fmin) & (f <= fmax)
    peaks, i = [], 0
    while i < len(ex):
        if ex[i]:
            j = i
            while j + 1 < len(ex) and ex[j + 1]:
                j += 1
            if (j - i + 1) * df_ <= max_width + 1e-9:
                seg = slice(i, j + 1)
                peaks.append(float(f[seg][np.argmax(L[seg])]))
            i = j + 1
        else:
            i += 1
    return peaks


def preprocess(x: np.ndarray, fs: float, names: List[str], line_freq: float = 60.0,
               epoch_sec: float = 2.0, window_sec: float = 20.0, max_sec: Optional[float] = None):
    """Return dict with clean continuous data (17 x T), windows list, and QC info."""
    x = select_channels(np.asarray(x, float), names)
    x = x - np.median(x, axis=1, keepdims=True)
    # resample
    fs_i = int(round(fs))
    g = gcd(int(FS_TARGET), fs_i)
    x = resample_poly(x, int(FS_TARGET) // g, fs_i // g, axis=1)
    fs = FS_TARGET
    if max_sec:
        x = x[:, :int(max_sec * fs)]
    sos = butter(4, [1.0, 45.0], btype='band', fs=fs, output='sos')
    x = sosfiltfilt(sos, x, axis=1)
    if line_freq < fs / 2:
        bn, an = iirnotch(line_freq, 30.0, fs)
        x = filtfilt(bn, an, x, axis=1)
    # narrowband instrumental artefacts (e.g. a ~16 Hz line present in every recording of one system):
    # peaks >= 0.8 log10 units (8 dB) above the 4-Hz running median and <= 0.5 Hz wide, 2-45 Hz
    line_peaks = detect_narrowband(x, fs)
    for f0 in line_peaks:
        bn, an = iirnotch(f0, max(f0 / 0.5, 5.0), fs)
        x = filtfilt(bn, an, x, axis=1)
    # recording-level QC 1: reference failure (common-mode contamination) -> near-unit
    # median inter-channel correlation of the reference-montage signals
    Cm = np.corrcoef(x)
    medcorr = float(np.median(Cm[np.triu_indices(x.shape[0], 1)]))
    # bad channels, detected after a provisional common average reference
    xc = x - x.mean(axis=0, keepdims=True)
    lv = np.log(xc.var(axis=1) + 1e-30)
    med = np.median(lv); mad = 1.4826 * np.median(np.abs(lv - med)) + 1e-12
    bad = (np.abs(lv - med) / mad > 4.0) | (x.std(axis=1) < 1e-12)
    if 0 < bad.sum() <= MAX_BAD:
        x = _interp_matrix(bad) @ (x - x[~bad].mean(axis=0, keepdims=True))
    x = x - x.mean(axis=0, keepdims=True)
    # epochs
    L = int(epoch_sec * fs)
    n_ep = x.shape[1] // L
    ep = x[:, :n_ep * L].reshape(x.shape[0], n_ep, L).transpose(1, 0, 2)
    lv_e = np.log(ep.var(axis=2).mean(1))
    p2p = np.log(np.ptp(ep, axis=2).max(1))
    def rob(v):
        m = np.median(v); s = 1.4826 * np.median(np.abs(v - m)) + 1e-12
        return (v - m) / s
    good = (rob(lv_e) < 3.5) & (rob(p2p) < 3.5)
    clean = np.concatenate(list(ep[good]), axis=1) if good.any() else x
    W = int(window_sec * fs)
    n_w = clean.shape[1] // W
    windows = [clean[:, i * W:(i + 1) * W] for i in range(n_w)]
    reasons = []
    if medcorr > MAX_MEDCORR:
        reasons.append(f'reference failure (median inter-channel r = {medcorr:.3f})')
    if bad.sum() > MAX_BAD:
        reasons.append(f'{int(bad.sum())} bad channels')
    if clean.shape[1] / fs < MIN_CLEAN_SEC:
        reasons.append(f'only {clean.shape[1] / fs:.0f} s of clean data')
    return {'clean': clean, 'windows': windows, 'fs': fs, 'line_peaks': line_peaks, 'bad_channels': [EEG_CHANNELS[i] for i in np.where(bad)[0]],
            'n_epochs': int(n_ep), 'n_good_epochs': int(good.sum()), 'medcorr': medcorr,
            'clean_sec': clean.shape[1] / fs, 'excluded': bool(reasons), 'reason': '; '.join(reasons)}
