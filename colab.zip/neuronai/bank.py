"""
neuronai.bank
=============

Generation of simulation banks used to train the amortised inverse model
(EEG features -> physiological parameters) and the forward emulator
(physiological parameters -> EEG features).

Parameters are drawn with a scrambled Sobol sequence (seeded) over the prior
box FIT_BOUNDS. Bank "I" (inverse) keeps neuromodulatory tone at baseline;
bank "E" (emulator) additionally varies the two neuromodulatory nuisance
parameters (dv0: firing-threshold shift; rscale: firing-rate gain) over the
range reachable by the pharmacological controls.
"""
from __future__ import annotations

import time
from typing import Optional

import numpy as np
from scipy.stats import qmc

from .model import FIT_PARAMS, FIT_BOUNDS, simulate, params_from_unit
from .features import extract_features, feature_matrix, psd, normalised_log_psd, FEATURE_NAMES

EMU_EXTRA = {'dv0': (-1.0, 1.0), 'rscale': (0.85, 1.15)}


def sample_unit(n: int, d: int, seed: int) -> np.ndarray:
    sampler = qmc.Sobol(d=d, scramble=True, seed=seed)
    m = int(np.ceil(np.log2(max(n, 2))))
    return sampler.random_base2(m)[:n]


def generate_bank(n: int, kind: str = 'I', seed: int = 2026, batch: int = 256,
                  duration: float = 20.0, transient: float = 2.0,
                  out_path: Optional[str] = None, verbose: bool = True) -> dict:
    d = len(FIT_PARAMS) + (2 if kind == 'E' else 0)
    U = sample_unit(n, d, seed)
    theta = params_from_unit(U[:, :len(FIT_PARAMS)])
    if kind == 'E':
        for j, (k, (lo, hi)) in enumerate(EMU_EXTRA.items()):
            theta[k] = lo + U[:, len(FIT_PARAMS) + j] * (hi - lo)
    X, LP, ok = [], [], []
    t0 = time.time()
    for s in range(0, n, batch):
        th_b = {k: v[s:s + batch] for k, v in theta.items()}
        res = simulate(th_b, duration=duration, transient=transient, seed=seed * 1000 + s // batch)
        x = res.eeg
        good = np.isfinite(x).all(axis=(1, 2)) & (x.std(axis=(1, 2)) > 1e-6)
        x = np.where(good[:, None, None], x, 0.0) + (~good)[:, None, None] * 1e-3 * \
            np.random.default_rng(0).standard_normal(x.shape)
        F = feature_matrix(extract_features(x, res.fs))
        f, P = psd(x, res.fs)
        fsel, lp = normalised_log_psd(f, P)
        good &= np.isfinite(F).all(axis=1)
        X.append(F); LP.append(lp); ok.append(good)
        if verbose:
            el = time.time() - t0
            done = min(s + batch, n)
            print(f'  bank {kind}: {done}/{n} simulations  ({el/60:.1f} min elapsed)', flush=True)
    bank = {'theta_names': np.array(list(theta.keys())),
            'theta': np.stack([theta[k] for k in theta], axis=1),
            'X': np.concatenate(X), 'logpsd': np.concatenate(LP).astype(np.float32),
            'freqs': fsel, 'ok': np.concatenate(ok), 'feature_names': np.array(FEATURE_NAMES),
            'seed': seed, 'duration': duration}
    if out_path:
        np.savez_compressed(out_path, **bank)
    return bank


def load_bank(path: str) -> dict:
    z = np.load(path, allow_pickle=False)
    return {k: z[k] for k in z.files}
