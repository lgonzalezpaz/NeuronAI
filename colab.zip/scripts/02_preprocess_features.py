"""Step 2 - preprocess every recording and extract unit-invariant EEG descriptors."""
import argparse, glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.data import read_any, preprocess
from neuronai.features import extract_features, feature_matrix, FEATURE_NAMES, psd, normalised_log_psd

ap = argparse.ArgumentParser()
ap.add_argument('--asd', default='data/ASD')
ap.add_argument('--td', default='data/TD')
ap.add_argument('--out', default='results')
ap.add_argument('--tag', default='')
ap.add_argument('--block', type=int, default=19,
                help='recordings per child in sequential file numbering (Duville et al.: 1 rest + 18 task = 19); use 1 if one file per child')
a = ap.parse_args()
rows, win_rows, psds, psds1, psds2, topo, failed = [], [], {}, {}, {}, {}, []
for grp, folder in [('ASD', a.asd), ('TD', a.td)]:
    files = sorted(glob.glob(os.path.join(folder, '**', '*.*'), recursive=True))
    files = [f for f in files if os.path.splitext(f)[1].lower() in ('.gdf', '.edf', '.set', '.bdf', '.mat')]
    files.sort(key=lambda p: int((re.findall(r'(\d+)\.\w+$', p) or ['0'])[0]))
    for p in files:
        sid = os.path.splitext(os.path.basename(p))[0]
        try:
            x, fs, names = read_any(p)
            pp = preprocess(x, fs, names)
            W = np.stack(pp['windows'])                  # (n_win, 17, 5000)
        except Exception as exc:                         # unreadable or too short: log and continue
            failed.append({'id': sid, 'group': grp, 'file': os.path.relpath(p, folder), 'error': repr(exc)[:300]})
            print(f"{sid:10s} SKIPPED ({exc!r})", flush=True)
            continue
        F = feature_matrix(extract_features(W, pp['fs']))  # (n_win, 10)
        f, P = psd(W, pp['fs'])
        fsel, lp = normalised_log_psd(f, P.mean(0))
        psds[sid] = lp
        band = (f >= 2) & (f <= 30)                      # spatial-spectral fingerprint (used to verify child blocks)
        Pc = P.mean(0)[:, band]
        topo[sid] = np.log10(Pc / Pc.sum() + 1e-20).ravel()
        half = len(W) // 2
        psds1[sid] = normalised_log_psd(f, P[:half].mean(0))[1]
        psds2[sid] = normalised_log_psd(f, P[half:].mean(0))[1]
        num = int((re.findall(r'(\d+)$', sid) or ['1'])[0])
        k_child = (num - 1) // a.block
        child = f"{grp}-{chr(ord('A') + k_child) if k_child < 26 else f'{k_child + 1:02d}'}"
        cond = 'rest' if a.block > 1 and (num - 1) % a.block == 0 else ('task' if a.block > 1 else 'rest')
        rec = {'id': sid, 'group': grp, 'child': child, 'condition': cond, 'fs_orig': fs, 'duration_s': x.shape[1] / fs,
               'clean_s': pp['clean_sec'], 'n_windows': len(W), 'bad_channels': ','.join(pp['bad_channels']),
               'n_bad': len(pp['bad_channels']), 'line_peaks_hz': ';'.join(f'{v:.2f}' for v in pp['line_peaks']), 'medcorr': pp['medcorr'], 'excluded': pp['excluded'],
               'reason': pp['reason']}
        rec.update({k: v for k, v in zip(FEATURE_NAMES, F.mean(0))})
        rec.update({k + '_h1': v for k, v in zip(FEATURE_NAMES, F[:half].mean(0))})
        rec.update({k + '_h2': v for k, v in zip(FEATURE_NAMES, F[half:].mean(0))})
        rows.append(rec)
        for wi in range(len(W)):
            win_rows.append({'id': sid, 'group': grp, 'child': child, 'window': wi, **dict(zip(FEATURE_NAMES, F[wi]))})
        print(f"{sid:10s} win={len(W)} bad={pp['bad_channels']} excl={pp['excluded']} {pp['reason']}", flush=True)
df = pd.DataFrame(rows)
df.to_csv(os.path.join(a.out, f'empirical_features{a.tag}.csv'), index=False)
pd.DataFrame(win_rows).to_csv(os.path.join(a.out, f'empirical_features_windows{a.tag}.csv'), index=False)
np.savez_compressed(os.path.join(a.out, f'empirical_psd{a.tag}.npz'), freqs=fsel, ids=np.array(list(psds)),
                    logpsd=np.stack(list(psds.values())), logpsd_h1=np.stack(list(psds1.values())),
                    logpsd_h2=np.stack(list(psds2.values())), topo=np.stack(list(topo.values())))
if failed:
    pd.DataFrame(failed).to_csv(os.path.join(a.out, f'failed_files{a.tag}.csv'), index=False)
    print(len(failed), 'files could not be read; see failed_files.csv')
print(df.groupby(['group', 'excluded']).size())
