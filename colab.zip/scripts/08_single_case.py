"""Step 8 - single-case analysis: one recording of the high-autistic-trait (ASD) cohort versus the TD reference.

The case is fixed a priori as the resting-state recording of participant 1 of the ASD cohort
(ASD_Part01_restEO in the complete datasets; ASD_EEG1 in the 120-file subset). The reference is every
valid TD recording of the same condition (resting state). The 30 best emulator candidates and 30 matched random control vectors are
simulated with 20 paired noise streams; candidates are ranked by simulated improvement; the top-ranked
intervention (and the best random vector) are then confirmed on 20 fresh streams."""
import json, os, pickle, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.model import CONTROLS, FIT_PARAMS, simulate
from neuronai.features import FEATURE_NAMES, psd, normalised_log_psd
from neuronai.intervention import (NormativeReference, search, random_like, simulate_candidates,
                                   verified_improvement)

R = 'results'

N_CAND, N_STREAMS = 30, 20
models = pickle.load(open(f'{R}/models.pkl', 'rb'))
df = pd.read_csv(f'{R}/empirical_features.csv'); df = df[~df.excluded].reset_index(drop=True)
tw = pd.read_csv(f'{R}/twin_parameters.csv').set_index('id')
X = df[FEATURE_NAMES].values
CASE = 'ASD_Part01_restEO' if (df.id == 'ASD_Part01_restEO').any() else 'ASD_EEG1'
REF_MASK = ((df.group == 'TD') & (df.condition == df.loc[df.id == CASE, 'condition'].iloc[0])).values
if REF_MASK.sum() < 10:                     # too few condition-matched TD recordings: use all TD recordings
    REF_MASK = (df.group == 'TD').values
ref = NormativeReference(X[REF_MASK])
print('case', CASE, '| TD reference recordings:', REF_MASK.sum())
i = int(np.where(df.id == CASE)[0][0])
theta = {n: tw.loc[CASE, f'{n}_full'] for n in FIT_PARAMS}
res = search(X[i], theta, models['emulator'], ref, n_refine=N_CAND)
d0 = res['d0']
cands = res['results'][:N_CAND]
U_ai = np.array([c['u'] for c in cands]); U_rn = random_like(U_ai, seed=77)
F = simulate_candidates(theta, np.vstack([np.zeros((1, len(CONTROLS))), U_ai, U_rn]), N_STREAMS, seed=4242)
per_ai, m_ai, d_ai = verified_improvement(X[i], F[1:1 + N_CAND], F[0], ref)
per_rn, m_rn, _ = verified_improvement(X[i], F[1 + N_CAND:], F[0], ref)
rng = np.random.default_rng(0)
rows = []
for k in range(N_CAND):
    bs = [100 * (d0 - ref.distance((X[i] + d_ai[k][rng.integers(0, N_STREAMS, N_STREAMS)].mean(0))[None])[0]) / d0
          for _ in range(2000)]
    u = cands[k]['u']
    rows.append({'combination': cands[k]['name'],
                 'u': ' / '.join(f"{CONTROLS[j]} {u[j]:+.2f}" for j in np.where(np.abs(u) >= 0.05)[0]),  # |u| < 0.05: negligible
                 'emulator_rank': k + 1, 'improvement_emulated': cands[k]['improvement'],
                 'improvement_simulated': float(m_ai[k]), 'ci_lo': float(np.percentile(bs, 2.5)),
                 'ci_hi': float(np.percentile(bs, 97.5)), 'pct_streams_improved': float((per_ai[k] > 0).mean() * 100),
                 'D_initial': d0, 'D_final': d0 * (1 - m_ai[k] / 100),
                 'key': ' '.join(f'{CONTROLS[j]}{np.round(u[j], 1):+.1f}' for j in np.where(np.abs(u) >= 0.1)[0])})
tab = pd.DataFrame(rows).sort_values('improvement_simulated', ascending=False)
tab = tab.drop_duplicates('key').reset_index(drop=True)        # practically identical control vectors
tab.insert(0, 'rank', np.arange(1, len(tab) + 1))
tab.head(10).to_csv(f'{R}/single_case_top10.csv', index=False)
tab.to_csv(f'{R}/single_case_all_candidates.csv', index=False)
print(tab.head(10).round(2).to_string())

# confirmation of the winner and of the best random vector on fresh streams
k_best = int(np.argmax(m_ai)); k_rn = int(np.argmax(m_rn))
Fc = simulate_candidates(theta, np.vstack([np.zeros((1, len(CONTROLS))), U_ai[k_best], U_rn[k_rn]]), N_STREAMS, seed=9191)
pc_ai, mc_ai, dc_ai = verified_improvement(X[i], Fc[1:2], Fc[0], ref)
pc_rn, mc_rn, dc_rn = verified_improvement(X[i], Fc[2:3], Fc[0], ref)
bs_ai = [100 * (d0 - ref.distance((X[i] + dc_ai[0][rng.integers(0, N_STREAMS, N_STREAMS)].mean(0))[None])[0]) / d0 for _ in range(2000)]
bs_rn = [100 * (d0 - ref.distance((X[i] + dc_rn[0][rng.integers(0, N_STREAMS, N_STREAMS)].mean(0))[None])[0]) / d0 for _ in range(2000)]
# spectra of the confirmed winner for the figure (same fresh streams)
lp = []
for U in (np.zeros(len(CONTROLS)), U_ai[k_best]):
    r = simulate({k: np.full(N_STREAMS, v) for k, v in theta.items()}, u=np.repeat(U[None], N_STREAMS, 0),
                 duration=20.0, seed=9191, crn_index=np.arange(N_STREAMS))
    f, P = psd(r.eeg, r.fs); fsel, l = normalised_log_psd(f, P); lp.append(l)
emp = np.load(f'{R}/empirical_psd.npz'); ids = list(emp['ids'])
np.savez_compressed(f'{R}/single_case.npz', freqs=fsel, lp_base=lp[0], lp_best=lp[1],
                    emp_case=emp['logpsd'][ids.index(CASE)],
                    emp_td=emp['logpsd'][[ids.index(s) for s in df.id[REF_MASK]]],
                    x_case=X[i], x_post=X[i] + dc_ai[0].mean(0), ref_mu=ref.mu, ref_sd=ref.sd,
                    screen_ai=m_ai, screen_random=m_rn)
meta = {'case': CASE, 'theta': theta, 'd0': d0, 'winner': cands[k_best]['name'], 'winner_u': U_ai[k_best].tolist(),
        'confirmed_improvement': float(mc_ai[0]), 'confirmed_ci': [float(np.percentile(bs_ai, 2.5)), float(np.percentile(bs_ai, 97.5))],
        'confirmed_pct_streams_improved': float((pc_ai[0] > 0).mean() * 100),
        'random_winner': '+'.join(CONTROLS[j] for j in np.where(np.abs(U_rn[k_rn]) > 1e-9)[0]),
        'random_confirmed_improvement': float(mc_rn[0]),
        'random_confirmed_ci': [float(np.percentile(bs_rn, 2.5)), float(np.percentile(bs_rn, 97.5))],
        'screen_median_ai': float(np.median(m_ai)), 'screen_median_random': float(np.median(m_rn)),
        'emulator_vs_simulator_r': float(np.corrcoef([c['improvement'] for c in cands], m_ai)[0, 1])}
json.dump(meta, open(f'{R}/single_case_meta.json', 'w'), indent=1)
print(json.dumps(meta, indent=1))
