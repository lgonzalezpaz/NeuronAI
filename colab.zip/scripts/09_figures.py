"""Step 9 - publication figures (Figures 2-8, Supplementary Figures S1-S3)."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from fig_style import (setup, save, panel, C_TD, C_ASD, C_SIM, C_NULL, C_TXT, C_TXT2, GRID,
                       DIV_NEG, DIV_MID, DIV_POS, CHILD_ASD, CHILD_TD)
from neuronai.model import FIT_PARAMS, FIT_LABELS, FIT_BOUNDS, CONTROLS, CONTROL_LABELS, params_from_unit
from neuronai.features import FEATURE_NAMES, FEATURE_LABELS
from neuronai.bank import load_bank

setup()
R = 'results'
df_all = pd.read_csv(f'{R}/empirical_features.csv')
df = df_all[~df_all.excluded].reset_index(drop=True)
tw = pd.read_csv(f'{R}/twin_parameters.csv')
emp = np.load(f'{R}/empirical_psd.npz')
ids = list(emp['ids']); fr = emp['freqs']
E = np.stack([emp['logpsd'][ids.index(s)] for s in df.id])
grp = df.group.values
gcol = {'ASD': C_ASD, 'TD': C_TD}
DISP = {'ASD': 'ASD', 'TD': 'TD'}
nice_id = lambda sid: sid.replace('ASD_', 'ASD ').replace('TD_', 'TD ').replace('_restEO', ' rest').replace('_', ' ').replace('EEG', '#')
MANY = df.child.nunique() > 12
children = sorted(df.child.unique())
ccol = {c: (CHILD_ASD if c.startswith('ASD') else CHILD_TD)[k % 4] for k, c in enumerate(children)}
if MANY:
    ccol = {c: gcol[c.split('-')[0]] for c in children}


def child_strip(ax, values, x0, jitter=0.12, s=7):
    rng = np.random.default_rng(0)
    for c in children:
        m = (df.child == c).values
        ax.scatter(x0 + rng.uniform(-jitter, jitter, m.sum()), values[m], s=s, color=ccol[c], alpha=0.75,
                   edgecolors='white', linewidths=0.3, zorder=3)


# =========================================================================== Figure 2
fig = plt.figure(figsize=(7.2, 6.2))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.15], hspace=0.42, wspace=0.28)
ax = fig.add_subplot(gs[0, 0]); ax.axis('off'); panel(ax, 'a', x=-0.02, y=1.02)
ax.set_xlim(0, 1); ax.set_ylim(0, 1)
n_tot = df_all.groupby('group').size(); n_ok = df.groupby('group').size(); n_ch = df.groupby('group').child.nunique()
ex = df_all[df_all.excluded]
reasons = ex.reason.fillna('').astype(str).str.contains('reference').sum(); badch = ex.reason.fillna('').astype(str).str.contains('bad channels').sum()
def tbox(x, y, w, h, t, fc, ec, fs=6.4):
    ax.add_patch(plt.Rectangle((x, y), w, h, fc=fc, ec=ec, lw=0.8))
    ax.text(x + w / 2, y + h / 2, t, ha='center', va='center', fontsize=fs)
def why(g):
    e = ex[ex.group == g].reason.fillna('').astype(str)
    return len(e), int(e.str.contains('reference').sum()), int(e.str.contains('bad channels').sum()), int(e.str.contains('clean data').sum())
tbox(0.04, 0.78, 0.92, 0.17, f'{len(df_all):,} EEG recordings · {df_all.child.nunique()} children\n'
     f'ASD: {n_tot["ASD"]} ({df_all[df_all.group == "ASD"].child.nunique()} children) · '
     f'TD: {n_tot["TD"]} ({df_all[df_all.group == "TD"].child.nunique()} children)', '#f7f6f3', '#9a9994', 5.8)
for x0, g, fc, ec in [(0.04, 'ASD', '#fdf0ea', C_ASD), (0.52, 'TD', '#eef4fc', C_TD)]:
    ne, nr, nb, ns = why(g)
    tbox(x0, 0.03, 0.44, 0.26, f'{DISP[g]} analysed\n{n_ok[g]} recordings\n{n_ch[g]} children', fc, ec, 6.0)
    txt = f'excluded: {ne}\nreference failure: {nr}\n> 4 bad channels: {nb}' + (f'\n< 60 s clean: {ns}' if ns else '')
    tbox(x0 + 0.08, 0.36, 0.34, 0.30, txt + '\n(may co-occur)', '#fbe0de', '#e34948', 5.3)
arr = dict(arrowstyle='-|>', color='#52514e', lw=0.9)
for x in (0.08, 0.56):
    ax.annotate('', xy=(x, 0.29), xytext=(x, 0.78), arrowprops=arr)
ax.set_title('Recordings and quality control', loc='left', pad=6, x=0.06)
ax = fig.add_subplot(gs[0, 1]); panel(ax, 'b')
for g in ['TD', 'ASD']:
    m = grp == g
    mu, sd = E[m].mean(0), E[m].std(0)
    ax.fill_between(fr, mu - sd, mu + sd, color=gcol[g], alpha=0.18, lw=0)
    ax.plot(fr, mu, color=gcol[g], lw=1.6, label=f'{DISP[g]} (n = {m.sum()} recordings)')
ax.set_xlabel('Frequency (Hz)'); ax.set_ylabel('log$_{10}$ relative power')
ax.set_title('Empirical spectra (mean ± SD)'); ax.legend(loc='upper right')
ax.set_xlim(1, 30)

ax = fig.add_subplot(gs[1, :]); panel(ax, 'c', x=-0.07)
bank = load_bank(f'{R}/bank_I.npz'); BX = bank['X'][bank['ok']]
mu, sd = BX.mean(0), BX.std(0)
Z = (BX - mu) / sd
parts = ax.violinplot([Z[:, j] for j in range(len(FEATURE_NAMES))], positions=np.arange(len(FEATURE_NAMES)),
                      widths=0.8, showextrema=False)
for b in parts['bodies']:
    b.set_facecolor('#d9d8d3'); b.set_edgecolor('none'); b.set_alpha(1)
rng = np.random.default_rng(1)
for j, f in enumerate(FEATURE_NAMES):
    for g, off in [('ASD', -0.13), ('TD', 0.13)]:
        v = (df[f].values[grp == g] - mu[j]) / sd[j]
        ax.scatter(j + off + rng.uniform(-0.05, 0.05, len(v)), v, s=3 if MANY else 5, color=gcol[g], alpha=0.5 if MANY else 0.7, lw=0, zorder=3,
                   label=DISP[g] if j == 0 else None)
    q = [(BX[:, j] < v).mean() for v in df[f].values]
    ax.text(j, 4.2, f'{100*np.mean([(0.025 < qq < 0.975) for qq in q]):.0f}%', ha='center', fontsize=6.3, color=C_TXT2)
ax.text(-0.6, 4.75, 'Recordings inside the central 95 % of the prior predictive:', fontsize=6.3, color=C_TXT2)
ax.set_xticks(range(len(FEATURE_NAMES))); ax.set_xticklabels([FEATURE_LABELS[f] for f in FEATURE_NAMES], rotation=0, fontsize=6.4)
ax.set_ylabel('z-score relative to simulated bank'); ax.set_ylim(-4.5, 5.2)
ax.set_title('Prior predictive check: 8,192 simulations (gray) vs. real recordings', pad=16)
ax.legend(loc='lower right', ncol=2, markerscale=2)
save(fig, 'Figure2_data_priorpredictive')

# =========================================================================== Figure 3
rec = pd.read_csv(f'{R}/recovery_inverse.csv').set_index('parameter')
z = np.load(f'{R}/recovery_test.npz')
fig, axes = plt.subplots(3, 3, figsize=(7.0, 6.6))
cmap = LinearSegmentedColormap.from_list('b', ['#ffffff', '#cde2fb', '#6da7ec', '#2a78d6', '#104281'])
for k, (ax, n) in enumerate(zip(axes.ravel(), FIT_PARAMS)):
    lo, hi = FIT_BOUNDS[n]
    t = lo + z['true'][:, k] * (hi - lo); p = lo + z['pred'][:, k] * (hi - lo)
    ax.hexbin(t, p, gridsize=28, cmap=cmap, mincnt=1, linewidths=0.1, extent=(lo, hi, lo, hi))
    ax.plot([lo, hi], [lo, hi], color=C_TXT2, lw=0.8, ls='--')
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    r = rec.loc[n]
    ax.text(0.04, 0.96, f"$R^2$ = {r.R2:.2f}\ncoverage = {100*r.conformal_coverage_90:.0f}%",
            transform=ax.transAxes, va='top', fontsize=6.5, bbox=dict(fc='white', ec='none', alpha=0.8, pad=1))
    ax.set_title(FIT_LABELS[n], fontsize=8)
    if k % 3 == 0: ax.set_ylabel('Estimated')
    if k >= 6: ax.set_xlabel('Ground truth')
n_test = json.load(open(f'{R}/training_summary.json'))['n_test_inv']
fig.suptitle(f'Parameter recovery on {n_test:,} held-out simulations (inverse deep ensemble, 90 % conformal intervals)',
             fontsize=8.5, fontweight='bold', x=0.02, ha='left', y=0.995)
fig.tight_layout(rect=(0, 0, 1, 0.97))
save(fig, 'Figure3_identifiability')

# =========================================================================== Figure 4
ppc = np.load(f'{R}/ppc.npz', allow_pickle=True)
S = ppc['LP_full']
ppcs = pd.read_csv(f'{R}/ppc_summary.csv').set_index('feature')
r2t = pd.read_csv(f'{R}/ppc_spectral_r2.csv')
fig = plt.figure(figsize=(7.2, 6.6))
gs = fig.add_gridspec(3, 4, height_ratios=[1, 1.05, 1.05], hspace=0.7, wspace=0.55)
med = r2t.groupby('group').R2_twin.median()
examples = []
for g in ['ASD', 'TD']:
    sub = r2t[r2t.group == g].sort_values('R2_twin')
    examples += [sub.iloc[len(sub) // 2].id, sub.iloc[int(len(sub) * 0.15)].id]
for k, sid in enumerate(examples):
    ax = fig.add_subplot(gs[0, k]); i = int(np.where(df.id == sid)[0][0])
    if k == 0: panel(ax, 'a', x=-0.35)
    g = df.group[i]
    lo_, hi_ = np.percentile(S[i], [2.5, 97.5], axis=0)
    ax.fill_between(fr, lo_, hi_, color=C_SIM, alpha=0.25, lw=0)
    ax.plot(fr, S[i].mean(0), color=C_SIM, lw=1.3, label='Twin (simulated)')
    ax.plot(fr, E[i], color=gcol[g], lw=1.3, label='Recorded')
    rr = r2t.set_index('id').loc[sid, 'R2_twin']
    ax.set_title(nice_id(sid), fontsize=7)
    ax.text(0.97, 0.95, f'$R^2$={rr:.2f}', transform=ax.transAxes, ha='right', va='top', fontsize=6.5)
    ax.set_xlabel('Hz'); ax.set_xlim(1, 30)
    if k == 0:
        ax.set_ylabel('log$_{10}$ rel. power')
        ax.legend(loc='lower left', fontsize=5.8, handlelength=1.2)
ax = fig.add_subplot(gs[1, 0:2]); panel(ax, 'b', x=-0.2, y=1.12)
r2a = pd.read_csv(f'{R}/ppc_spectral_r2_amortised.csv').set_index('id')
for j, g in enumerate(['ASD', 'TD']):
    sub = r2t[r2t.group == g]
    x0 = j * 3.6
    vals = [sub.R2_group_mean.values, r2a.loc[sub.id, 'R2_amortised'].values, sub.R2_twin.values]
    cols = [C_NULL, '#9ec5f4', gcol[g]]
    for k2, (v, c) in enumerate(zip(vals, cols)):
        rng = np.random.default_rng(k2)
        ax.scatter(x0 + k2 + rng.uniform(-0.18, 0.18, len(v)), np.clip(v, -1, 1), s=5, color=c, alpha=0.8, lw=0, zorder=3)
        ax.plot([x0 + k2 - 0.3, x0 + k2 + 0.3], [np.median(v)] * 2, color=C_TXT, lw=1.4, zorder=4)
ax.set_xticks([0, 1, 2, 3.6, 4.6, 5.6])
ax.set_xticklabels(['group\nmean', 'amor-\ntised', 'refined\ntwin'] * 2, fontsize=5.8)
ax.text(1, 1.06, 'ASD', transform=ax.get_xaxis_transform(), ha='center', color=C_ASD, fontweight='bold')
ax.text(4.6, 1.06, 'TD', transform=ax.get_xaxis_transform(), ha='center', color=C_TD, fontweight='bold')
ax.set_ylabel('Spectral $R^2$ (clipped at −1)'); ax.set_ylim(-1.05, 1.0)
ax.set_title('Spectral fit, 1–30 Hz (bars: medians)', pad=14)
ax = fig.add_subplot(gs[1, 2:]); panel(ax, 'c', x=-0.16)
xx = np.arange(len(FEATURE_NAMES))
ax.bar(xx - 0.27, ppcs.r_in_sample, 0.26, color='#9ec5f4', label='in-sample')
ax.bar(xx, ppcs.r_out_of_sample, 0.26, color=C_SIM, label='out-of-sample (half 1 → half 2)')
ax.bar(xx + 0.27, ppcs.r_test_retest, 0.26, color='#d9d8d3', label='test–retest ceiling')
ax.set_xticks(xx); ax.set_xticklabels([FEATURE_LABELS[f] for f in FEATURE_NAMES], rotation=45, ha='right', fontsize=6)
ax.set_ylabel('Pearson r'); ax.axhline(0, color='#9a9994', lw=0.6)
ax.legend(fontsize=5.6, loc='lower center', bbox_to_anchor=(0.5, 1.0), ncol=3, handlelength=1.0, columnspacing=0.8); ax.set_ylim(min(-0.2, ppcs[['r_in_sample', 'r_out_of_sample']].min().min() - 0.05), 1.05)
ax.set_title('Recorded vs. predicted descriptors', pad=16)
F_oos = ppc['F_h1'].mean(1)
X2 = df[[f + '_h2' for f in FEATURE_NAMES]].values
for k, f in enumerate(['rel_alpha', 'iaf', 'exponent', 'kuramoto_alpha']):
    ax = fig.add_subplot(gs[2, k]); j = FEATURE_NAMES.index(f)
    if k == 0: panel(ax, 'd', x=-0.35)
    for g in ['ASD', 'TD']:
        m = grp == g
        ax.scatter(F_oos[m, j], X2[m, j], s=3 if MANY else 6, color=gcol[g], alpha=0.5 if MANY else 0.75, lw=0, label=DISP[g])
    lim = [min(F_oos[:, j].min(), X2[:, j].min()), max(F_oos[:, j].max(), X2[:, j].max())]
    pad = 0.05 * (lim[1] - lim[0]); lim = [lim[0] - pad, lim[1] + pad]
    ax.plot(lim, lim, color=C_TXT2, ls='--', lw=0.7); ax.set_xlim(lim); ax.set_ylim(lim)
    ax.set_title(FEATURE_LABELS[f], fontsize=7.5)
    ax.text(0.04, 0.96, f"r = {ppcs.loc[f, 'r_out_of_sample']:.2f}", transform=ax.transAxes, va='top', fontsize=6.5)
    ax.set_xlabel('Twin prediction (half 1)', fontsize=6.5)
    if k == 0:
        ax.set_ylabel('Recorded (half 2)', fontsize=6.5); ax.legend(fontsize=5.8, loc='lower right', handletextpad=0.1)
save(fig, 'Figure4_validation_real_eeg')

# =========================================================================== Figure 5
rel = pd.read_csv(f'{R}/reliability.csv')
vs = json.load(open(f'{R}/validation_summary.json'))
fig = plt.figure(figsize=(7.2, 5.8))
gs = fig.add_gridspec(2, 3, hspace=0.6, wspace=0.75)
ax = fig.add_subplot(gs[0, 0]); panel(ax, 'a', x=-0.75)
rp = rel[~rel.parameter.str.startswith('feature:')].reset_index(drop=True)
yy = np.arange(len(rp))[::-1]
ax.axvspan(0.75, 1.0, color='#e8f6f0', lw=0); ax.axvspan(0.5, 0.75, color='#f4faf7', lw=0)
ax.errorbar(rp.ICC_split_half, yy, xerr=[rp.ICC_split_half - rp.ci_lo, rp.ci_hi - rp.ICC_split_half], fmt='o',
            color=C_SIM, ms=4, elinewidth=1, capsize=0)
ax.set_yticks(yy); ax.set_yticklabels([FIT_LABELS[n] for n in rp.parameter], fontsize=6.3)
ax.set_xlabel('ICC(2,1), split halves'); ax.set_xlim(-0.2, 1.0)
ax.set_title('Split-half reliability')
ax = fig.add_subplot(gs[0, 1:]); panel(ax, 'b', x=-0.1)
show = ['p', 'K', 'rho', 'A', 'B']
SHORT = {'p': 'Drive $\\bar p$', 'K': 'Coupling $K$', 'B': 'Slow inh. $B$', 'rho': 'Slow input $\\rho$', 'A': 'AMPA $A$'}
if MANY:
    # child medians (dots) and within-child interquartile ranges (bars), children sorted within each parameter
    for k, n in enumerate(show):
        lo, hi = FIT_BOUNDS[n]
        vv = (tw[f'{n}_full'].values - lo) / (hi - lo)
        st = pd.DataFrame({'v': vv, 'child': df.child.values}).groupby('child').v.describe()
        st = st.sort_values('50%')
        xs = k + np.linspace(-0.4, 0.4, len(st))
        for x_, (c, r_) in zip(xs, st.iterrows()):
            col = gcol[c.split('-')[0]]
            ax.plot([x_, x_], [r_['25%'], r_['75%']], color=col, lw=0.6, alpha=0.55)
            ax.scatter([x_], [r_['50%']], s=4, color=col, lw=0, zorder=3)
        icc1 = rel.set_index('parameter').loc[n, 'ICC1_between_child']
        ax.text(k, 1.06, f'ICC(1) = {icc1:.2f}', ha='center', fontsize=6.0, color=C_TXT2)
        if k: ax.axvline(k - 0.5, color=GRID, lw=0.8)
    for g in ['ASD', 'TD']:
        ax.scatter([], [], color=gcol[g], s=12, label=f'{DISP[g]} child (median, IQR)')
    ax.legend(ncol=2, fontsize=6, loc='lower center', bbox_to_anchor=(0.5, -0.3))
    ax.set_title(f'Twin parameters of {len(children)} children (sorted within each parameter)', pad=14)
else:
    offs = np.linspace(-0.36, 0.36, len(children))
    rng = np.random.default_rng(0)
    for k, n in enumerate(show):
        v = tw[f'{n}_full'].values
        lo, hi = FIT_BOUNDS[n]
        vv = (v - lo) / (hi - lo)
        for o, c in zip(offs, children):
            m = (df.child == c).values
            ax.scatter(k + o + rng.uniform(-0.025, 0.025, m.sum()), vv[m], s=5, color=ccol[c], alpha=0.8, lw=0, zorder=3)
            ax.plot([k + o - 0.04, k + o + 0.04], [np.median(vv[m])] * 2, color=C_TXT, lw=1.0, zorder=4)
        icc1 = rel.set_index('parameter').loc[n, 'ICC1_between_child']
        ax.text(k, 1.06, f'ICC(1) = {icc1:.2f}', ha='center', fontsize=6.0, color=C_TXT2)
        if k: ax.axvline(k - 0.5, color=GRID, lw=0.8)
    for c in children:
        ax.scatter([], [], color=ccol[c], s=12, label=c)
    ax.legend(ncol=8, fontsize=5.8, loc='lower center', bbox_to_anchor=(0.5, -0.3), handletextpad=0.05, columnspacing=0.7)
    ax.set_title('Twin parameters by child (each column = one child; ticks = medians)', pad=14)
ax.set_xticks(range(len(show))); ax.set_xticklabels([SHORT[n] for n in show], fontsize=6.3)
ax.set_ylabel('Twin estimate (prior range = 0–1)'); ax.set_ylim(-0.05, 1.13); ax.grid(axis='x', visible=False)
ax = fig.add_subplot(gs[1, 0]); panel(ax, 'c', x=-0.45)
ci = vs['child_identification']; cd = vs.get('child_identification_discriminant')
vals = [ci['perm_mean'], ci['accuracy']]
labs = ['permuted labels', 'twin, centroid']
cols = ['#d9d8d3', C_SIM]
if cd is not None:
    vals += [cd['accuracy'], cd['reference_raw_descriptors_discriminant']]
    labs += ['twin, discriminant', 'raw EEG (reference)']
    cols += [C_SIM, '#9a9994']
    for g in ['ASD', 'TD']:
        w = cd.get(f'within_{g}')
        if w:
            vals.append(w['accuracy_discriminant']); labs.append(f'twin, within {DISP[g]}'); cols.append(gcol[g])
xs = np.arange(len(vals))
ax.bar(xs, vals, color=cols, width=0.62)
ax.set_xticks(xs); ax.set_xticklabels(labs, fontsize=5.4, rotation=45, ha='right', rotation_mode='anchor')
ax.set_ylabel('Child identification accuracy'); ax.set_ylim(0, 1.08)
for x_, v_ in zip(xs[1:], vals[1:]):
    ax.text(x_, v_ + 0.03, f"{100*v_:.0f}%", ha='center', fontsize=5.8)
ax.text(0.98, 0.97, f"{ci['n_children']} children\nchance {100/ci['n_children']:.1f}%", transform=ax.transAxes, ha='right', va='top', fontsize=5.6, color=C_TXT2)
ax.set_title('Which child?')
gp = pd.read_csv(f'{R}/group_params.csv').set_index('variable')
ax = fig.add_subplot(gs[1, 1:]); panel(ax, 'd', x=-0.3)
order = FIT_PARAMS
yy = np.arange(len(order))[::-1]
g_ = gp.loc[order]
lim_ = max(2.0, np.nanmax(np.abs(g_[['g_ci_lo', 'g_ci_hi']].values)) + 0.3)
ax.axvline(0, color='#9a9994', lw=0.7)
ax.errorbar(g_.hedges_g, yy, xerr=[g_.hedges_g - g_.g_ci_lo, g_.g_ci_hi - g_.hedges_g], fmt='o', color=C_ASD, ms=4, elinewidth=1)
for y_, (_, rw) in zip(yy, g_.iterrows()):
    ax.text(lim_ * 1.02, y_, f"q = {rw.q_fdr:.3f}", va='center', fontsize=6, color=C_TXT2)
ax.set_yticks(yy); ax.set_yticklabels([FIT_LABELS[n] for n in order], fontsize=6.3)
ax.set_xlabel("Hedges' g, ASD – TD (cluster-bootstrap 95 % CI)"); ax.set_xlim(-lim_, lim_ * 1.35)
ax.set_title('ASD vs. TD (confounded with device and sex; child-level p)')
save(fig, 'Figure5_reliability_personalisation')

# =========================================================================== Figure 6
pv = pd.read_csv(f'{R}/pharmaco_validity.csv')
eff = pd.read_csv(f'{R}/pharmaco_effects_all.csv')
fp = pd.read_csv(f'{R}/control_fingerprints.csv')
fig = plt.figure(figsize=(7.2, 6.4))
gs = fig.add_gridspec(2, len(pv), height_ratios=[1, 1.05], hspace=0.62, wspace=0.75)
for k, (_, rw) in enumerate(pv.iterrows()):
    ax = fig.add_subplot(gs[0, k])
    v = eff[eff.drug == rw.drug][rw.feature].values
    gg = eff[eff.drug == rw.drug].group.values
    rng = np.random.default_rng(k)
    for g, off in [('ASD', -0.15), ('TD', 0.15)]:
        ax.scatter(off + rng.uniform(-0.08, 0.08, (gg == g).sum()), v[gg == g], s=3 if MANY else 5, color=gcol[g], alpha=0.4 if MANY else 0.6, lw=0, label=DISP[g])
    ax.errorbar([0.5], [rw.mean_change], yerr=[[rw.mean_change - rw.ci_lo], [rw.ci_hi - rw.mean_change]], fmt='D',
                color=C_TXT, ms=4, capsize=2, lw=1)
    ax.axhline(0, color='#9a9994', lw=0.7)
    exp_up = rw.expected_sign == '+'
    ax.annotate('', xy=(0.86, 0.93 if exp_up else 0.66), xytext=(0.86, 0.66 if exp_up else 0.93), xycoords='axes fraction',
                arrowprops=dict(arrowstyle='-|>', color=C_SIM if rw.concordant else '#e34948', lw=1.6))
    ax.text(0.86, 0.98, 'expected', transform=ax.transAxes, ha='center', fontsize=5.3, color=C_TXT2)
    name = rw.drug.split(' (')[0].replace('GABA_A', 'GABA$_A$').replace('5-HT2A', '5-HT$_{2A}$')
    mech = '(' + rw.drug.split(' (')[1]
    import textwrap
    ax.set_title('\n'.join(textwrap.wrap(name, 18)) + f'\n{mech}', fontsize=5.7)
    lab = {'rel_beta': 'Δ log β rel. power', 'rel_alpha': 'Δ log α rel. power', 'theta_beta': 'Δ log θ/β ratio',
           'rel_delta': 'Δ log δ rel. power'}[rw.feature]
    ax.set_ylabel(lab, fontsize=6.3); ax.set_xticks([]); ax.set_xlim(-0.45, 1.05)
    verdict = 'reproduced' if rw.concordant else ('opposite' if (rw.ci_lo > 0 or rw.ci_hi < 0) else 'not significant')
    ax.text(0.5, -0.09, f"{rw.pct_twins_expected_direction:.0f}% of twins in\nexpected direction:\n{verdict}", transform=ax.transAxes, ha='center',
            va='top', fontsize=5.8, color=C_SIM if rw.concordant else '#e34948')
    if k == 0: ax.legend(fontsize=5.5, loc='lower left', handletextpad=0.1)
    panel(ax, 'abcde'[k], x=-0.55, y=1.16)
ax = fig.add_subplot(gs[1, :]); panel(ax, 'f', x=-0.08)
feats = FEATURE_NAMES
sdx = df[(df.group == 'TD')][feats].std().values
M = np.zeros((len(CONTROLS), len(feats))); sig = np.zeros_like(M, dtype=bool)
for i, c in enumerate(CONTROLS):
    for j, f in enumerate(feats):
        rw = fp[(fp.control == c) & (fp.feature == f)].iloc[0]
        M[i, j] = rw['mean'] / sdx[j]; sig[i, j] = (rw.ci_lo > 0) or (rw.ci_hi < 0)
cm = LinearSegmentedColormap.from_list('div', [DIV_NEG, DIV_MID, DIV_POS])
vmax = np.nanpercentile(np.abs(M), 95)
im = ax.imshow(M, cmap=cm, vmin=-vmax, vmax=vmax, aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f'{M[i, j]:+.1f}' + ('' if sig[i, j] else '°'), ha='center', va='center', fontsize=5.6,
                color='white' if abs(M[i, j]) > 0.6 * vmax else C_TXT)
ax.set_xticks(range(len(feats))); ax.set_xticklabels([FEATURE_LABELS[f] for f in feats], fontsize=6.2)
ax.set_yticks(range(len(CONTROLS))); ax.set_yticklabels([CONTROL_LABELS[c] + ' (+1)' for c in CONTROLS], fontsize=6.2)
ax.grid(False)
cb = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.01); cb.set_label('Δ descriptor (TD SD units)', fontsize=6.3); cb.ax.tick_params(labelsize=6)
ax.set_title('Mechanistic fingerprints of each control across all twins (° = cluster-bootstrap CI includes 0)')
save(fig, 'Figure7_pharmacological_face_validity')

# =========================================================================== Figure 7 single case
sc = np.load(f'{R}/single_case.npz')
top = pd.read_csv(f'{R}/single_case_top10.csv')
meta = json.load(open(f'{R}/single_case_meta.json'))
fig = plt.figure(figsize=(7.2, 5.8))
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.15], width_ratios=[1.45, 1], hspace=0.5, wspace=0.55)
ax = fig.add_subplot(gs[0, 0]); panel(ax, 'a')
td = sc['emp_td']; mu, sd = td.mean(0), td.std(0)
ax.fill_between(sc['freqs'], mu - sd, mu + sd, color=C_TD, alpha=0.18, lw=0, label='TD reference (mean ± SD)')
ax.plot(sc['freqs'], mu, color=C_TD, lw=1.2)
ax.plot(sc['freqs'], sc['emp_case'], color=C_ASD, lw=1.4, label=f"{nice_id(meta['case'])} (recorded)")
post = sc['emp_case'] + sc['lp_best'].mean(0) - sc['lp_base'].mean(0)
ax.plot(sc['freqs'], post, color=C_SIM, lw=1.4, ls='--', label='predicted after the confirmed top intervention')
ax.set_xlabel('Frequency (Hz)'); ax.set_ylabel('log$_{10}$ relative power'); ax.set_xlim(1, 30)
ax.legend(fontsize=5.6, loc='upper right', framealpha=0.9); ax.set_title('Single case vs. TD reference')
ax = fig.add_subplot(gs[0, 1]); panel(ax, 'b')
zc = (sc['x_case'] - sc['ref_mu']) / sc['ref_sd']; zp = (sc['x_post'] - sc['ref_mu']) / sc['ref_sd']
yy = np.arange(len(FEATURE_NAMES))[::-1]
ax.axvspan(-1, 1, color='#eef4fc', lw=0); ax.axvline(0, color='#9a9994', lw=0.7)
for y_, a, b in zip(yy, zc, zp):
    ax.annotate('', xy=(b, y_), xytext=(a, y_), arrowprops=dict(arrowstyle='-|>', color=C_SIM, lw=1.0))
ax.scatter(zc, yy, color=C_ASD, s=18, zorder=3, label='before'); ax.scatter(zp, yy, color=C_SIM, s=18, zorder=3, label='after (predicted)')
ax.set_yticks(yy); ax.set_yticklabels([FEATURE_LABELS[f] for f in FEATURE_NAMES], fontsize=6.3)
ax.set_xlabel('z-score relative to TD reference'); ax.legend(fontsize=6, loc='upper center', bbox_to_anchor=(0.5, -0.17), ncol=2)
ax.set_title('Descriptor profile (top-1 intervention)')
ax = fig.add_subplot(gs[1, 0]); panel(ax, 'c', x=-0.55)
yy = np.arange(len(top))[::-1]
ax.errorbar(top.improvement_simulated, yy, xerr=[top.improvement_simulated - top.ci_lo, top.ci_hi - top.improvement_simulated],
            fmt='o', color=C_SIM, ms=4, elinewidth=1.2, capsize=2, label='full simulator (20 paired streams)')
ax.scatter(top.improvement_emulated, yy, marker='x', color=C_TXT2, s=16, label='emulator estimate', zorder=3)
ax.axvline(0, color='#9a9994', lw=0.7)
PRETTY = lambda t: t.replace('GABA_slow', 'slow GABA').replace('GABA_A', 'GABA$_A$').replace('NMDA_2A', 'GluN2A').replace('NMDA_2B', 'GluN2B').replace('5HT', '5-HT$_{2A}$').replace(' / ', ', ')
ax.set_yticks(yy); ax.set_yticklabels([f'{r}. {PRETTY(u)}' for r, u in zip(top['rank'], top['u'])], fontsize=5.6)
ax.set_xlabel('Distance reduction to TD (%)')
ax.legend(fontsize=5.6, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2); ax.set_title('Ten best simulator-verified interventions')
ax = fig.add_subplot(gs[1, 1]); panel(ax, 'd', x=-0.2)
rng = np.random.default_rng(3)
for k2, (v, c, lab) in enumerate([(sc['screen_random'], C_NULL, 'random\n(matched)'), (sc['screen_ai'], C_SIM, 'NeuronAI\ncandidates')]):
    ax.scatter(k2 + rng.uniform(-0.15, 0.15, len(v)), v, s=9, color=c, alpha=0.85, lw=0)
    ax.plot([k2 - 0.25, k2 + 0.25], [np.median(v)] * 2, color=C_TXT, lw=1.4)
ax.errorbar([2.1], [meta['confirmed_improvement']], yerr=[[meta['confirmed_improvement'] - meta['confirmed_ci'][0]],
            [meta['confirmed_ci'][1] - meta['confirmed_improvement']]], fmt='D', color=C_SIM, ms=5, capsize=2)
ax.errorbar([2.5], [meta['random_confirmed_improvement']], yerr=[[meta['random_confirmed_improvement'] - meta['random_confirmed_ci'][0]],
            [meta['random_confirmed_ci'][1] - meta['random_confirmed_improvement']]], fmt='D', color=C_NULL, ms=5, capsize=2)
ax.set_xticks([0, 1, 2.3]); ax.set_xticklabels(['random\n(matched)', 'NeuronAI\ncandidates', 'winners on\nfresh streams'], fontsize=6)
ax.axhline(0, color='#9a9994', lw=0.7); ax.set_ylabel('Distance reduction (%)')
ax.set_title('Guided vs. random search (same budget)')
save(fig, 'Figure9_single_case')

# =========================================================================== Figure 8 intervention across recordings
iv = pd.read_csv(f'{R}/intervention_results.csv')
fig = plt.figure(figsize=(7.2, 6.4))
gs = fig.add_gridspec(2, 3, width_ratios=[1.15, 1, 1.25], hspace=0.95, wspace=0.85)
ax = fig.add_subplot(gs[0, 0]); panel(ax, 'a', x=-0.35)
for j, g in enumerate(['ASD', 'TD']):
    sub = iv[iv.group == g]
    if MANY:   # one point per child: median over that child's recordings
        sub = sub.groupby('child')[['random_improvement_confirmed', 'improvement_confirmed']].median().reset_index()
    x0 = j * 2.4
    for _, rw in sub.iterrows():
        ax.plot([x0, x0 + 1], [rw.random_improvement_confirmed, rw.improvement_confirmed], color=gcol[g], alpha=0.18, lw=0.6)
    ax.scatter(np.full(len(sub), x0), sub.random_improvement_confirmed, s=6, color=C_NULL, zorder=3, lw=0)
    ax.scatter(np.full(len(sub), x0 + 1), sub.improvement_confirmed, s=6, color=gcol[g], zorder=3, lw=0)
    for xx_, v in [(x0, sub.random_improvement_confirmed), (x0 + 1, sub.improvement_confirmed)]:
        ax.plot([xx_ - 0.25, xx_ + 0.25], [np.median(v)] * 2, color=C_TXT, lw=1.5, zorder=4)
ax.set_xticks([0, 1, 2.4, 3.4]); ax.set_xticklabels(['random', 'Neuron-\nAI', 'random', 'Neuron-\nAI'], fontsize=5.8)
ax.text(0.5, 1.03, 'ASD', transform=ax.get_xaxis_transform(), ha='center', color=C_ASD, fontweight='bold')
ax.text(2.9, 1.03, 'TD (LOCO)', transform=ax.get_xaxis_transform(), ha='center', color=C_TD, fontweight='bold')
lo_ = np.percentile(np.r_[iv.random_improvement_confirmed, iv.improvement_confirmed], 1)
ax.set_ylim(max(lo_ - 5, -100), None)
ax.axhline(0, color='#9a9994', lw=0.6); ax.set_ylabel(('Child median of confirmed\nreduction (%)') if MANY else 'Confirmed distance reduction (%)')
ax.set_title('Guided vs. random', pad=14)
ax = fig.add_subplot(gs[0, 1]); panel(ax, 'b', x=-0.5)
ax.scatter(iv.improvement_emulated, iv.improvement_confirmed, c=[gcol[g] for g in iv.group], s=7, alpha=0.75, lw=0)
lim = [min(iv.improvement_emulated.min(), iv.improvement_confirmed.min()) - 3, max(iv.improvement_emulated.max(), iv.improvement_confirmed.max()) + 3]
lim[0] = max(lim[0], -60)
ax.plot(lim, lim, color=C_TXT2, ls='--', lw=0.7); ax.set_xlim(lim); ax.set_ylim(lim)
ax.set_xlabel('Emulator estimate (%)'); ax.set_ylabel('Simulator, confirmed (%)')
ax.text(0.04, 0.96, f"r = {vs['intervention']['emulated_vs_confirmed_r']:.2f}", transform=ax.transAxes, va='top', fontsize=6.5)
ax.set_title('Emulator vs. simulator', fontsize=8)
a = iv[iv.group == 'ASD']
ax = fig.add_subplot(gs[0, 2]); panel(ax, 'c', x=-0.42)
sel = a[[f'u_{c}' for c in CONTROLS]]
up = (sel > 1e-6).mean(); dn = (sel < -1e-6).mean()
xx = np.arange(len(CONTROLS))
ax.bar(xx, up * 100, color=DIV_POS, width=0.65, label='increase (agonism)')
ax.bar(xx, -dn * 100, color=DIV_NEG, width=0.65, label='decrease (antagonism)')
ax.axhline(0, color='#52514e', lw=0.6)
ax.set_xticks(xx); ax.set_xticklabels([CONTROL_LABELS[c] for c in CONTROLS], rotation=60, ha='right', fontsize=6)
ax.set_ylabel('% of ASD recordings'); ax.legend(fontsize=5.4, loc='lower center', bbox_to_anchor=(0.5, 1.0), ncol=2, handlelength=1.0, columnspacing=0.6)
ax.set_title('Selected targets', pad=18)
ax = fig.add_subplot(gs[1, :]); panel(ax, 'd', x=-0.06)
a_sorted = a.sort_values(['child', 'condition'])
M = a_sorted[[f'u_{c}' for c in CONTROLS]].values.T
cm = LinearSegmentedColormap.from_list('div', [DIV_NEG, DIV_MID, DIV_POS])
im = ax.imshow(M, aspect='auto', cmap=cm, vmin=-1, vmax=1, interpolation='nearest')
ax.set_yticks(range(len(CONTROLS))); ax.set_yticklabels([CONTROL_LABELS[c] for c in CONTROLS], fontsize=6.3)
ax.grid(False)
bounds = np.cumsum(a_sorted.groupby('child').size().values)
for b in bounds[:-1]:
    ax.axvline(b - 0.5, color='#0b0b0b', lw=0.4 if MANY else 0.8)
starts = np.r_[0, bounds[:-1]]
if not MANY:
    for c, s0, s1 in zip(a_sorted.child.unique(), starts, bounds):
        ax.text((s0 + s1 - 1) / 2, -0.9, c, ha='center', fontsize=6.8, color=C_ASD, fontweight='bold')
ax.set_xticks([]); ax.set_xlabel(f'ASD recordings, grouped by child ({a_sorted.child.nunique()} children; vertical lines separate children)')
cb = fig.colorbar(im, ax=ax, fraction=0.02, pad=0.01); cb.set_label('control u', fontsize=6.5); cb.ax.tick_params(labelsize=6)
ax.set_title(f"Selected intervention vectors (within-child cosine {vs['intervention']['u_cosine_within_child']:.2f} vs. "
             f"between-child {vs['intervention']['u_cosine_between_child']:.2f}; permutation p {'< 0.001' if vs['intervention']['u_cosine_perm_p'] < 0.001 else '= %.3f' % vs['intervention']['u_cosine_perm_p']})", pad=14)
save(fig, 'Figure8_intervention_across_recordings')

# =========================================================================== Supplementary
nc = pd.read_csv(f'{R}/noise_ceiling.csv').set_index('feature')
ea = pd.read_csv(f'{R}/emulator_accuracy.csv').set_index('feature')
fig, ax = plt.subplots(figsize=(4.6, 2.6))
xx = np.arange(len(FEATURE_NAMES))
ax.bar(xx - 0.2, nc.loc[FEATURE_NAMES, 'noise_ceiling_R2'], 0.38, color='#d9d8d3', label='noise ceiling (4 seeds × 128 parameter sets)')
ax.bar(xx + 0.2, ea.loc[FEATURE_NAMES, 'R2_heldout'], 0.38, color=C_SIM, label='forward emulator (held-out simulations)')
ax.set_xticks(xx); ax.set_xticklabels([FEATURE_LABELS[f] for f in FEATURE_NAMES], rotation=45, ha='right', fontsize=6.3)
ax.set_ylabel('$R^2$'); ax.set_ylim(0, 1.08); ax.legend(fontsize=6, loc='lower left')
save(fig, 'FigureS1_emulator_noise_ceiling')

fig, axes = plt.subplots(2, 5, figsize=(7.2, 3.6))
for ax, f in zip(axes.ravel(), FEATURE_NAMES + ['_']):
    if f == '_':
        ax.axis('off'); continue
    for k, c in enumerate(children):
        v = df[df.child == c][f].values
        ax.scatter(np.full(len(v), k) + np.random.default_rng(k).uniform(-0.15, 0.15, len(v)), v, s=2 if MANY else 5, color=ccol[c], lw=0)
    if MANY:
        ax.set_xticks([]); ax.set_xlabel('children (ASD | TD)', fontsize=6)
    else:
        ax.set_xticks(range(len(children))); ax.set_xticklabels([c.replace('-', '\n') for c in children], fontsize=5)
    ax.set_title(FEATURE_LABELS[f], fontsize=7)
fig.tight_layout()
save(fig, 'FigureS2_features_by_child')
print('figures done')
