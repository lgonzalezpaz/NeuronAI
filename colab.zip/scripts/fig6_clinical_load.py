"""Figure 6 - clinical association (ASRS) and attentional-load effects of twin parameters (complete cohort)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from fig_style import setup, save, panel, C_TD, C_ASD, C_SIM, C_TXT, C_TXT2, GRID, DIV_NEG, DIV_MID, DIV_POS
from neuronai.model import FIT_PARAMS, FIT_LABELS
from neuronai.features import FEATURE_NAMES, FEATURE_LABELS

R = 'results'
if not (os.path.exists(f'{R}/asrs_association.csv') and os.path.exists(f'{R}/load_effects.csv')):
    sys.exit('Figure 9 needs asrs_association.csv and load_effects.csv (complete cohort only)')
setup()
asrs = pd.read_csv(f'{R}/asrs_association.csv')
ld = pd.read_csv(f'{R}/load_effects.csv').set_index('variable')
LAB = {**FIT_LABELS, **FEATURE_LABELS}
VARS = FIT_PARAMS + FEATURE_NAMES
cm = LinearSegmentedColormap.from_list('div', [DIV_NEG, DIV_MID, DIV_POS])

fig = plt.figure(figsize=(7.2, 6.0))
gs = fig.add_gridspec(2, 3, width_ratios=[1.0, 1.25, 1.05], height_ratios=[1, 1], hspace=0.55, wspace=0.95)

# (a) ASRS total: Spearman rho within each cohort
ax = fig.add_subplot(gs[:, 0]); panel(ax, 'a', x=-0.9)
cols = [('ASD', 'ASD'), ('TD', 'TD'), ('all', 'all')]
M = np.full((len(VARS), len(cols)), np.nan); Q = np.ones_like(M)
for j, (c, _) in enumerate(cols):
    t = asrs[(asrs.cohort == c) & (asrs.score == 'ASRS_Total_T')].set_index('variable')
    for i, v in enumerate(VARS):
        if v in t.index:
            M[i, j] = t.loc[v, 'spearman_rho']; Q[i, j] = t.loc[v, 'q_fdr']
im = ax.imshow(M, cmap=cm, vmin=-0.6, vmax=0.6, aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        ax.text(j, i, f'{M[i, j]:+.2f}' + ('*' if Q[i, j] < 0.05 else ''), ha='center', va='center', fontsize=5.3,
                color='white' if abs(M[i, j]) > 0.4 else C_TXT, fontweight='bold' if Q[i, j] < 0.05 else 'normal')
ax.set_xticks(range(len(cols))); ax.set_xticklabels([l for _, l in cols], fontsize=6.3)
ax.xaxis.set_ticks_position('top'); ax.xaxis.set_label_position('top'); ax.tick_params(axis='x', length=0, pad=2)
ax.set_yticks(range(len(VARS))); ax.set_yticklabels([LAB[v] for v in VARS], fontsize=5.8)
ax.axhline(len(FIT_PARAMS) - 0.5, color=C_TXT, lw=0.8)
ax.grid(False)
cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02, orientation='horizontal', location='bottom')
cb.set_label('Spearman ρ with ASRS total T (child means; * q < 0.05)', fontsize=5.6); cb.ax.tick_params(labelsize=5.5)
ax.set_title('Autistic-trait severity', pad=16)

# (b) attentional load: effect sizes (dz) of task vs rest and high vs low load
ax = fig.add_subplot(gs[:, 1]); panel(ax, 'b', x=-0.45)
yy = np.arange(len(VARS))[::-1]
for off, col, q, lab, c in [(0.18, 'task_minus_rest_dz', 'task_vs_rest_wilcoxon_q', 'task − rest', C_SIM),
                            (-0.18, 'high_minus_low_dz', 'friedman_load_q', 'high − low load', '#6250d6')]:
    v = ld.loc[VARS, col].values; qq = ld.loc[VARS, q].values
    ax.barh(yy + off, v, height=0.34, color=[c if x < 0.05 else '#d9d8d3' for x in qq], label=lab)
ax.axvline(0, color='#9a9994', lw=0.7)
ax.set_yticks(yy); ax.set_yticklabels([LAB[v] for v in VARS], fontsize=5.8)
ax.axhline(len(FEATURE_NAMES) - 0.5, color=C_TXT, lw=0.8)
ax.set_xlabel("within-child effect size d$_z$", fontsize=6.3)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=C_SIM, label='task − rest'), Patch(color='#6250d6', label='high − low load'),
                   Patch(color='#d9d8d3', label='q ≥ 0.05')], fontsize=5.6, loc='upper center', bbox_to_anchor=(0.5, -0.08), ncol=3,
          handlelength=1.0, columnspacing=0.8)
ax.set_title(f"Attentional load ({int(ld['n_children_load'].iloc[0])} children)", pad=8, fontsize=7.5)

# (c, d) strongest twin-parameter associations with ASRS within each cohort
pp = pd.read_csv(f'{R}/participants.csv').set_index('child')
tw = pd.read_csv(f'{R}/twin_parameters.csv')
for k, (g, colr) in enumerate([('ASD', C_ASD), ('TD', C_TD)]):
    ax = fig.add_subplot(gs[k, 2]); panel(ax, 'cd'[k], x=-0.32)
    t = asrs[(asrs.cohort == g) & (asrs.score == 'ASRS_Total_T') & (asrs.kind == 'parameter')].sort_values('p')
    v = t.iloc[0]
    cmn = tw.groupby('child')[f"{v.variable}_full"].mean()
    cmn = cmn[[c for c in cmn.index if c.startswith(g)]]
    y = pp.loc[cmn.index, 'ASRS_Total_T']
    ax.scatter(cmn.values, y.values, s=12, color=colr, lw=0)
    b1, b0 = np.polyfit(cmn.values, y.values, 1)
    xs = np.linspace(cmn.min(), cmn.max(), 10); ax.plot(xs, b0 + b1 * xs, color=C_TXT2, lw=0.8, ls='--')
    ax.set_xlabel(f'{FIT_LABELS[v.variable]} (child mean)', fontsize=6.3); ax.set_ylabel('ASRS total T', fontsize=6.3)
    ax.text(0.03, 0.97, f"ρ = {v.spearman_rho:+.2f}\np = {v.p:.3f}, q = {v.q_fdr:.2f}", transform=ax.transAxes, va='top', fontsize=5.8, bbox=dict(fc='white', ec='none', alpha=0.85, pad=1))
    ax.set_title(f"{g}: strongest parameter", fontsize=7)
save(fig, 'Figure6_clinical_load')
print('figure 9 done')
