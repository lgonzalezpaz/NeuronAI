"""Graphical abstract (1328 x 531 px minimum; produced at 600 dpi)."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle
from fig_style import setup, save, C_TD, C_ASD, C_SIM, C_TXT, C_TXT2

setup()
R = 'results'
df = pd.read_csv(f'{R}/empirical_features.csv'); df = df[~df.excluded].reset_index(drop=True)
emp = np.load(f'{R}/empirical_psd.npz'); ids = list(emp['ids']); fr = emp['freqs']
ppc = np.load(f'{R}/ppc.npz', allow_pickle=True)
vs = json.load(open(f'{R}/validation_summary.json'))
rec = pd.read_csv(f'{R}/recovery_inverse.csv')

fig = plt.figure(figsize=(13.28 / 2.0, 5.31 / 2.0))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis('off')
def card(x, w, title, col):
    ax.add_patch(FancyBboxPatch((x, 7.5), w, 29, boxstyle='round,pad=0.3,rounding_size=1.2', fc='white', ec=col, lw=1.2))
    ax.text(x + w / 2, 34.6, title, ha='center', va='center', fontsize=7.2, fontweight='bold', color=C_TXT)
card(1.5, 27, 'Scalp EEG of children', C_ASD)
card(36, 28, 'Biophysical digital twin', C_SIM)
card(71.5, 27, 'In silico pharmacology', '#6250d6')
for x0, x1 in [(29.2, 35.4), (64.7, 70.9)]:
    ax.annotate('', xy=(x1, 22), xytext=(x0, 22), arrowprops=dict(arrowstyle='-|>', color='#52514e', lw=1.4))
# panel 1: real spectra
a1 = fig.add_axes([0.075, 0.37, 0.195, 0.42])
E = emp['logpsd']; grp = np.array(['ASD' if s.startswith('ASD') else 'TD' for s in ids])
keep = np.isin(ids, df.id.values)
for g, c in [('TD', C_TD), ('ASD', C_ASD)]:
    m = (grp == g) & keep
    a1.plot(fr, E[m].mean(0), color=c, lw=1.4, label=g)
    a1.fill_between(fr, E[m].mean(0) - E[m].std(0), E[m].mean(0) + E[m].std(0), color=c, alpha=0.15, lw=0)
a1.set_ylabel('log rel. power', fontsize=5.5); a1.tick_params(labelsize=5)
a1.legend(fontsize=5.5, loc='upper right'); a1.set_xlim(1, 30)
ax.text(15, 9.0, f'{len(df):,} recordings · {df.child.nunique()} children · 1–30 Hz', ha='center', fontsize=5.6, color=C_TXT2)
# panel 2: twin fit example + text
a2 = fig.add_axes([0.40, 0.42, 0.20, 0.36])
sid = df.id[0]; i = 0
S = ppc['LP_full'][i]
a2.fill_between(fr, np.percentile(S, 2.5, 0), np.percentile(S, 97.5, 0), color=C_SIM, alpha=0.25, lw=0)
a2.plot(fr, S.mean(0), color=C_SIM, lw=1.3, label='twin')
a2.plot(fr, E[ids.index(sid)], color=C_ASD, lw=1.2, label='recorded')
a2.legend(fontsize=5.3, loc='lower left'); a2.set_xticks([]); a2.set_yticks([]); a2.set_xlim(1, 30)
ax.text(50, 14.2, 'AMPA · NMDA-GluN2A/2B · GABA$_A$ · slow GABA\nDA · 5-HT · NE gain control · 17 coupled columns',
        ha='center', va='center', fontsize=5.4, color=C_TXT2)
ax.text(50, 9.6, 'simulation-based inference:\ndeep ensemble + conformal intervals', ha='center', fontsize=5.2, color=C_TXT)
# panel 3: intervention summary
a3 = fig.add_axes([0.745, 0.40, 0.21, 0.38])
iv = pd.read_csv(f'{R}/intervention_results.csv'); a = iv[iv.group == 'ASD']
bins = np.linspace(np.percentile(np.r_[a.random_improvement_confirmed, a.improvement_confirmed], 2), max(a.improvement_confirmed.max(), a.random_improvement_confirmed.max()), 16)
a3.hist(a.random_improvement_confirmed.clip(bins[0]), bins=bins, color='#c7c6c1', alpha=0.9, label='random search')
a3.hist(a.improvement_confirmed.clip(bins[0]), bins=bins, color='#6250d6', alpha=0.75, label='NeuronAI-guided')
a3.tick_params(labelsize=5); a3.set_yticks([])
a3.legend(fontsize=5.0, loc='upper left')
ax.text(85, 9.0, 'distance reduction to TD (%), 129 sparse\ntarget combinations, simulator-confirmed', ha='center', fontsize=5.2, color=C_TXT2)
ci = vs['child_identification']
iv_ = vs['intervention']
ax.text(50, 3.0, f"{df.child.nunique()} children · out-of-sample prediction · child identification {100*ci['accuracy']:.0f}% "
        f"(chance {100/ci['n_children']:.1f}%) · guided search better than random in "
        f"{iv_.get('ASD_children_ai_better_pct', iv_['ASD_pct_ai_better_than_random']):.0f}% of children with ASD · "
        f"pharmaco-EEG benchmarks incl. failures · open code",
        ha='center', fontsize=4.7, color=C_TXT, fontweight='bold')
fig.savefig('figures/Graphical_abstract.png', dpi=600, bbox_inches=None)
fig.savefig('figures/Graphical_abstract.pdf', bbox_inches=None)
fig.savefig('figures/Graphical_abstract.tiff', dpi=600, bbox_inches=None, pil_kwargs={'compression': 'tiff_lzw'})
print('ok')
