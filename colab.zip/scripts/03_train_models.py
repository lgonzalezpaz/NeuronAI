"""Step 3 - train the amortised inverse ensemble and the forward emulator; evaluate
parameter recovery (identifiability), conformal coverage and emulator accuracy on
held-out simulations."""
import json, os, pickle, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.bank import load_bank
from neuronai.model import FIT_PARAMS, FIT_BOUNDS, params_to_unit
from neuronai.inference import InverseEnsemble, ForwardEmulator, SpectralEmulator, EMU_INPUTS, emu_matrix
from neuronai.features import FEATURE_NAMES

R = 'results'
bI, bE = load_bank(f'{R}/bank_I.npz'), load_bank(f'{R}/bank_E.npz')


def theta_dict(b):
    return {n: b['theta'][:, i] for i, n in enumerate(b['theta_names'])}


# ---------------- inverse model (bank I) ----------------
ok = bI['ok']
X = bI['X'][ok]
Z = params_to_unit(theta_dict(bI))[ok]
rng = np.random.default_rng(0)
perm = rng.permutation(len(X))
n_tr, n_cal = int(0.7 * len(X)), int(0.1 * len(X))
tr, cal, te = perm[:n_tr], perm[n_tr:n_tr + n_cal], perm[n_tr + n_cal:]
inv = InverseEnsemble().fit(X[tr], Z[tr], X[cal], Z[cal], coverage=0.90)
pred = inv.predict(X[te])
lo, hi = inv.interval(X[te])
rows = []
for i, n in enumerate(FIT_PARAMS):
    r2 = 1 - ((pred[:, i] - Z[te, i]) ** 2).sum() / ((Z[te, i] - Z[te, i].mean()) ** 2).sum()
    cov = float(((Z[te, i] >= lo[:, i]) & (Z[te, i] <= hi[:, i])).mean())
    width = float((hi[:, i] - lo[:, i]).mean())
    rows.append({'parameter': n, 'R2': r2, 'pearson_r': np.corrcoef(pred[:, i], Z[te, i])[0, 1],
                 'conformal_coverage_90': cov, 'mean_interval_width_unit': width,
                 'contraction': 1 - width})
rec = pd.DataFrame(rows)
rec.to_csv(f'{R}/recovery_inverse.csv', index=False)
np.savez_compressed(f'{R}/recovery_test.npz', pred=pred, true=Z[te], lo=lo, hi=hi)
print(rec.round(3))

# ---------------- forward emulator (banks I + E) ----------------
tE = theta_dict(bE)
tI = theta_dict(bI)
UE, UI = emu_matrix(tE), emu_matrix(tI)
Xe = np.concatenate([bI['X'][bI['ok']], bE['X'][bE['ok']]])
Ue = np.concatenate([UI[bI['ok']], UE[bE['ok']]])
perm = np.random.default_rng(1).permutation(len(Xe))
n_tr = int(0.85 * len(Xe))
emu = ForwardEmulator().fit(Ue[perm[:n_tr]], Xe[perm[:n_tr]])
sc = emu.score(Ue[perm[n_tr:]], Xe[perm[n_tr:]], FEATURE_NAMES)
pd.DataFrame({'feature': list(sc), 'R2_heldout': list(sc.values())}).to_csv(f'{R}/emulator_accuracy.csv', index=False)
print('Emulator held-out R2:', {k: round(v, 3) for k, v in sc.items()})

# ---------------- spectral emulator (full 1-30 Hz relative log-spectrum) ----------------
LPe = np.concatenate([bI['logpsd'][bI['ok']], bE['logpsd'][bE['ok']]])
semu = SpectralEmulator(seed=11).fit(Ue[perm[:n_tr]], LPe[perm[:n_tr]])
Ph = semu.predict(Ue[perm[n_tr:]]); Tt = LPe[perm[n_tr:]]
spec_r2 = 1 - ((Ph - Tt) ** 2).sum(1) / ((Tt - Tt.mean(1, keepdims=True)) ** 2).sum(1)
print('Spectral emulator: median held-out spectral R2 =', round(float(np.median(spec_r2)), 3))
pd.DataFrame({'heldout_spectral_R2': spec_r2}).to_csv(f'{R}/spectral_emulator_accuracy.csv', index=False)

with open(f'{R}/models.pkl', 'wb') as f:
    pickle.dump({'inverse': inv, 'emulator': emu, 'spec_emulator': semu}, f)
json.dump({'n_bank_I': int(ok.sum()), 'n_bank_E': int(bE['ok'].sum()), 'n_train_inv': len(tr),
           'n_cal_inv': len(cal), 'n_test_inv': len(te), 'conformal_q': inv.q.tolist()},
          open(f'{R}/training_summary.json', 'w'), indent=2)
