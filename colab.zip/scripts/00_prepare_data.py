"""Step 0 - prepare the complete Duville et al. datasets (as downloaded from Mendeley Data) for NeuronAI.

Usage:  python scripts/00_prepare_data.py --asd <ASD download folder or zip> --td <TD download folder or zip>

The Mendeley archives contain EEG/PartNN/<recording>.gdf plus spreadsheets (Demographics, ASRS, Behaviour).
TD file names lack a group prefix (Part05_restEO.gdf) and the same name exists in both cohorts, so every
recording is linked into data/<GROUP>/ under a unique id (<GROUP>_PartNN_<condition>), and the mapping is
written to results/recording_id_map.csv. Spreadsheets are copied to data_meta/<GROUP>/ with short names.
Nothing is modified in the original download."""
import argparse, glob, hashlib, os, re, shutil, zipfile
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument('--asd', required=True)
ap.add_argument('--td', required=True)
ap.add_argument('--data', default='data')
ap.add_argument('--meta', default='data_meta')
ap.add_argument('--results', default='results')
a = ap.parse_args()
EEG = ('.gdf', '.edf', '.bdf', '.set', '.mat')
META = ('.xlsx', '.xls', '.csv', '.tsv', '.txt', '.json')


def short_name(rel, maxlen=100):
    parts = rel.replace('\\', '/').split('/')
    base = '__'.join(parts[-2:]) if len(parts) > 1 else parts[0]
    stem, ext = os.path.splitext(base)
    h = hashlib.md5(rel.encode()).hexdigest()[:6]
    return f"{re.sub(r'[^A-Za-z0-9_.-]+', '_', stem)[: maxlen - len(ext) - 8]}_{h}{ext}"


def source_root(path, grp):
    if os.path.isfile(path) and path.lower().endswith('.zip'):
        dest = os.path.join(a.data, f'_extracted_{grp}')
        if not os.path.isdir(dest):
            with zipfile.ZipFile(path) as zf:
                zf.extractall(dest)
        for zp in glob.glob(os.path.join(dest, '**', '*.zip'), recursive=True):
            with zipfile.ZipFile(zp) as zf:
                zf.extractall(os.path.splitext(zp)[0])
            os.remove(zp)
        return dest
    return path


rows = []
os.makedirs(a.results, exist_ok=True)
for grp, src in [('ASD', a.asd), ('TD', a.td)]:
    root = source_root(src, grp)
    out = os.path.join(a.data, grp); os.makedirs(out, exist_ok=True)
    files = sorted(f for f in glob.glob(os.path.join(root, '**', '*'), recursive=True) if os.path.isfile(f))
    eeg = [f for f in files if f.lower().endswith(EEG)]
    names = [os.path.basename(f).lower() for f in eeg]
    for f in eeg:
        b = os.path.basename(f)
        new = b
        if names.count(b.lower()) > 1:
            new = f"{re.sub(r'[^A-Za-z0-9]+', '', os.path.basename(os.path.dirname(f)))[:20]}_{new}"
        if not new.upper().startswith(grp):
            new = f'{grp}_{new}'
        dst = os.path.join(out, new)
        if not os.path.exists(dst):
            try:
                os.symlink(os.path.abspath(f), dst)
            except OSError:
                shutil.copy(f, dst)
        rows.append({'group': grp, 'original_path': os.path.relpath(f, root), 'recording_id': os.path.splitext(new)[0]})
    md = os.path.join(a.meta, grp); os.makedirs(md, exist_ok=True)
    for f in files:
        if f.lower().endswith(META) and os.path.getsize(f) < 50e6:
            shutil.copy(f, os.path.join(md, short_name(os.path.relpath(f, root))))
    print(grp, len(eeg), 'recordings linked into', out)
pd.DataFrame(rows).to_csv(os.path.join(a.results, 'recording_id_map.csv'), index=False)
print('mapping written to', os.path.join(a.results, 'recording_id_map.csv'))
