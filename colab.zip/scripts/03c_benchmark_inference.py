"""Step 3c - comparison of inverse-inference strategies on held-out simulations.

Methods compared (identical training bank and held-out test set):
  1. kNN-ABC: mean parameters of the 20 nearest simulations in standardised descriptor space
  2. Random forest regression (300 trees)
  3. NeuronAI amortised deep ensemble (posterior mean)
  4. NeuronAI amortised + emulator-gradient refinement within conformal intervals (proposed)
Metrics: parameter recovery (R^2), data-space discrepancy of the estimate (descriptors and full
log-spectrum re-simulated with the stochastic simulator) and computing time per recording."""
import os, pickle, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from neuronai.bank import load_bank
from neuronai.model import FIT_PARAMS, params_to_unit, params_from_unit, simulate
from neuronai.features import extract_features, feature_matrix, psd, normalised_log_psd
from neuronai.inference import refine_twin

R = 'results'
N_TEST_SIM = 150
b = load_bank(f'{R}/bank_I.npz')
ok = b['ok']
X = b['X'][ok]; LP = b['logpsd'][ok]
Z = params_to_unit({n: b['theta'][:, i] for i, n in enumerate(b['theta_names'])})[ok]
rng = np.random.default_rng(0)                      # identical split to step 3
perm = rng.permutation(len(X))
n_tr, n_cal = int(0.7 * len(X)), int(0.1 * len(X))
tr, te = perm[:n_tr], perm[n_tr + n_cal:]
te = te[:N_TEST_SIM]
m = pickle.load(open(f'{R}/models.pkl', 'rb')); inv, emu, semu = m['inverse'], m['emulator'], m['spec_emulator']
sc = StandardScaler().fit(X[tr])
scale = X[tr].std(0)
est, times = {}, {}
t = time.time()
Xs_tr = sc.transform(X[tr])
knn = []
for x in sc.transform(X[te]):
    d = ((Xs_tr - x) ** 2).sum(1)
    knn.append(Z[tr][np.argsort(d)[:20]].mean(0))
est['kNN-ABC'] = np.array(knn); times['kNN-ABC'] = (time.time() - t) / len(te)
t = time.time()
rf = RandomForestRegressor(n_estimators=300, min_samples_leaf=3, n_jobs=1, random_state=0).fit(X[tr], Z[tr])
t_fit = time.time() - t
t = time.time(); est['Random forest'] = rf.predict(X[te]); times['Random forest'] = (time.time() - t) / len(te)
t = time.time(); est['NeuronAI amortised'] = inv.predict(X[te]); times['NeuronAI amortised'] = (time.time() - t) / len(te)
t = time.time()
lo, hi = inv.interval(X[te])
ref = []
for k in range(len(te)):
    nn = np.argsort((((X[te][k] - X[tr]) / scale) ** 2).sum(1))[:5]
    z, _ = refine_twin(X[te][k], emu, np.vstack([est['NeuronAI amortised'][k], Z[tr][nn]]), scale, lo[k], hi[k],
                       spectrum=LP[te][k], spec_emulator=semu, spec_scale=LP[tr].std(0))
    ref.append(z)
est['NeuronAI amortised + refinement'] = np.array(ref)
times['NeuronAI amortised + refinement'] = (time.time() - t) / len(te) + times['NeuronAI amortised']

est['True parameters (noise ceiling)'] = Z[te]; times['True parameters (noise ceiling)'] = float('nan')
rows = []
for name, E in est.items():
    r2 = 1 - ((E - Z[te]) ** 2).sum(0) / ((Z[te] - Z[te].mean(0)) ** 2).sum(0)
    th = params_from_unit(E)
    res = simulate(th, duration=20.0, seed=777)       # same noise seed for every method
    F = feature_matrix(extract_features(res.eeg, res.fs))
    f, P = psd(res.eeg, res.fs); _, lp = normalised_log_psd(f, P)
    E_lp = LP[te]
    spec_r2 = 1 - ((E_lp - lp) ** 2).sum(1) / ((E_lp - E_lp.mean(1, keepdims=True)) ** 2).sum(1)
    feat_err = np.abs((F - X[te]) / scale).mean(1)
    rows.append({'method': name, 'mean_R2_parameters': float(r2.mean()),
                 'R2_identifiable_(B,rho,K,A)': float(r2[[FIT_PARAMS.index(p) for p in ['B', 'rho', 'K', 'A']]].mean()),
                 'median_spectral_R2_resimulated': float(np.median(spec_r2)),
                 'median_descriptor_error_SD': float(np.median(feat_err)),
                 'seconds_per_recording': times[name]})
    print(rows[-1], flush=True)
out = pd.DataFrame(rows)
out.to_csv(f'{R}/inference_benchmark.csv', index=False)
print(out.round(3).to_string())
