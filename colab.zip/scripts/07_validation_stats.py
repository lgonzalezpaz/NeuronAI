"""Step 7 - validation statistics against real EEG and child-level inference.

Outputs (results/):
  ppc_summary.csv            posterior-predictive and out-of-sample agreement per feature
  ppc_spectral_r2.csv        per-recording R^2 between simulated and empirical log-spectra
  reliability.csv            split-half ICC(2,1), between-child ICC(1) of twin parameters
  identification.json        child identification from twin parameters (leave-one-recording-out)
  group_params.csv           ASD vs TD twin parameters (child-level permutation, cluster bootstrap)
  intervention_summary.json  aggregate intervention statistics, nulls and consistency
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.model import FIT_PARAMS, CONTROLS
from neuronai.features import FEATURE_NAMES
from neuronai.stats import (icc_ci, icc_1, cluster_bootstrap_ci, child_permutation_test, hedges_g, fdr_bh,
                            identify_discriminant, sign_flip_test)
from scipy.stats import spearmanr, wilcoxon, friedmanchisquare

R = 'results'
df = pd.read_csv(f'{R}/empirical_features.csv'); df = df[~df.excluded].reset_index(drop=True)
tw = pd.read_csv(f'{R}/twin_parameters.csv')
ppc = np.load(f'{R}/ppc.npz', allow_pickle=True)
emp_psd = np.load(f'{R}/empirical_psd.npz')
child = df['child'].values
summary = {}

# ------------------------------------------------------------- 1. PPC & out-of-sample
F_sim = ppc['F_full'].mean(1)       # in-sample twin prediction
F_oos = ppc['F_h1'].mean(1)         # twin fitted on first half -> predicts second half
X = df[FEATURE_NAMES].values
X1 = df[[f + '_h1' for f in FEATURE_NAMES]].values
X2 = df[[f + '_h2' for f in FEATURE_NAMES]].values
rows = []
for j, f in enumerate(FEATURE_NAMES):
    # leave-one-child-out group-mean baseline (population model without personalisation)
    base = np.array([X2[(df.group == g) & (df.child != c), j].mean() for g, c in zip(df.group, df.child)])
    mae_tw = np.abs(F_oos[:, j] - X2[:, j]).mean()
    mae_base = np.abs(base - X2[:, j]).mean()
    mae_rt = np.abs(X1[:, j] - X2[:, j]).mean()
    # within-child (condition-to-condition) tracking: correlation after removing child means
    dm = lambda v: v - pd.Series(v).groupby(child).transform('mean').values
    rows.append({'feature': f,
                 'r_in_sample': np.corrcoef(F_sim[:, j], X[:, j])[0, 1],
                 'r_out_of_sample': np.corrcoef(F_oos[:, j], X2[:, j])[0, 1],
                 'r_within_child_oos': np.corrcoef(dm(F_oos[:, j]), dm(X2[:, j]))[0, 1],
                 'r_test_retest': np.corrcoef(X1[:, j], X2[:, j])[0, 1],
                 'MAE_twin_oos': mae_tw, 'MAE_group_mean': mae_base, 'MAE_test_retest': mae_rt,
                 'skill_vs_group_mean': 1 - mae_tw / mae_base,
                 'bias_in_sample': float((F_sim[:, j] - X[:, j]).mean())})
ppc_tab = pd.DataFrame(rows)
ppc_tab.to_csv(f'{R}/ppc_summary.csv', index=False)
print(ppc_tab.round(3).to_string())

ids = list(emp_psd['ids'])
E = np.stack([emp_psd['logpsd'][ids.index(s)] for s in df.id])
S = ppc['LP_full'].mean(1)
r2 = 1 - ((E - S) ** 2).sum(1) / ((E - E.mean(1, keepdims=True)) ** 2).sum(1)
# spectral R^2 of the leave-one-child-out group-mean spectrum (non-personalised baseline)
Gm = np.stack([E[(df.group == g).values & (df.child != c).values].mean(0) for g, c in zip(df.group, df.child)])
r2_base = 1 - ((E - Gm) ** 2).sum(1) / ((E - E.mean(1, keepdims=True)) ** 2).sum(1)
pd.DataFrame({'id': df.id, 'group': df.group, 'child': child, 'R2_twin': r2, 'R2_group_mean': r2_base}).to_csv(
    f'{R}/ppc_spectral_r2.csv', index=False)
summary['spectral_R2_twin'] = cluster_bootstrap_ci(r2, child, np.median)
summary['spectral_R2_group_mean'] = cluster_bootstrap_ci(r2_base, child, np.median)
summary['spectral_R2_twin_better_pct'] = float((r2 > r2_base).mean() * 100)
# ablation: amortised posterior mean without emulator refinement
Sa = ppc['LP_amort'].mean(1)
r2a = 1 - ((E - Sa) ** 2).sum(1) / ((E - E.mean(1, keepdims=True)) ** 2).sum(1)
summary['spectral_R2_amortised_only'] = cluster_bootstrap_ci(r2a, child, np.median)
Fa = ppc['F_amort'].mean(1)
SC = df[df.group == 'TD'][FEATURE_NAMES].std().values
summary['feature_error_twin_TDsd'] = dict(zip(FEATURE_NAMES, np.round(np.abs(F_sim - X).mean(0) / SC, 3).tolist()))
summary['feature_error_amortised_TDsd'] = dict(zip(FEATURE_NAMES, np.round(np.abs(Fa - X).mean(0) / SC, 3).tolist()))
pd.DataFrame({'id': df.id, 'R2_amortised': r2a}).to_csv(f'{R}/ppc_spectral_r2_amortised.csv', index=False)

# ------------------------------------------------------------- 2. reliability & identifiability of children
rel = []
for n in FIT_PARAMS:
    icc, lo, hi = icc_ci(tw[f'{n}_h1'].values, tw[f'{n}_h2'].values)
    rel.append({'parameter': n, 'ICC_split_half': icc, 'ci_lo': lo, 'ci_hi': hi,
                'ICC1_between_child': icc_1(tw[f'{n}_full'].values, child)})
for f in FEATURE_NAMES:
    icc, lo, hi = icc_ci(df[f + '_h1'].values, df[f + '_h2'].values)
    rel.append({'parameter': 'feature:' + f, 'ICC_split_half': icc, 'ci_lo': lo, 'ci_hi': hi,
                'ICC1_between_child': icc_1(df[f].values, child)})
pd.DataFrame(rel).to_csv(f'{R}/reliability.csv', index=False)

P = tw[[f'{n}_full' for n in FIT_PARAMS]].values
Pz = (P - P.mean(0)) / P.std(0)


def identify(M, labels):
    hits = 0
    for k in range(len(M)):
        m = np.arange(len(M)) != k
        cents = {c: M[m & (labels == c)].mean(0) for c in np.unique(labels[m])}
        pred = min(cents, key=lambda c: np.linalg.norm(M[k] - cents[c]))
        hits += pred == labels[k]
    return hits / len(M)


acc = identify(Pz, child)
rng = np.random.default_rng(0)
N_PERM_ID = 200 if len(child) < 300 else 50
perm = [identify(Pz, rng.permutation(child)) for _ in range(N_PERM_ID)]
chance = max(pd.Series(child).value_counts(normalize=True))
summary['child_identification'] = {'accuracy': acc, 'perm_p': float((1 + sum(p >= acc for p in perm)) / (1 + len(perm))),
                                   'perm_mean': float(np.mean(perm)), 'majority_chance': float(chance),
                                   'n_children': int(len(np.unique(child))), 'n_recordings': int(len(child))}

# discriminant identification (secondary): shrinkage LDA on the nine twin parameters, trained in each fold
# on the training recordings and on the split-half twins of those recordings
H = [tw[[f'{n}_{h}' for n in FIT_PARAMS]].values for h in ('h1', 'h2')]
acc_l = identify_discriminant(P, child, H)
rng = np.random.default_rng(2)
perm_l = []
for _ in range(N_PERM_ID):
    pc = rng.permutation(len(child))          # permute recordings, keeping each recording's halves together
    perm_l.append(identify_discriminant(P[pc], child, [h[pc] for h in H]))
Fobs = df[FEATURE_NAMES].values
summary['child_identification_discriminant'] = {
    'accuracy': acc_l, 'perm_p': float((1 + sum(p >= acc_l for p in perm_l)) / (1 + len(perm_l))), 'perm_mean': float(np.mean(perm_l)),
    'reference_raw_descriptors_discriminant': identify_discriminant(Fobs, child),
    'reference_raw_descriptors_centroid': identify(((Fobs - Fobs.mean(0)) / Fobs.std(0)), child)}
# identification within each cohort (removes any contribution of the acquisition system)
for g in ['ASD', 'TD']:
    m = (df.group == g).values
    summary['child_identification_discriminant'][f'within_{g}'] = {
        'accuracy_centroid': identify(Pz[m], child[m]),
        'accuracy_discriminant': identify_discriminant(P[m], child[m], [h[m] for h in H]),
        'reference_raw_descriptors_discriminant': identify_discriminant(Fobs[m], child[m]),
        'chance': float(1 / len(np.unique(child[m]))), 'n_children': int(len(np.unique(child[m]))),
        'n_recordings': int(m.sum())}
print('child identification: centroid', round(acc, 3), '| discriminant', round(acc_l, 3),
      '| raw descriptors', round(summary['child_identification_discriminant']['reference_raw_descriptors_discriminant'], 3))

# ------------------------------------------------------------- 3. group comparison of twin parameters
gp = []
for n in FIT_PARAMS + FEATURE_NAMES:
    v = tw[f'{n}_full'].values if n in FIT_PARAMS else df[n].values
    diff, p, nperm = child_permutation_test(v, df.group.values, child)
    a, b = v[df.group == 'ASD'], v[df.group == 'TD']
    ca = child[df.group == 'ASD']; cb = child[df.group == 'TD']
    rng = np.random.default_rng(1)
    la, lb = np.unique(ca), np.unique(cb)
    bs = []
    for _ in range(2000):
        sa = np.concatenate([rng.choice(a[ca == c], (ca == c).sum()) for c in rng.choice(la, len(la))])
        sb = np.concatenate([rng.choice(b[cb == c], (cb == c).sum()) for c in rng.choice(lb, len(lb))])
        bs.append(hedges_g(sa, sb))
    gp.append({'variable': n, 'kind': 'parameter' if n in FIT_PARAMS else 'feature',
               'ASD_mean': a.mean(), 'ASD_sd': a.std(ddof=1), 'TD_mean': b.mean(), 'TD_sd': b.std(ddof=1),
               'hedges_g': hedges_g(a, b), 'g_ci_lo': np.percentile(bs, 2.5), 'g_ci_hi': np.percentile(bs, 97.5),
               'p_child_permutation': p, 'n_permutations': nperm})
gp = pd.DataFrame(gp)
gp['q_fdr'] = fdr_bh(gp['p_child_permutation'].values)
gp.to_csv(f'{R}/group_params.csv', index=False)
print(gp.round(3).to_string())

# ------------------------------------------------------------- 4. intervention statistics
iv = pd.read_csv(f'{R}/intervention_results.csv')
asd, td = iv[iv.group == 'ASD'], iv[iv.group == 'TD']
s = {}
for tag, sub in [('ASD', asd), ('TD', td)]:
    s[f'{tag}_D0'] = cluster_bootstrap_ci(sub.D0.values, sub.child.values)
    s[f'{tag}_improvement_emulated'] = cluster_bootstrap_ci(sub.improvement_emulated.values, sub.child.values)
    s[f'{tag}_improvement_confirmed_mean'] = cluster_bootstrap_ci(sub.improvement_confirmed.values, sub.child.values)
    s[f'{tag}_improvement_confirmed_median'] = cluster_bootstrap_ci(sub.improvement_confirmed.values, sub.child.values, np.median)
    s[f'{tag}_random_confirmed_median'] = cluster_bootstrap_ci(sub.random_improvement_confirmed.values, sub.child.values, np.median)
    diff = (sub.improvement_confirmed - sub.random_improvement_confirmed).values
    s[f'{tag}_ai_minus_random_median'] = cluster_bootstrap_ci(diff, sub.child.values, np.median)
    s[f'{tag}_pct_ai_better_than_random'] = float((diff > 0).mean() * 100)
    s[f'{tag}_pct_confirmed_ci_above_zero'] = float((sub.ci_lo > 0).mean() * 100)
    s[f'{tag}_screen_pct_positive_ai'] = float(sub.screen_pct_ai_positive.mean())
    s[f'{tag}_screen_pct_positive_random'] = float(sub.screen_pct_random_positive.mean())
    s[f'{tag}_child_median_ai_minus_random'] = pd.Series(diff).groupby(sub.child.values).median().round(2).to_dict()
    per_child = pd.Series(diff).groupby(sub.child.values).median()
    per_child_conf = pd.Series(sub.improvement_confirmed.values).groupby(sub.child.values).median()
    s[f'{tag}_n_children'] = int(len(per_child))
    s[f'{tag}_n_recordings'] = int(len(sub))
    s[f'{tag}_children_ai_better_pct'] = float((per_child > 0).mean() * 100)
    if len(per_child) >= 6:
        s[f'{tag}_child_level_signflip'] = sign_flip_test(per_child.values, stat=np.median)
        s[f'{tag}_child_level_wilcoxon_p'] = float(wilcoxon(per_child.values).pvalue)
        s[f'{tag}_child_level_confirmed_wilcoxon_p'] = float(wilcoxon(per_child_conf.values).pvalue)
        s[f'{tag}_children_confirmed_positive_pct'] = float((per_child_conf > 0).mean() * 100)
    for cond in sorted(set(sub.condition)):
        cs = sub[sub.condition == cond]
        dd = (cs.improvement_confirmed - cs.random_improvement_confirmed).values
        s[f'{tag}_by_condition'] = s.get(f'{tag}_by_condition', {})
        s[f'{tag}_by_condition'][cond] = {'n': int(len(cs)), 'confirmed_median': float(cs.improvement_confirmed.median()),
                                          'random_median': float(cs.random_improvement_confirmed.median()),
                                          'ai_minus_random_median': float(np.median(dd)),
                                          'pct_ai_better': float((dd > 0).mean() * 100),
                                          'wilcoxon_p': float(wilcoxon(dd).pvalue) if len(dd) >= 6 else None}
if 'ASD_n_children' in s and s['ASD_n_children'] >= 6:
    dif = (iv.improvement_confirmed - iv.random_improvement_confirmed).values
    s['ASD_vs_TD_guidance_advantage_child_perm'] = child_permutation_test(dif, iv.group.values, iv.child.values)[:2]
s['emulated_vs_confirmed_r'] = float(np.corrcoef(iv.improvement_emulated, iv.improvement_confirmed)[0, 1])
s['emulator_optimism_median'] = float(np.median(iv.improvement_emulated - iv.improvement_confirmed))
s['emulator_rank_vs_simulator_r_median'] = float(np.nanmedian(iv.emulator_vs_simulator_rank_r))
s['selected_emulator_rank_median'] = float(iv.emulator_rank_of_selected.median())
s['member_agreement_top1_mean'] = float(iv.member_agreement_top1.mean())
s['member_target_jaccard_mean'] = float(iv.member_target_jaccard.mean())
s['top_combo_frequency_ASD'] = asd.best_combo.value_counts().head(10).to_dict()
s['n_targets_ASD'] = asd.n_targets.value_counts().to_dict()
# recommendation consistency within child: cosine similarity of u* (within vs between children)
U = asd[[f'u_{c}' for c in CONTROLS]].values
Un = U / (np.linalg.norm(U, axis=1, keepdims=True) + 1e-12)
Cs = Un @ Un.T
cc = asd.child.to_numpy(dtype=str)
same = (cc[:, None] == cc[None]) & ~np.eye(len(cc), dtype=bool)
diff_ = cc[:, None] != cc[None]
obs = Cs[same].mean() - Cs[diff_].mean()
rng = np.random.default_rng(0)
null = []
for _ in range(2000):
    pc = rng.permutation(cc)
    sm = (pc[:, None] == pc[None]) & ~np.eye(len(pc), dtype=bool)
    null.append(Cs[sm].mean() - Cs[pc[:, None] != pc[None]].mean())
s['u_cosine_within_child'] = float(Cs[same].mean())
s['u_cosine_between_child'] = float(Cs[diff_].mean())
s['u_cosine_perm_p'] = float((1 + sum(n_ >= obs for n_ in null)) / 2001)
# mean control vector per child
s['mean_u_by_child'] = {c: asd[asd.child == c][[f'u_{k}' for k in CONTROLS]].mean().round(3).to_dict()
                        for c in np.unique(cc)}
s['modal_combo_by_child'] = {c: asd[asd.child == c].best_combo.value_counts().index[0] for c in np.unique(cc)}
s['modal_combo_share_by_child'] = {c: float(asd[asd.child == c].best_combo.value_counts(normalize=True).iloc[0])
                                   for c in np.unique(cc)}
s['robust_spectral_only_agree'] = float((asd.best_spectral_only == asd.emulator_top1_combo).mean())
s['robust_sync_only_agree'] = float((asd.best_sync_only == asd.emulator_top1_combo).mean())
summary['intervention'] = s

# ------------------------------------------------------------- 6. clinical association (ASRS) and attentional load
if os.path.exists(f'{R}/participants.csv'):
    pp = pd.read_csv(f'{R}/participants.csv').set_index('child')
    VARS = FIT_PARAMS + FEATURE_NAMES
    cm_ = pd.DataFrame({n: (tw[f'{n}_full'].values if n in FIT_PARAMS else df[n].values) for n in VARS})
    cm_['child'] = child; cm_['group'] = df.group.values
    cmean = cm_.groupby(['child', 'group']).mean().reset_index().set_index('child').join(pp.drop(columns='group'))
    rows = []
    for g in ['ASD', 'TD', 'all']:
        sub = cmean if g == 'all' else cmean[cmean.group == g]
        for n in VARS:
            for score in ['ASRS_Total_T', 'ASRS_SC_T', 'ASRS_UB_T', 'ASRS_SR_T', 'ASRS_DSM5_T']:
                if score not in sub:
                    continue
                ok = sub[[n, score]].dropna()
                rho, p = spearmanr(ok[n], ok[score])
                rows.append({'cohort': g, 'variable': n, 'kind': 'parameter' if n in FIT_PARAMS else 'feature',
                             'score': score, 'n_children': len(ok), 'spearman_rho': rho, 'p': p})
    asrs = pd.DataFrame(rows)
    for (g, sc), idx in asrs.groupby(['cohort', 'score']).groups.items():
        asrs.loc[idx, 'q_fdr'] = fdr_bh(asrs.loc[idx, 'p'].values)
    asrs.to_csv(f'{R}/asrs_association.csv', index=False)
    summary['asrs'] = {'n_children': int(cmean.ASRS_Total_T.notna().sum()),
                       'min_q_total_within_ASD': float(asrs[(asrs.cohort == 'ASD') & (asrs.score == 'ASRS_Total_T')].q_fdr.min()),
                       'min_q_total_within_TD': float(asrs[(asrs.cohort == 'TD') & (asrs.score == 'ASRS_Total_T')].q_fdr.min()),
                       'min_q_total_all': float(asrs[(asrs.cohort == 'all') & (asrs.score == 'ASRS_Total_T')].q_fdr.min())}
    print(asrs[asrs.score == 'ASRS_Total_T'].sort_values('p').head(12).round(3).to_string())

if set(df.condition) >= {'rest', 'low', 'intermediate', 'high'}:
    rows = []
    for n in FIT_PARAMS + FEATURE_NAMES:
        v = tw[f'{n}_full'].values if n in FIT_PARAMS else df[n].values
        t = pd.DataFrame({'v': v, 'child': child, 'cond': df.condition.values, 'group': df.group.values})
        piv = t.groupby(['child', 'cond']).v.mean().unstack()
        full = piv.dropna(subset=['low', 'intermediate', 'high'])
        task = full[['low', 'intermediate', 'high']].mean(1)
        rt = full.dropna(subset=['rest'])
        rec = {'variable': n, 'kind': 'parameter' if n in FIT_PARAMS else 'feature', 'n_children_load': len(full),
               'n_children_rest': len(rt)}
        rec['friedman_load_p'] = float(friedmanchisquare(full['low'], full['intermediate'], full['high']).pvalue)
        dhl = (full['high'] - full['low']).values
        rec['high_minus_low_median'] = float(np.median(dhl)); rec['high_minus_low_dz'] = float(dhl.mean() / dhl.std(ddof=1))
        dtr = (task.loc[rt.index] - rt['rest']).values
        rec['task_minus_rest_median'] = float(np.median(dtr)); rec['task_minus_rest_dz'] = float(dtr.mean() / dtr.std(ddof=1))
        rec['task_vs_rest_wilcoxon_p'] = float(wilcoxon(dtr).pvalue)
        # does the load effect differ between cohorts? (child-level permutation on high-minus-low)
        gch = t.groupby('child').group.first().loc[full.index].values
        rec['load_effect_group_diff_p'] = child_permutation_test(dhl, gch, full.index.values)[1]
        rows.append(rec)
    ld = pd.DataFrame(rows)
    for col in ['friedman_load_p', 'task_vs_rest_wilcoxon_p', 'load_effect_group_diff_p']:
        ld[col.replace('_p', '_q')] = fdr_bh(ld[col].values)
    ld.to_csv(f'{R}/load_effects.csv', index=False)
    print(ld.round(3).to_string())

# ------------------------------------------------------------- 5. dimensionality of the control space
fp = pd.read_csv(f'{R}/control_fingerprints.csv')
SDtd = df[df.group == 'TD'][FEATURE_NAMES].std()
ctrl = list(dict.fromkeys(fp.control))
Mfp = np.array([[fp[(fp.control == c) & (fp.feature == f)]['mean'].iloc[0] / SDtd[f] for f in FEATURE_NAMES] for c in ctrl])
U_, S_, Vt_ = np.linalg.svd(Mfp, full_matrices=False)
summary['control_space'] = {'variance_explained': (S_ ** 2 / (S_ ** 2).sum()).round(4).tolist(),
                            'loading_controls_pc1': dict(zip(ctrl, (U_[:, 0] * S_[0]).round(3).tolist())),
                            'loading_features_pc1': dict(zip(FEATURE_NAMES, Vt_[0].round(3).tolist()))}
json.dump(summary, open(f'{R}/validation_summary.json', 'w'), indent=1, default=float)
print(json.dumps(summary, indent=1, default=float)[:4000])
