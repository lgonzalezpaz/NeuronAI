"""Step 6 - personalised in silico pharmacological search for every recording.

Design ("emulator proposes, simulator disposes"):
 1. Emulator search over all 129 sparse supports (grid + L-BFGS-B refinement).
 2. Screening: the 12 best emulator candidates AND 12 random control vectors matched one-to-one in
    sparsity and norm are simulated with the full stochastic simulator (8 paired noise streams).
    The best candidate of each arm is selected on the screening streams.
 3. Confirmation: the two winners and the baseline are re-simulated with 12 FRESH paired streams,
    giving selection-unbiased improvements (no winner's curse) and bootstrap CIs.
 4. Robustness of the emulator ranking (ensemble members, descriptor subsets) and TD leave-one-child-out
    negative control.

Normative reference: TD recordings of the SAME condition (rest, or the same attentional load), excluding the
child under study (leave-one-child-out for TD recordings). When participant/condition labels are available
(complete cohort), the search is run on a pre-specified subset: for every child, the resting-state recording
and the first valid block of each attentional load (at most four recordings per child); use --all to run
every recording.
"""
import argparse, glob, json, os, pickle, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.model import CONTROLS, FIT_PARAMS
from neuronai.features import FEATURE_NAMES
from neuronai.intervention import (NormativeReference, search, grid_controls, grid_rank, member_deltas,
                                   random_like, simulate_candidates, verified_improvement)

ap = argparse.ArgumentParser()
ap.add_argument('--shard', type=int, default=0)
ap.add_argument('--nshards', type=int, default=1)
ap.add_argument('--all', action='store_true')
ARGS = ap.parse_args()
R = 'results'
N_CAND, N_SCREEN, N_CONFIRM = 12, 8, 12
MIN_REF = 10          # fewer condition-matched TD recordings than this: use all TD recordings of other children
models = pickle.load(open(f'{R}/models.pkl', 'rb'))
emu = models['emulator']
df = pd.read_csv(f'{R}/empirical_features.csv')
df = df[~df.excluded].reset_index(drop=True)
tw = pd.read_csv(f'{R}/twin_parameters.csv').set_index('id')
X = df[FEATURE_NAMES].values
is_td = (df.group == 'TD').values
COND = df['condition'].astype(str).values
MATCH = len(set(COND) - {'rest', 'task'}) > 0          # true load labels available (complete cohort)
if MATCH and not ARGS.all:
    first = (df.assign(_o=df.get('scenario', 0)).sort_values(['child', 'condition', '_o'])
             .groupby(['child', 'condition']).head(1).index)
    SELECT = np.zeros(len(df), bool); SELECT[first] = True
else:
    SELECT = np.ones(len(df), bool)
print('recordings selected for the intervention search:', SELECT.sum(), flush=True)
SPECTRAL = [FEATURE_NAMES.index(f) for f in ['rel_delta', 'rel_theta', 'rel_alpha', 'rel_beta', 'iaf', 'exponent']]
SYNC = [FEATURE_NAMES.index(f) for f in ['plv_alpha', 'wpli_alpha', 'kuramoto_alpha']]
GRID = grid_controls()
rng_boot = np.random.default_rng(2026)


def boot_ci(x_s, delta, ref, n=2000):
    d0 = ref.distance(x_s[None])[0]
    k = delta.shape[0]
    vals = [100 * (d0 - ref.distance((x_s + delta[rng_boot.integers(0, k, k)].mean(0))[None])[0]) / d0 for _ in range(n)]
    return np.percentile(vals, [2.5, 97.5])


rows, top = [], {}
for i, r in df.iterrows():
    if not SELECT[i] or int(np.flatnonzero(SELECT).tolist().index(i)) % ARGS.nshards != ARGS.shard:
        continue
    sid = r['id']
    ref_mask = is_td & (df['child'].values != r['child'])     # TD: leave-one-child-out reference
    if MATCH and (ref_mask & (COND == COND[i])).sum() >= MIN_REF:
        ref_mask &= COND == COND[i]                           # condition-matched normative reference
    ref = NormativeReference(X[ref_mask])
    theta = {n: tw.loc[sid, f'{n}_full'] for n in FIT_PARAMS}
    supports, U_all, own = GRID
    md = member_deltas(theta, emu, U_all)
    ens = md.mean(0)
    res = search(X[i], theta, emu, ref, n_refine=N_CAND, precomputed=(supports, U_all, own, ens))
    cands = res['results'][:N_CAND]
    U_ai = np.array([c['u'] for c in cands])
    U_rn = random_like(U_ai, seed=1000 + i)
    # ---- screening (paired streams) ----
    U_scr = np.vstack([np.zeros((1, len(CONTROLS))), U_ai, U_rn])
    F = simulate_candidates(theta, U_scr, N_SCREEN, seed=10_000 + i)
    _, m_ai, _ = verified_improvement(X[i], F[1:1 + N_CAND], F[0], ref)
    _, m_rn, _ = verified_improvement(X[i], F[1 + N_CAND:], F[0], ref)
    k_ai, k_rn = int(np.argmax(m_ai)), int(np.argmax(m_rn))
    # ---- confirmation (fresh paired streams) ----
    Fc = simulate_candidates(theta, np.vstack([np.zeros((1, len(CONTROLS))), U_ai[k_ai], U_rn[k_rn]]),
                             N_CONFIRM, seed=20_000 + i)
    per_ai, mean_ai, d_ai = verified_improvement(X[i], Fc[1:2], Fc[0], ref)
    per_rn, mean_rn, d_rn = verified_improvement(X[i], Fc[2:3], Fc[0], ref)
    lo_ai, hi_ai = boot_ci(X[i], d_ai[0], ref)
    lo_rn, hi_rn = boot_ci(X[i], d_rn[0], ref)
    win = cands[k_ai]
    # ---- robustness of the emulator ranking ----
    member_best = [grid_rank(X[i], md[m], U_all, own, supports, ref) for m in range(len(md))]
    top1 = res['results'][0]
    jacc = [len(set(mb['support']) & set(top1['support'])) / len(set(mb['support']) | set(top1['support']))
            for mb in member_best]
    sub = {tag: grid_rank(X[i], ens, U_all, own, supports, NormativeReference(X[ref_mask], idx))['name']
           for tag, idx in [('spectral', SPECTRAL), ('sync', SYNC)]}
    rank_corr = float(np.corrcoef(np.array([c['improvement'] for c in cands]), m_ai)[0, 1])
    rec = {'id': sid, 'group': r['group'], 'child': r['child'], 'condition': r['condition'], 'D0': res['d0'],
           'best_combo': win['name'], 'n_targets': len(win['support']), 'emulator_rank_of_selected': k_ai + 1,
           'improvement_emulated': win['improvement'],
           'improvement_screen': float(m_ai[k_ai]),
           'improvement_confirmed': float(mean_ai[0]), 'ci_lo': lo_ai, 'ci_hi': hi_ai,
           'pct_streams_improved': float((per_ai[0] > 0).mean() * 100),
           'random_best_combo': '+'.join(CONTROLS[j] for j in np.where(np.abs(U_rn[k_rn]) > 1e-9)[0]),
           'random_improvement_confirmed': float(mean_rn[0]), 'random_ci_lo': lo_rn, 'random_ci_hi': hi_rn,
           'screen_median_ai': float(np.median(m_ai)), 'screen_median_random': float(np.median(m_rn)),
           'screen_pct_ai_positive': float((m_ai > 0).mean() * 100),
           'screen_pct_random_positive': float((m_rn > 0).mean() * 100),
           'emulator_vs_simulator_rank_r': rank_corr,
           'emulator_top1_combo': top1['name'],
           'member_agreement_top1': float(np.mean([mb['name'] == top1['name'] for mb in member_best])),
           'member_target_jaccard': float(np.mean(jacc)),
           'best_spectral_only': sub['spectral'], 'best_sync_only': sub['sync']}
    rec.update({f'u_{c}': win['u'][j] for j, c in enumerate(CONTROLS)})
    rec.update({f'delta_{f}': d_ai[0].mean(0)[j] for j, f in enumerate(FEATURE_NAMES)})
    rows.append(rec)
    top[sid] = {'emulator_candidates': [{'combo': c['name'], 'u': c['u'].tolist(), 'emulated': c['improvement'],
                                         'screen': float(s)} for c, s in zip(cands, m_ai)],
                'random_screen': m_rn.tolist()}
    print(time.strftime("%H:%M:%S"), f"{sid:10s} {r['group']} D0={res['d0']:.2f} sel={win['name']:26s} emu={win['improvement']:5.1f}% "
          f"confirmed={mean_ai[0]:6.1f}% [{lo_ai:6.1f},{hi_ai:6.1f}]  random={mean_rn[0]:6.1f}%", flush=True)

out = pd.DataFrame(rows)
tag = '' if ARGS.nshards == 1 else f'_shard{ARGS.shard}of{ARGS.nshards}'
out.to_csv(f'{R}/intervention_results{tag}.csv', index=False)
json.dump(top, open(f'{R}/intervention_candidates{tag}.json', 'w'))
if ARGS.nshards > 1:
    parts = sorted(glob.glob(f'{R}/intervention_results_shard*of{ARGS.nshards}.csv'))
    if len(parts) == ARGS.nshards:
        allr = pd.concat([pd.read_csv(p) for p in parts])
        allr = allr.set_index('id').loc[[s for s in df.id if s in set(allr.id)]].reset_index()
        allr.to_csv(f'{R}/intervention_results.csv', index=False)
        cand = {}
        for p in sorted(glob.glob(f'{R}/intervention_candidates_shard*of{ARGS.nshards}.json')):
            cand.update(json.load(open(p)))
        json.dump(cand, open(f'{R}/intervention_candidates.json', 'w'))
        print('merged', len(allr), 'recordings')
        out = allr
print(out.groupby('group')[['D0', 'improvement_emulated', 'improvement_confirmed', 'random_improvement_confirmed']].median())
