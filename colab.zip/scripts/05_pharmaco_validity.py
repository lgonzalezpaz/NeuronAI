"""Step 5 - pharmacological face validity: simulate canonical drug classes on every
fitted twin and compare the predicted direction of EEG change with the direction
reported in the human pharmaco-EEG literature (benchmarks fixed a priori)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from neuronai.model import CONTROLS, FIT_PARAMS, simulate
from neuronai.features import FEATURE_NAMES, extract_features, feature_matrix
from neuronai.stats import cluster_bootstrap_ci, sign_flip_test

R = 'results'
N_SEEDS = 4
tw = pd.read_csv(f'{R}/twin_parameters.csv')
theta = {n: tw[f'{n}_full'].values for n in FIT_PARAMS}
n = len(tw)


def u_of(**kw):
    u = np.zeros(len(CONTROLS))
    for k, v in kw.items():
        u[CONTROLS.index(k)] = v
    return u


DRUGS = [
    # name, control vector, feature, expected sign, literature
    ('GABA_A positive modulator (benzodiazepine class)', u_of(GABA_A=1.0), 'rel_beta', +1,
     'Feshchenko et al., 1997; Mandema & Danhof, 1992'),
    ('NMDA receptor antagonist (ketamine class)', u_of(NMDA_2A=-1.0, NMDA_2B=-1.0), 'rel_alpha', -1,
     'Muthukumaraswamy et al., 2015; de la Salle et al., 2016'),
    ('5-HT2A agonist (psilocybin class)', u_of(**{'5HT': 1.0}), 'rel_alpha', -1,
     'Muthukumaraswamy et al., 2013; Kometer et al., 2015'),
    ('DA/NE enhancer (stimulant class)', u_of(DA=1.0, NE=1.0), 'theta_beta', -1,
     'Clarke et al., 2017; Loo et al., 2004'),
    ('Slow-inhibition agonist (baclofen class)', u_of(GABA_slow=1.0), 'rel_delta', +1,
     'exploratory (no firm human benchmark)'),
]


def run(u_vec, seed):
    rows = np.repeat(np.arange(n), N_SEEDS)
    th = {k: v[rows] for k, v in theta.items()}
    U = np.repeat(u_vec[None, :], len(rows), axis=0)
    feats = []
    for s in range(0, len(rows), 128):
        sl = slice(s, s + 128)
        res = simulate({k: v[sl] for k, v in th.items()}, u=U[sl], duration=20.0, seed=seed + s)
        feats.append(feature_matrix(extract_features(res.eeg, res.fs)))
    return np.concatenate(feats).reshape(n, N_SEEDS, -1)


base = run(np.zeros(len(CONTROLS)), 777)    # common random numbers across conditions
records, effects = [], {}
for name, u, feat, sign, ref in DRUGS:
    drug = run(u, 777)
    d = (drug - base).mean(1)                   # paired, per twin
    eff = pd.DataFrame(d, columns=FEATURE_NAMES)
    eff['theta_beta'] = (drug[..., FEATURE_NAMES.index('rel_theta')] - drug[..., FEATURE_NAMES.index('rel_beta')]).mean(1) - \
        (base[..., FEATURE_NAMES.index('rel_theta')] - base[..., FEATURE_NAMES.index('rel_beta')]).mean(1)
    eff['id'] = tw['id'].values; eff['group'] = tw['group'].values; eff['child'] = tw['child'].values; eff['drug'] = name
    effects[name] = eff
    v = eff[feat].values
    m, lo, hi = cluster_bootstrap_ci(v, tw['child'].values)
    p = wilcoxon(v).pvalue
    child_means = pd.Series(v).groupby(tw['child'].values).mean()
    child_agree = float((np.sign(child_means) == sign).mean())
    p_child = sign_flip_test(child_means.values)[1] if len(child_means) >= 6 else np.nan
    agree = float((np.sign(v) == sign).mean())
    records.append({'drug': name, 'feature': feat, 'expected_sign': '+' if sign > 0 else '-',
                    'mean_change': m, 'ci_lo': lo, 'ci_hi': hi, 'wilcoxon_p_records': p,
                    'pct_twins_expected_direction': 100 * agree, 'pct_children_expected_direction': 100 * child_agree,
                    'p_child_signflip': p_child, 'n_children': int(len(child_means)),
                    'concordant': bool(np.sign(m) == sign and (lo > 0 if sign > 0 else hi < 0)), 'reference': ref})
    print(records[-1], flush=True)
pd.DataFrame(records).to_csv(f'{R}/pharmaco_validity.csv', index=False)
pd.concat(effects.values()).to_csv(f'{R}/pharmaco_effects_all.csv', index=False)
