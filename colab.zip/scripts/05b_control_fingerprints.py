"""Step 5b - mechanistic fingerprints of the pharmacological controls.

For every fitted twin, each control is set to +1 (maximal agonism/potentiation)
in isolation and the change of every descriptor is measured with common random
numbers. In addition, post hoc mechanistically refined drug models (clearly
separated from the pre-specified benchmarks of step 5) are evaluated."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.model import CONTROLS, FIT_PARAMS, simulate
from neuronai.features import FEATURE_NAMES, extract_features, feature_matrix
from neuronai.stats import cluster_bootstrap_ci

R = 'results'
N_SEEDS = 2
tw = pd.read_csv(f'{R}/twin_parameters.csv')
n = len(tw)
rows = np.repeat(np.arange(n), N_SEEDS)
theta = {k: tw[f'{k}_full'].values[rows] for k in FIT_PARAMS}


def run(u=None, extra=None, seed=31):
    th = {k: v.copy() for k, v in theta.items()}
    if extra:
        for k, f in extra.items():
            th[k] = th.get(k, np.ones(len(rows))) * f
    F = []
    for s in range(0, len(rows), 103):
        sl = slice(s, s + 103)
        nb = min(103, len(rows) - s)
        uu = None if u is None else np.repeat(np.asarray(u, float)[None], nb, 0)
        r = simulate({k: v[sl] for k, v in th.items()}, u=uu, duration=20.0, seed=seed + s)
        F.append(feature_matrix(extract_features(r.eeg, r.fs)))
    F = np.concatenate(F).reshape(n, N_SEEDS, -1)
    tb = F[..., FEATURE_NAMES.index('rel_theta')] - F[..., FEATURE_NAMES.index('rel_beta')]
    return np.concatenate([F, tb[..., None]], -1).mean(1)


names = FEATURE_NAMES + ['theta_beta']
base = run()
out = []
for m, c in enumerate(CONTROLS):
    u = np.zeros(len(CONTROLS)); u[m] = 1.0
    d = run(u) - base
    for j, f in enumerate(names):
        mu, lo, hi = cluster_bootstrap_ci(d[:, j], tw.child.values, n_boot=2000)
        out.append({'control': c, 'feature': f, 'mean': mu, 'ci_lo': lo, 'ci_hi': hi,
                    'sd': d[:, j].std(ddof=1), 'pct_positive': 100 * (d[:, j] > 0).mean()})
    print('control', c, 'done', flush=True)
pd.DataFrame(out).to_csv(f'{R}/control_fingerprints.csv', index=False)

POSTHOC = [
    ('GABA_A modulator at both inhibitory synapses + prolonged IPSC decay (post hoc)', dict(G=1.3, B=1.3, g_tau=1.3), 'exponent', +1,
     'steeper aperiodic exponent with GABAergic potentiation (Gao et al., 2017)'),
    ('GABA_A modulator at both inhibitory synapses + prolonged IPSC decay (post hoc)', dict(G=1.3, B=1.3, g_tau=1.3), 'rel_beta', +1,
     'beta increase with benzodiazepines (Feshchenko et al., 1997)'),
    ('NMDA antagonist, interneuron-preferential + AMPA increase (post hoc)', dict(NI_scale=0.3, N=0.7, A=1.15), 'rel_alpha', -1,
     'alpha decrease with ketamine (Muthukumaraswamy et al., 2015)'),
]
ph = []
for name, extra, feat, sign, ref in POSTHOC:
    d = run(extra=extra) - base
    j = names.index(feat)
    mu, lo, hi = cluster_bootstrap_ci(d[:, j], tw.child.values, n_boot=2000)
    ph.append({'model': name, 'feature': feat, 'expected_sign': '+' if sign > 0 else '-', 'mean_change': mu,
               'ci_lo': lo, 'ci_hi': hi, 'pct_expected': 100 * (np.sign(d[:, j]) == sign).mean(),
               'concordant': bool(np.sign(mu) == sign and (lo > 0 if sign > 0 else hi < 0)), 'benchmark': ref})
    print(ph[-1], flush=True)
pd.DataFrame(ph).to_csv(f'{R}/pharmaco_posthoc.csv', index=False)
