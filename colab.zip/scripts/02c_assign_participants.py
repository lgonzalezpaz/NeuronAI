"""Step 2c - assign every recording to its participant and condition, and collect participant metadata.

The complete Duville et al. datasets are organised as EEG/PartNN/<file>.gdf with file names that encode
the condition (restEO = 2-min eyes-open rest; scenarioK_IAPS / _4discs / _8discs = task blocks under low,
intermediate and high attentional load). This script replaces the provisional child labels written by
step 2 with the true participant identifiers and adds age, sex, ASRS and tracking-capacity data.

Inputs : results/empirical_features.csv, results/empirical_features_windows.csv,
         results/recording_id_map.csv (written by the Colab download cell), --meta folder with the
         dataset spreadsheets (Age_Gender, PartNN_ASRS, Tracking_Capacity) in ASD/ and TD/ sub-folders.
Outputs: updated empirical_features*.csv and results/participants.csv
"""
import argparse, glob, os, re, sys
import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument('--results', default='results')
ap.add_argument('--meta', default='data_meta')
a = ap.parse_args()
R = a.results

# 'Idiscs' (one participant) is the image-viewing (IAPS) block and 'bolas' is Spanish for discs; both are
# naming variants in the original files (verified: each participant has 1 rest + 6 blocks of each load).
LOAD = {'restEO': 'rest', 'IAPS': 'low', 'Idiscs': 'low', '4discs': 'intermediate', '4bolas': 'intermediate',
        '8discs': 'high', '8bolas': 'high'}

m = pd.read_csv(f'{R}/recording_id_map.csv')
m['part'] = m.original_path.str.extract(r'Part(\d+)', expand=False).astype(int)
m['cond_raw'] = m.recording_id.str.extract(r'(restEO|IAPS|Idiscs|4discs|4bolas|8discs|8bolas)$', expand=False)
m['scenario'] = m.recording_id.str.extract(r'scenario(\d)', expand=False).fillna(0).astype(int)
chk = m.assign(c=m.cond_raw.map(LOAD)).groupby(['group', 'part']).c.value_counts().unstack(fill_value=0)
assert (chk[['rest', 'low', 'intermediate', 'high']].values == [1, 6, 6, 6]).all(), chk
if m.part.isna().any() or m.cond_raw.isna().any():
    sys.exit('Some recordings could not be mapped to a participant/condition')
m['child'] = m.group + '-P' + m.part.map('{:02d}'.format)
m['condition'] = m.cond_raw.map(LOAD)
lab = m.set_index('recording_id')[['child', 'condition', 'scenario', 'part']]

for fn in ['empirical_features.csv', 'empirical_features_windows.csv']:
    df = pd.read_csv(f'{R}/{fn}')
    df['child'] = lab.loc[df.id, 'child'].values
    if 'condition' in df:
        df['condition'] = lab.loc[df.id, 'condition'].values
        df['scenario'] = lab.loc[df.id, 'scenario'].values
    df.to_csv(f'{R}/{fn}', index=False)

# ------------------------------------------------------------------ participant metadata
def first(pattern):
    fs = sorted(glob.glob(pattern), key=len)
    return fs[0] if fs else None


rows = []
for grp in ['ASD', 'TD']:
    ag = first(os.path.join(a.meta, grp, '*Age_Gender*.xlsx'))
    tc = first(os.path.join(a.meta, grp, '*Tracking_Capacity*.xlsx'))
    age = pd.read_excel(ag) if ag else None
    trk = pd.read_excel(tc) if tc else None
    for p in range(1, 32):
        rec = {'group': grp, 'child': f'{grp}-P{p:02d}', 'participant': p}
        if age is not None:
            r = age[age.iloc[:, 0] == p]
            if len(r):
                rec['age'] = float(r.iloc[0, 1]); rec['sex'] = str(r.iloc[0, 2]).strip()
        if trk is not None:
            r = trk[trk.iloc[:, 0] == p]
            if len(r):
                rec['tracking_capacity'] = float(r.iloc[0, 1])
        f = first(os.path.join(a.meta, grp, f'*Part{p:02d}_ASRS*.xlsx'))
        if f:
            s = pd.read_excel(f)
            for _, row in s.iterrows():
                name = str(row.iloc[0])
                code = re.search(r'\(([A-Z]+)\s*-', name)
                key = 'Total' if name.startswith('Total') else ('DSM5' if name.startswith('DSM') else (code.group(1) if code else None))
                if key:
                    rec[f'ASRS_{key}_T'] = float(row.iloc[2])
                    rec[f'ASRS_{key}_raw'] = float(row.iloc[1])
        rows.append(rec)
pp = pd.DataFrame(rows)
pp.to_csv(f'{R}/participants.csv', index=False)
q = pd.read_csv(f'{R}/empirical_features.csv')
print(q.groupby(['group', 'condition', 'excluded']).size().unstack(fill_value=0))
print(pp.groupby('group')[['age', 'ASRS_Total_T']].describe().round(1).T)
print(pp.groupby(['group', 'sex']).size())
