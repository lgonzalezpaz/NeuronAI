"""Step 4 - fit a digital twin to every recording (full data and split halves) and run
posterior-predictive and out-of-sample validation against the real EEG.

Recordings are processed in fixed blocks of 21 (21 x 6 seeds = 126 simulations per batch), and every block
is simulated with a seed derived from its position, so results are identical whether the step is run in one
process or split into shards (--shard k --nshards n; the last shard to finish merges the outputs)."""
import argparse, glob, os, pickle, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.model import FIT_PARAMS, params_from_unit, params_to_unit, simulate
from neuronai.inference import refine_twin
from neuronai.bank import load_bank
from neuronai.features import FEATURE_NAMES, extract_features, feature_matrix, psd, normalised_log_psd

ap = argparse.ArgumentParser()
ap.add_argument('--shard', type=int, default=0)
ap.add_argument('--nshards', type=int, default=1)
ARGS = ap.parse_args()
R = 'results'
N_SEEDS = 6
BLOCK = 21
models = pickle.load(open(f'{R}/models.pkl', 'rb'))
inv, emu, semu = models['inverse'], models['emulator'], models['spec_emulator']
df = pd.read_csv(f'{R}/empirical_features.csv')
df = df[~df.excluded].reset_index(drop=True)
df_all = df
blocks = np.arange(len(df)) // BLOCK
mine = (blocks % ARGS.nshards) == ARGS.shard
TAG = '' if ARGS.nshards == 1 else f'_shard{ARGS.shard}of{ARGS.nshards}'
# scale of meaningful variation: between-recording SD of each descriptor in the TD cohort (all recordings)
SCALE = df_all[df_all.group == 'TD'][FEATURE_NAMES].std().values
bank = load_bank(f'{R}/bank_I.npz')
BX = bank['X'][bank['ok']]
BZ = params_to_unit({n: bank['theta'][:, i] for i, n in enumerate(bank['theta_names'])})[bank['ok']]
emp = np.load(f'{R}/empirical_psd.npz')
eid = list(emp['ids'])
SPEC = {t: np.stack([emp[k][eid.index(s_)] for s_ in df_all.id]) for t, k in
        [('full', 'logpsd'), ('h1', 'logpsd_h1'), ('h2', 'logpsd_h2')]}
SPEC_SCALE = SPEC['full'][(df_all.group == 'TD').values].std(0)
SPEC = {t: v[mine] for t, v in SPEC.items()}
BLK = blocks[mine]
df = df_all[mine].reset_index(drop=True)
out = df[['id', 'group', 'child', 'condition']].copy()
units = {}
for tag, cols in [('full', FEATURE_NAMES), ('h1', [f + '_h1' for f in FEATURE_NAMES]),
                  ('h2', [f + '_h2' for f in FEATURE_NAMES])]:
    Xs = df[cols].values
    mu = inv.predict(Xs)                      # amortised posterior mean (deep ensemble)
    lo, hi = inv.interval(Xs)                 # 90 % split-conformal intervals
    Z, L = [], []
    for k in range(len(Xs)):
        nn = np.argsort((((Xs[k] - BX) / SCALE) ** 2).sum(1))[:5]   # nearest simulations as extra starts
        z, loss = refine_twin(Xs[k], emu, np.vstack([mu[k], BZ[nn]]), SCALE, lo[k], hi[k],
                              spectrum=SPEC[tag][k], spec_emulator=semu, spec_scale=SPEC_SCALE)
        Z.append(z); L.append(loss)
    Z = np.array(Z)
    th, tlo, thi, tnn = params_from_unit(Z), params_from_unit(lo), params_from_unit(hi), params_from_unit(mu)
    for n in FIT_PARAMS:
        out[f'{n}_{tag}'] = th[n]
        if tag == 'full':
            out[f'{n}_lo'], out[f'{n}_hi'], out[f'{n}_amortised'] = tlo[n], thi[n], tnn[n]
    out[f'refine_loss_{tag}'] = L
    units[tag] = Z
    print(f'twins ({tag}) refined; median standardised loss {np.median(L):.2f}', flush=True)
out.to_csv(f'{R}/twin_parameters{TAG}.csv', index=False)


def ppc(unit, seed0):
    """Simulate each twin with N_SEEDS independent noise realisations (20 s each), block by block."""
    th_all = params_from_unit(np.repeat(unit, N_SEEDS, axis=0))
    feats, lps = [], []
    for b in np.unique(BLK):
        rows = np.flatnonzero(np.repeat(BLK == b, N_SEEDS))
        res = simulate({k: v[rows] for k, v in th_all.items()}, duration=20.0, seed=seed0 + int(b))
        feats.append(feature_matrix(extract_features(res.eeg, res.fs)))
        f, P = psd(res.eeg, res.fs)
        fsel, lp = normalised_log_psd(f, P)
        lps.append(lp)
    n = len(unit)
    F = np.concatenate(feats).reshape(n, N_SEEDS, -1)
    LP = np.concatenate(lps).reshape(n, N_SEEDS, -1)
    return F, LP, fsel


F_full, LP_full, fsel = ppc(units['full'], 50000)
F_h1, _, _ = ppc(units['h1'], 60000)
F_amort, LP_amort, _ = ppc(inv.predict(df[FEATURE_NAMES].values), 70000)   # ablation: no refinement
np.savez_compressed(f'{R}/ppc{TAG}.npz', F_full=F_full, LP_full=LP_full, F_h1=F_h1, F_amort=F_amort, LP_amort=LP_amort, freqs=fsel,
                    ids=df['id'].values)
print('PPC simulations done:', F_full.shape, flush=True)

# ---------------------------------------------------------------- merge shards
if ARGS.nshards > 1:
    parts = [f'{R}/twin_parameters_shard{k}of{ARGS.nshards}.csv' for k in range(ARGS.nshards)]
    pz = [f'{R}/ppc_shard{k}of{ARGS.nshards}.npz' for k in range(ARGS.nshards)]
    if all(os.path.exists(p) for p in parts + pz):
        order = list(df_all.id)
        tw = pd.concat([pd.read_csv(p) for p in parts]).set_index('id').loc[order].reset_index()
        tw.to_csv(f'{R}/twin_parameters.csv', index=False)
        Z = [np.load(p, allow_pickle=True) for p in pz]
        ids = list(np.concatenate([z['ids'] for z in Z])); pos = [ids.index(i) for i in order]
        merged = {k: np.concatenate([z[k] for z in Z])[pos] for k in ['F_full', 'LP_full', 'F_h1', 'F_amort', 'LP_amort']}
        np.savez_compressed(f'{R}/ppc.npz', **merged, freqs=Z[0]['freqs'], ids=np.array(order))
        print('merged', len(tw), 'twins', flush=True)
