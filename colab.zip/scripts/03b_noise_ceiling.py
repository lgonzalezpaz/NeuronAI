"""Step 3b - intrinsic stochasticity of 20-s simulations: fraction of descriptor variance
explained by parameters (noise ceiling for any emulator / inverse model)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import pandas as pd
from neuronai.bank import sample_unit
from neuronai.model import params_from_unit, simulate, FIT_PARAMS
from neuronai.features import extract_features, feature_matrix, FEATURE_NAMES

N_P, N_S = 128, 4
U = sample_unit(N_P, len(FIT_PARAMS), seed=99)
th = params_from_unit(np.repeat(U, N_S, axis=0))
F = []
for s in range(0, N_P * N_S, 128):
    r = simulate({k: v[s:s + 128] for k, v in th.items()}, duration=20.0, seed=123 + s)
    F.append(feature_matrix(extract_features(r.eeg, r.fs)))
F = np.concatenate(F).reshape(N_P, N_S, -1)
within = F.var(axis=1, ddof=1).mean(0)
total = F.reshape(-1, F.shape[-1]).var(0, ddof=1)
ceil = 1 - within / total
pd.DataFrame({'feature': FEATURE_NAMES, 'noise_ceiling_R2': ceil,
              'within_param_sd': np.sqrt(within)}).to_csv('results/noise_ceiling.csv', index=False)
print(dict(zip(FEATURE_NAMES, np.round(ceil, 3))))
