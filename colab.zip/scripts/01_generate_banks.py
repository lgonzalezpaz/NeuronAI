"""Step 1 - generate the simulation banks (inverse bank I and emulator bank E)."""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from neuronai.bank import generate_bank

ap = argparse.ArgumentParser()
ap.add_argument('--kind', default='I', choices=['I', 'E'])
ap.add_argument('--n', type=int, default=8192)
ap.add_argument('--seed', type=int, default=None)
ap.add_argument('--out', default='results')
a = ap.parse_args()
seed = a.seed if a.seed is not None else (2026 if a.kind == 'I' else 3031)
os.makedirs(a.out, exist_ok=True)
generate_bank(a.n, a.kind, seed=seed, out_path=os.path.join(a.out, f'bank_{a.kind}.npz'))
