"""Shared figure style for NeuronAI publication figures."""
import matplotlib as mpl
import matplotlib.pyplot as plt

C_TD = '#2a78d6'      # blue
C_ASD = '#eb6834'     # orange
C_SIM = '#1baf7a'     # aqua (model / simulation)
C_NULL = '#8a8984'    # neutral gray
C_TXT = '#0b0b0b'
C_TXT2 = '#52514e'
GRID = '#e6e5e1'
DIV_NEG, DIV_MID, DIV_POS = '#2a78d6', '#f0efec', '#e34948'
CHILD_ASD = ['#eb6834', '#c2491b', '#f39a6f', '#8f3410']
CHILD_TD = ['#2a78d6', '#184f95', '#6da7ec', '#0d366b']


def setup():
    mpl.rcParams.update({
        'font.family': 'DejaVu Sans', 'font.size': 8, 'axes.titlesize': 9, 'axes.labelsize': 8,
        'xtick.labelsize': 7, 'ytick.labelsize': 7, 'legend.fontsize': 7,
        'axes.edgecolor': '#9a9994', 'axes.linewidth': 0.6, 'axes.labelcolor': C_TXT,
        'xtick.color': C_TXT2, 'ytick.color': C_TXT2, 'xtick.major.width': 0.6, 'ytick.major.width': 0.6,
        'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True,
        'grid.color': GRID, 'grid.linewidth': 0.5, 'axes.axisbelow': True,
        'legend.frameon': False, 'savefig.dpi': 600, 'figure.dpi': 150,
        'savefig.bbox': 'tight', 'savefig.pad_inches': 0.04, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
        'lines.linewidth': 1.4, 'axes.titleweight': 'bold', 'axes.titlelocation': 'left'})


def panel(ax, letter, x=-0.16, y=1.06):
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=11, fontweight='bold', va='bottom', ha='left', color=C_TXT)


def save(fig, name, outdir='figures'):
    import os
    os.makedirs(outdir, exist_ok=True)
    fig.savefig(f'{outdir}/{name}.png')
    fig.savefig(f'{outdir}/{name}.pdf')
    fig.savefig(f'{outdir}/{name}.tiff', dpi=600, pil_kwargs={'compression': 'tiff_lzw'})
    plt.close(fig)
