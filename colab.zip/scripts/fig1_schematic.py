"""Figure 1 - model and NeuronAI framework schematic."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, FancyArrowPatch, Ellipse
from fig_style import setup, save, panel, C_TXT, C_TXT2, C_SIM, C_TD, C_ASD
from neuronai.model import electrode_positions, EEG_CHANNELS, connectivity_matrices

setup()
C_AMPA, C_N2A, C_N2B = '#1c5cab', '#6250d6', '#9085e9'
C_GA, C_GS = '#e34948', '#eda100'
C_MOD = '#008300'

fig = plt.figure(figsize=(7.2, 7.4))
gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 0.95], width_ratios=[1.15, 0.85], hspace=0.12, wspace=0.05)

# ---------------------------------------------------------------- (a) column
ax = fig.add_subplot(gs[0, 0]); ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis('off'); ax.set_aspect('equal')
panel(ax, 'a', x=0.0, y=0.97)
ax.text(0.9, 9.62, 'Extended Wendling column', fontsize=9, fontweight='bold', color=C_TXT)
pops = {'P': (5.0, 5.3, 'Pyramidal\ncells'), 'E': (1.8, 7.6, 'Excitatory\ninterneurons'),
        'S': (1.8, 3.0, 'Slow dendritic\ninterneurons'), 'F': (8.2, 3.0, 'Fast somatic\n(PV-like) int.')}
for k, (x, y, lab) in pops.items():
    col = '#dbe9fa' if k in 'PE' else '#fbe0de'
    ax.add_patch(Circle((x, y), 1.12, fc=col, ec='#52514e', lw=0.8, zorder=3))
    ax.text(x, y, lab, ha='center', va='center', fontsize=5.3, zorder=4, color=C_TXT)


def arrow(p, q, color, lw=1.6, rad=0.0, style='-|>', ls='-'):
    a = FancyArrowPatch(p, q, arrowstyle=style, mutation_scale=9, color=color, lw=lw,
                        connectionstyle=f'arc3,rad={rad}', zorder=2, shrinkA=10, shrinkB=10, ls=ls)
    ax.add_patch(a)


P, E, S, F = [pops[k][:2] for k in 'PESF']
arrow(P, E, C_AMPA, rad=0.15)                         # P -> E
arrow(E, P, C_AMPA, rad=0.15)                         # E -> P (AMPA)
arrow((E[0] + 0.3, E[1] - 0.2), (P[0] - 0.2, P[1] + 0.3), C_N2A, rad=-0.05)
arrow((E[0] + 0.5, E[1] - 0.45), (P[0] - 0.45, P[1] + 0.15), C_N2B, rad=-0.15)
arrow(P, S, C_AMPA, rad=-0.15)
arrow(S, P, C_GS, rad=-0.15, style='-[')
arrow(P, F, C_AMPA, rad=0.15)
arrow((P[0] + 0.4, P[1] - 0.6), (F[0] - 0.6, F[1] + 0.6), C_N2A, rad=0.3)
arrow(F, P, C_GA, rad=0.15, style='-[')
arrow(S, F, C_GS, rad=0.0, style='-[')
# drive
ax.annotate('', xy=(P[0] + 0.7, P[1] + 0.75), xytext=(7.4, 7.7),
            arrowprops=dict(arrowstyle='-|>', color=C_AMPA, lw=1.4))
ax.text(6.9, 7.8, 'Drive $p(t)$: tonic $\\bar p$ +\nwhite + slow (OU) noise\n+ long-range input $K$',
        fontsize=5.6, color=C_TXT2, va='bottom')
ax.text(5.0, 0.35, 'EEG source: $v_P = y_1+n_{2A}+n_{2B}-y_2-y_3$', fontsize=5.6, ha='center', color=C_TXT2)
# neuromodulators
mods = [('DA (D1)', 4.0, 9.0, [(P[0] - 0.3, P[1] + 1.0), (F[0] - 0.4, F[1] + 1.0)]),
        ('5-HT$_{2A}$', 5.6, 9.0, [(P[0] + 0.2, P[1] + 1.0)]),
        ('NE', 9.3, 6.0, [(P[0] + 1.0, P[1] + 0.2), (F[0] + 0.2, F[1] + 1.0)])]
for lab, x, y, tg in mods:
    ax.text(x, y, lab, fontsize=6.5, color=C_MOD, ha='center', va='center', fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.25', fc='#e7f5e7', ec=C_MOD, lw=0.6))
    for t in tg:
        ax.annotate('', xy=t, xytext=(x, y - 0.25 if y > 8 else y), arrowprops=dict(arrowstyle='->', color=C_MOD, lw=0.8, ls=(0, (2, 1.5))))
# legend (lines with arrow = excitatory, bar end = inhibitory)
leg = [('AMPA', C_AMPA, 'e'), ('NMDA-GluN2A', C_N2A, 'e'), ('NMDA-GluN2B', C_N2B, 'e'),
       ('GABA$_A$ (fast)', C_GA, 'i'), ('Slow dendritic GABA', C_GS, 'i'), ('Neuromodulation', C_MOD, 'm')]
for i, (lab, c, kind) in enumerate(leg):
    xx = [0.0, 3.1, 7.0][i % 3]; yy = 1.45 - (i // 3) * 0.5
    if kind == 'i':
        ax.plot([xx, xx + 0.7], [yy, yy], color=c, lw=1.6); ax.plot([xx + 0.7] * 2, [yy - 0.15, yy + 0.15], color=c, lw=1.6)
    else:
        ax.annotate('', xy=(xx + 0.75, yy), xytext=(xx, yy), arrowprops=dict(arrowstyle='->' if kind == 'm' else '-|>', color=c, lw=1.4,
                    ls=(0, (2, 1.5)) if kind == 'm' else '-'))
    ax.text(xx + 0.9, yy, lab, fontsize=5.6, va='center', color=C_TXT)
ax.set_ylim(-0.4, 10)
# ---------------------------------------------------------------- (b) network on scalp
ax = fig.add_subplot(gs[0, 1]); ax.set_aspect('equal'); ax.axis('off')
panel(ax, 'b', x=0.0, y=0.97)
ax.text(-1.05, 1.36, '17-column network', fontsize=9, fontweight='bold', color=C_TXT)
pos = electrode_positions()
r = np.sqrt(pos[:, 0] ** 2 + pos[:, 1] ** 2)
th = np.arctan2(pos[:, 1], pos[:, 0])
rad = np.arccos(np.clip(pos[:, 2], -1, 1)) / (np.pi / 2)
xy = np.c_[rad * np.cos(th), rad * np.sin(th)]
ax.add_patch(Circle((0, 0), 1.08, fc='#f7f6f3', ec='#9a9994', lw=0.8))
ax.plot([-0.12, 0, 0.12], [1.07, 1.2, 1.07], color='#9a9994', lw=0.8)
W, M = connectivity_matrices(mixing_width=0.5)
for i in range(17):
    for j in range(i + 1, 17):
        w = W[i, j] + W[j, i]
        if w > 0.13:
            ax.plot(*xy[[i, j]].T, color=C_AMPA, lw=2.2 * w, alpha=0.55, zorder=1)
ax.scatter(xy[:, 0], xy[:, 1], s=95, c='#dbe9fa', edgecolors='#1c5cab', linewidths=0.8, zorder=3)
for (x, y), lab in zip(xy, EEG_CHANNELS):
    ax.text(x, y, lab, fontsize=4.6, ha='center', va='center', zorder=4)
ax.text(0, -1.32, 'Coupling $W_{ij}\\propto e^{-d_{ij}/\\ell}$ (long-range, glutamatergic)\n'
        'Sensors $= \\mathbf{M}\\,v_P$ (volume conduction) + average reference',
        fontsize=5.6, ha='center', va='top', color=C_TXT2)
ax.set_xlim(-1.3, 1.3); ax.set_ylim(-1.75, 1.45)

# ---------------------------------------------------------------- (c) pipeline
ax = fig.add_subplot(gs[1, :]); ax.set_xlim(0, 20); ax.set_ylim(0, 8.2); ax.axis('off')
panel(ax, 'c', x=0.0, y=0.98)
ax.text(0.9, 7.95, 'NeuronAI v2: simulation-based inference and in silico pharmacology', fontsize=9, fontweight='bold')


def box(x, y, w, h, title, body, fc, ec):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.05,rounding_size=0.25', fc=fc, ec=ec, lw=0.9))
    ax.text(x + w / 2, y + h - 0.3, title, ha='center', va='top', fontsize=6.0, fontweight='bold', color=C_TXT)
    ax.text(x + w / 2, y + h - 0.9, body, ha='center', va='top', fontsize=4.9, color=C_TXT2, linespacing=1.3)


def arr(p, q):
    ax.annotate('', xy=q, xytext=p, arrowprops=dict(arrowstyle='-|>', color='#52514e', lw=1.1))


B = '#eef4fc'; Be = '#6da7ec'; G = '#e8f6f0'; Ge = C_SIM; O = '#fdf0ea'; Oe = C_ASD
w, gap, y0, h = 3.6, 0.4, 4.4, 3.0
xs = [0.2 + k * (w + gap) for k in range(5)]
box(xs[0], y0, w, h, '1  Simulation banks', '2 x 8,192 virtual networks\nscrambled Sobol prior\n9 physiological parameters\n(+ neuromodulatory nuisance)', B, Be)
box(xs[1], y0, w, h, '2  EEG descriptors', 'unit-invariant:\nrelative power (\u03b4 \u03b8 \u03b1 \u03b2)\nIAF, 1/f exponent\nPLV\u03b1, wPLI\u03b1, Kuramoto r\u03b1', B, Be)
box(xs[2], y0, w, h, '3  Inverse ensemble', '5 x MLP deep ensemble\nfeatures \u2192 parameters\nsplit-conformal 90 %\nprediction intervals', G, Ge)
box(xs[3], y0, w, h, '4  Digital twin', 'one twin per recording\nparameter estimate + interval\nposterior-predictive and\nout-of-sample checks', G, Ge)
box(xs[4], y0, w, h, '5  Forward emulator', '5 x MLP surrogate\nparameters (+ modulators)\n\u2192 expected descriptors', G, Ge)
for k in range(4):
    arr((xs[k] + w + 0.03, y0 + h / 2), (xs[k + 1] - 0.03, y0 + h / 2))
yb, hb = 0.2, 3.4
box(0.2, yb, 5.4, hb, 'Real EEG (Duville et al.)', 'ASD and TD recordings\n17 shared electrodes, 250 Hz\n1\u201345 Hz, average reference\npre-specified quality control\n20-s windows, split halves', O, Oe)
box(6.0, yb, 5.6, hb, '7  Verification and validation', 'full stochastic simulator, paired seeds\nbootstrap CIs, robustness checks\npharmaco-EEG face validity\nreliability, child identification\nTD leave-one-child-out control', G, Ge)
box(12.0, yb, 7.8, hb, '6  Sparse pharmacological search', 'u \u2208 [\u22121, 1]$^9$: GABA$_A$, slow GABA, AMPA, GluN2A, GluN2B,\ntonic drive, DA, 5-HT, NE; all 129 supports of size \u2264 3\nminimise Mahalanobis distance to the TD reference + \u03bb\u2016u\u2016$^2$\nresidual-preserving prediction of post-intervention EEG\nnull: random u with equal sparsity and norm', G, Ge)
arr((xs[1] + 0.9, yb + hb + 0.05), (xs[1] + 0.9, y0 - 0.05))      # real EEG -> descriptors
arr((xs[3] + w / 2, y0 - 0.05), (xs[3] + w / 2, yb + hb + 0.05))  # twin -> search
arr((xs[4] + w / 2, y0 - 0.05), (xs[4] + w / 2, yb + hb + 0.05))  # emulator -> search
arr((12.0 - 0.03, yb + hb / 2), (11.6 + 0.03, yb + hb / 2))        # search -> verification
save(fig, 'Figure1_framework')
print('ok')
